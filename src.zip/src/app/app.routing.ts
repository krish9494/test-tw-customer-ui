import { HomeComponent } from './home/home.component';
import { HotelSearchResolver } from './hotel-search/hotelSearch.resolver';
import { Routes, RouterModule } from '@angular/router';
import { HotelSearchComponent } from './hotel-search/hotel-search.component';
import { HotelDetailsComponent } from './hotel-details/hotel-details.component';
import { BookingComponent } from './booking/booking.component';
import { ThankYouComponent } from './thank-you/thank-you.component';
import { ManageBookingComponent } from './manage-booking/manage-booking.component';
import { PartnerResolver } from './hotel-search/partner.resolver';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { PropertyManagerSigninComponent } from './property-manager-signin/property-manager-signin.component';
import { PrintLayoutComponent } from './common/print-layout/print-layout.component';
import { PrintBookingConfirmationComponent } from './common/print-booking-confirmation/print-booking-confirmation.component';
import { PciCallbackComponent } from './pci-callback/pci-callback.component';
import { SitemapComponent } from './sitemap/sitemap.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { FaqsComponent } from './faqs/faqs.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AuthGuard } from './services/_auth/auth.guard';

const appRoutes: Routes = [
  {
    path: '',
    component: HomeComponent,
    resolve: { message: HotelSearchResolver, partnerTypes: PartnerResolver }
  },
  {
    path: 'hotel-search',
    component: HotelSearchComponent,
    resolve: { message: HotelSearchResolver, partnerTypes: PartnerResolver }
  },
  {
    path: 'hotel-details/:id',
    component: HotelDetailsComponent
  },
  {
    path: 'booking',
    component: BookingComponent
  },
  {
    path: 'thankyou',
    component: ThankYouComponent
  },
  {
    path: 'manage-booking',
    canActivate: [AuthGuard],
    component: ManageBookingComponent
  },
  {
    path: 'view-booking/:orderNumber',
    canActivate: [AuthGuard],
    component: ViewBookingsComponent
  },
  {
    path: 'signin',
    component: PropertyManagerSigninComponent
  },
  {
    path: 'callback',
    component: PciCallbackComponent
  },
  {
    path: 'print',
    component: PrintLayoutComponent,
    children: [
      {
        path: 'booking-confirmation',
        component: PrintBookingConfirmationComponent
      }
    ]
  },
  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent
  },
  {
    path: 'terms-and-conditions',
    component: TermsAndConditionsComponent
  },
  {
    path: 'sitemap',
    component: SitemapComponent
  },
  {
    path: 'faqs',
    component: FaqsComponent
  },
  {
    path: 'about-us',
    component: AboutUsComponent
  },
  {
    path: 'contact-us',
    component: ContactUsComponent
  },
  {
    path: 'member-sign-in',
    component: PropertyManagerSigninComponent
  }
];

export const routing = RouterModule.forRoot(appRoutes, { useHash: true });
