import 'hammerjs';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { routing } from './app.routing';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HotelSearchComponent } from './hotel-search/hotel-search.component';
import { FooterComponent } from './footer/footer.component';
import { HotelDetailsComponent } from './hotel-details/hotel-details.component';
import { BookingComponent } from './booking/booking.component';
import { ThankYouComponent } from './thank-you/thank-you.component';
import { ManageBookingComponent } from './manage-booking/manage-booking.component';
import { CustomErrorHandler } from './services/error.service';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SearchComponent } from './common/search-component/search.component';
import { HotelSearchFiltersComponent } from './search-filters/hotel-search-filters.component';
import { HomeComponent } from './home/home.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { FilterComponent } from './utility-components/filter.component';
import { ProgressBarComponent } from './utility-components/progressbar-components/progress-bar.component';
import { DatePickerComponent } from './common/date-picker/date-picker.component';
import { GuestComponent } from './common/guest-dropdown/guest-dropdown.component';
import { MultiTranslateHttpLoader } from 'ngx-translate-multi-http-loader';
import { environment } from '../environments/environment';
import { CognitoUtil } from './services/aws/cognito.service';
import { NgxGalleryModule } from 'ngx-gallery';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { CountrySelectionComponent } from './country-selection/country-selection.component';
import { AddRoomComponent } from './add-room/add-room.component';
import { ChangeRoomComponent } from './change-room/change-room.component';
import { AgmCoreModule } from '@agm/core';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { ChangeDatesComponent } from './change-dates/change-dates.component';
import { ManageBookingHotelDetailComponent } from './manage-booking-hotel-detail/manage-booking-hotel-detail.component';
import { PropertyManagerSigninComponent } from './property-manager-signin/property-manager-signin.component';
// import { FilterPipe } from './utility-components/filter.pipe';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';
import { AncillaryTypeFilter } from './pipes/ancillaryTypeFilter.pipes';
import { PrintLayoutComponent } from './common/print-layout/print-layout.component';
import { PrintBookingConfirmationComponent } from './common/print-booking-confirmation/print-booking-confirmation.component';
import { EditGuestComponent } from './edit-guest/edit-guest.component';
import { HotelMapViewComponent } from './common/google-map/hotel-map-view/hotel-map-view.component';
import { GoogleMapComponent } from './common/google-map/google-map.component';
import { GoogleMapViewComponent } from './common/google-map/google-map-view/google-map-view.component';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { PciCallbackComponent } from './pci-callback/pci-callback.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './terms-and-conditions/terms-and-conditions.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { SitemapComponent } from './sitemap/sitemap.component';
import { FaqsComponent } from './faqs/faqs.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { PaymentGatewayComponent } from './payment-gateway/payment-gateway.component';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HotelSearchComponent,
    FooterComponent,
    HotelDetailsComponent,
    BookingComponent,
    ThankYouComponent,
    ManageBookingComponent,
    SearchComponent,
    DatePickerComponent,
    GuestComponent,
    HotelSearchFiltersComponent,
    HomeComponent,
    FilterComponent,
    ProgressBarComponent,
    SignUpComponent,
    ViewBookingsComponent,
    AddRoomComponent,
    ChangeRoomComponent,
    CountrySelectionComponent,
    ChangeDatesComponent,
    ManageBookingHotelDetailComponent,
    PropertyManagerSigninComponent,
    // FilterPipe
    GoogleMapComponent,
    AncillaryTypeFilter,
    PrintLayoutComponent,
    PrintBookingConfirmationComponent,
    EditGuestComponent,
    GoogleMapViewComponent,
    AncillaryTypeFilter,
    PrintLayoutComponent,
    PrintBookingConfirmationComponent,
    HotelMapViewComponent,
    GoogleMapComponent,
    PciCallbackComponent,
    PrivacyPolicyComponent,
    TermsAndConditionsComponent,
    AboutUsComponent,
    SitemapComponent,
    FaqsComponent,
    ContactUsComponent,
    PaymentGatewayComponent
    // FilterPipe
  ],
  imports: [
    NgxGalleryModule,
    MDBBootstrapModule.forRoot(),
    FlexLayoutModule,
    ScrollDispatchModule,
    NgxGalleryModule,
    MDBBootstrapModule.forRoot(),
    FlexLayoutModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAkSShBR7tGOBX1z5Jo-9IAmMvtiBLq1RM'
    }),
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    NgbModule,
    FormsModule,
    HttpClientModule,
    routing,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    BrowserAnimationsModule,
    AgmSnazzyInfoWindowModule,
    ToastrModule.forRoot(),
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    FormsModule
  ],
  providers: [
    // CustomErrorHandler,
    // { provide: ErrorHandler, useClass: CustomErrorHandler },
    CognitoUtil,
    DatePipe
  ],
  entryComponents: [
    EditGuestComponent,
    AddRoomComponent,
    PaymentGatewayComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function HttpLoaderFactory(http: HttpClient) {
  const baseURL = environment.IMAGE_LOC;
  return new MultiTranslateHttpLoader(http, [
    { prefix: '/assets/i18n/', suffix: '/base.json' },
    { prefix: '/assets/i18n/', suffix: '/home.json' },
    { prefix: '/assets/i18n/', suffix: '/search.json' },
    { prefix: '/assets/i18n/', suffix: '/booking.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/city.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/privacy_policy.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/terms_and_conditions.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/sitemap.json' },
    { prefix: '/assets/i18n/', suffix: '/faqs.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/about_us.json' },
    { prefix: baseURL + '/assets/i18n/', suffix: '/contact_us.json' }
  ]);
}
