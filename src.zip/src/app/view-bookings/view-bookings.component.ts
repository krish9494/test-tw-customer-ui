import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';
import {
  NgxGalleryOptions,
  NgxGalleryImage,
  NgxGalleryAnimation
} from 'ngx-gallery';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs';
import { NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { AddRoomComponent } from '../add-room/add-room.component';
import { ChangeRoomComponent } from '../change-room/change-room.component';
import { ChangeDatesComponent } from '../change-dates/change-dates.component';
import { EditGuestComponent } from '../edit-guest/edit-guest.component';

import * as _ from 'lodash';
import * as moment from 'moment';

import { ProductOrder } from '../model/product-order.model';
import { CreditCardDetails } from '../model/credit-card-details.model';

import { RootScopeService } from '../services/rootscope.service';
import { environment } from '../../environments/environment';
import { PartnerPolicyService } from '../services/policy.service';
import { HotelService } from '../services/hotel.service';
import { OrderService } from '../services/order.service';

import { ProductdSearchRequest } from '../model/ProductdSearchRequest';
import { OrderItem } from '../model/order-item.model';
import { ToastrService } from 'ngx-toastr';
import { AppConstants } from '../constants/app.contstants';
import { Renderer2 } from '@angular/core';
import { ElementRef } from '@angular/core';
import { PCIBookingService } from '../services/pci-booking/pci-booking.service';
import { PaymentGatewayComponent } from '../payment-gateway/payment-gateway.component';

import { Faq } from '../model/Faq';
import { MasterDataService } from '../shared/services/master-data.service';
import { Product } from '../model/product.model';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-view-bookings',
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.scss'],
  providers: [OrderService, HotelService, PartnerPolicyService]
})
export class ViewBookingsComponent implements OnInit {
  lodash = _;
  moment = moment;

  closeResult: string;
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[] = [];

  productGalleryImagesMap = new Map();
  public isCollapsed = false;
  toggleicon: boolean = false;
  order: ProductOrder = new ProductOrder();
  faqList: Faq[] = [];
  public today = moment(new Date());
  partnerReview: any = {
    guestReviews: []
  };
  recentReview: any = {
    guestReviews: []
  };
  totalCancellationCharges: any;

  currentPage = 0;
  pageSize = 4;
  aroundDetails: any = {};
  childPolicies = {};
  cotPolicies = [];
  extraBedPolicies = [];
  petLangCode: any;
  petFacCode: any;
  petsAllowed: boolean;
  intLangCode: any;
  intConType: any;
  intPriceCode: any;
  intAvailable: boolean;
  intPrice: any;
  parkPriceCode: any;
  parkPrice: any;
  isIntChargeSpecified: boolean;
  parkAvailable: boolean;
  intParkCode: any;
  isParkChargeSpecified: boolean;
  intParkResType: any;
  parkFacList = [];
  //check in check out policy
  partnerCheckIn: string;
  partnerCheckout: string;
  prtnrChckInAgLmt: string;

  public isCollapsedRoomAmenities = new Map();
  modelReference: any;
  cancelForm: FormGroup;
  updateCCForm: FormGroup;
  orderItemToCancel: number;
  updateCCSubmitted: boolean;
  faqResponses;
  faqDetailResponse$: Observable<any>;
  cardExpiryYear: number[] = [];
  productSearchRequest = new ProductdSearchRequest();
  message: any;
  baseImgUrl: String = environment.IMAGE_LOC;
  faqCategory = [];
  faqCategoryResponce:any;
  public hideRuleContent: boolean[] = [];
  cardExpiryMonth = {
    '01': 'common.months.Jan',
    '02': 'common.months.Feb',
    '03': 'common.months.Mar',
    '04': 'common.months.Apr',
    '05': 'common.months.May',
    '06': 'common.months.Jun',
    '07': 'common.months.Jul',
    '08': 'common.months.Aug',
    '09': 'common.months.Sep',
    '10': 'common.months.Oct',
    '11': 'common.months.Nov',
    '12': 'common.months.Dec'
  };
  booking: any;
  isFormLoaded = false;
  orderStatus = '';
  orderNo: any;
  cancelRoomSelected = new OrderItem();
  @ViewChild('cancelRoomConfModal') cancelRoomConfModal: TemplateRef<any>;
  cancelledOrderItem: OrderItem;
  public bedTypes = new Map();
  constructor(
    private modalService: NgbModal,
    private activatedRoute: ActivatedRoute,
    private orderService: OrderService,
    private rootScopeService: RootScopeService,
    private partnerPolicyService: PartnerPolicyService,
    private hotelService: HotelService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private renderer: Renderer2,
    private pciBookingService: PCIBookingService,
    private ele: ElementRef,
    private masterService: MasterDataService,
    public datePipe : DatePipe
  ) { }

  ngOnInit() {
    this.galleryOptions = [
      {
        width: '100%',
        height: '180px',
        thumbnailsColumns: 4,
        thumbnailsRemainingCount: true,
        imageAnimation: NgxGalleryAnimation.Slide
      },
      {
        breakpoint: 800,
        width: '100%',
        height: '600px',
        imagePercent: 80,
        thumbnailsPercent: 20,
        thumbnailsMargin: 10,
        thumbnailMargin: 10
      },

      {
        breakpoint: 400,
        preview: false
      }
    ];


    // --- view booking start.

    this.rootScopeService.setCurrencyChangeAllowedSubject(false);

    const params = this.activatedRoute.snapshot.params;
    this.orderNo = params.orderNumber;
    this.orderApi();

    // form
    this.cancelForm = this.formBuilder.group({
      cancelReason: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-zA-Z ]{2,30}')
        ])
      ]
    });

    this.updateCCForm = this.formBuilder.group({
      cardType: ['', Validators.compose([Validators.required])],
      cardNumber: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(16),
          Validators.maxLength(16),
          Validators.pattern('[0-9]{16}')
        ])
      ],
      cardHoldName: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(2),
          Validators.pattern('[a-zA-Z ]{2,30}')
        ])
      ],
      expiryMonth: ['', Validators.compose([Validators.required])],
      expiryYear: ['', Validators.compose([Validators.required])]
    });

    let currentYear = moment().year();
    let maxExpiryYear = moment().year() + 8;
    for (; currentYear <= maxExpiryYear; currentYear++) {
      this.cardExpiryYear.push(currentYear);
    }
  }

  orderApi() {
    this.orderService.getOrderDetails(this.orderNo).subscribe(
      orderDetails => {
        this.order = orderDetails;
        this.isFormLoaded = true;
        if (orderDetails.orderStatus !== 'CANCELLED') {
          this.orderStatus = 'Confirmed';
        } else {
          this.orderStatus = 'Cancelled';
        }
        // orderItem check before MSD for cancellation charges
        this.order.orderItems.forEach(orderItem => {
          if (orderItem.cancelmilStoneDate) {
            orderItem['isBeforeMSD'] = this.isMlstnDtBfrTdy(orderItem.cancelmilStoneDate);
          }
        });
        // call for reviews, whats around
        this.loadAroundDetails();
        this.recentReview = {
          guestReviews: []
        };
        this.hotelService.getHotelReviews(this.order.partnerId).subscribe(
          resp => {
            let partnerInfo: any = resp;
            this.recentReview.overAllReview = _.filter(
              partnerInfo.partnerReviewAggregateList,
              { isOverAllComment: 'Y' }
            )[0];
            this.recentReview.otherReviews = _.filter(
              partnerInfo.partnerReviewAggregateList,
              { isOverAllComment: 'N' }
            );
          },
          error => {
            throw error;
          }
        );
        this.getGuestReviews(true);

        // Set bedTypes
        this.order.orderItems.forEach(orderItem => {
          // Each orderItem
          if (orderItem.product !== undefined && orderItem.product.bedDetails !== undefined) {
            const bedTypesList = orderItem.product.bedDetails.split('/');
            bedTypesList.forEach(bedType => {
              // Each bed type from 'bedDetails' field.
              let bedObjList = this.bedTypes.get(orderItem.product.productId);
              if (!bedObjList) {
                bedObjList = [];
              }
              bedObjList.push({
                type: bedType.substring(0, 2),
                count: bedType.substring(3)
              });
              this.bedTypes.set(orderItem.product.productId, bedObjList);
            });
          }
        });

        // Set room amenities;
        const amenityListMaster = this.masterService.getLatestMasterData('AmenityList');
        const primaryTagList = this.masterService.getLatestMasterData('primaryTagList');
        this.order.orderItems.forEach(orderItem => {
          if (orderItem.product !== undefined && orderItem.product.productAmenityList !== undefined) {
            orderItem.product.productAmenityList.forEach(productAmenity => {
              const amenityFound = _.find(amenityListMaster, [
                'amenityId',
                productAmenity.amenityId
              ]);
              if (amenityFound) {
                productAmenity.amenityMasterTO = amenityFound;
              }
            });
          }
          Object.assign(orderItem, {
            amenityToggle: true
          });
          // Set Gallery Images
          if (orderItem.product !== undefined && orderItem.product.partnerImagesTOS !== undefined) {

            this.galleryImages = [];
            orderItem.product.partnerImagesTOS.forEach(productImage => {
              const imagePathOriginal =
                this.baseImgUrl + '/' + productImage.originalImage;
              const obj = {
                small: imagePathOriginal,
                medium: imagePathOriginal,
                big: imagePathOriginal
              };
              this.galleryImages.push(obj);
            });
            this.productGalleryImagesMap.set(orderItem.product.productId, this.galleryImages);
          }
        });
      },
      error => {
        console.error('error while getting order details : ', error);
      }
    );
  }

  open(content, modalName: string, orderItemToCancel?: any) {
    this.cancelRoomSelected = orderItemToCancel;

    if (orderItemToCancel !== undefined) {
      this.orderItemToCancel = orderItemToCancel.orderItemId;
    } else {
      this.orderItemToCancel = undefined;
    }

    if (modalName == 'cancelRoom') {
      this.modelReference = this.modalService.open(content, {
        size: 'lg',
        windowClass: 'cancelRoom',
        ariaLabelledBy: 'modal-basic-title'
      });
    } else if (modalName == 'cancelBooking') {
      this.modelReference = this.modalService.open(content, {
        size: 'lg',
        windowClass: 'cancelBooking',
        ariaLabelledBy: 'modal-basic-title'
      });
      this.getTotalCancellationCharges();
    } else if (modalName == 'hotelMap') {
      this.modelReference = this.modalService.open(content, {
        size: 'lg',
        windowClass: 'hotelMap',
        ariaLabelledBy: 'modal-basic-title'
      });
    } else if (modalName == 'sideBarMap') {
      this.modelReference = this.modalService.open(content, {
        size: 'lg',
        windowClass: 'sideBarMap',
        ariaLabelledBy: 'modal-basic-title'
      });
    } else if (modalName == 'cancelRoomConfirmation') {
      this.modelReference = this.modalService.open(content, {
        size: 'lg',
        windowClass: 'cancelRoomConfirmation',
        ariaLabelledBy: 'modal-basic-title'
      });
    }
    this.modelReference.result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }

  openUpdateCC(contentUpdateCC) {
    const modalRef = this.modalService.open(PaymentGatewayComponent, {
      windowClass: 'pci-booking-pg'
    });
    modalRef.result.then((result: any) => {
      if (result) {
        this.toastr.success('Card details updated');
      } else {
        this.toastr.error('Card details updation failed');
      }
    });
  }

  editGuestDetails(orderItem) {
    const modalRef = this.modalService.open(EditGuestComponent);
    modalRef.componentInstance.orderItem = orderItem;
    modalRef.componentInstance.orderNumber = this.order.orderNumber;
    modalRef.result.then(result => {
      if (result === 'success') {
        this.orderApi();
      }
    });
  }

  openModalAddRoom() {
    const modalRef = this.modalService.open(AddRoomComponent);
    modalRef.result.then(
      (result: any) => { },
      reason => {
        if (reason) {
          this.order = reason;
          this.orderApi();
        }
      }
    );
    modalRef.componentInstance.order = this.order;
  }

  openModalChangeDates(modalComponent: ChangeDatesComponent) {
    modalComponent.open();
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  loadAroundDetails() {
    this.hotelService.getAroundDetails(this.order.partnerId).subscribe(
      resp => {
        this.aroundDetails = resp;
      },
      error => {
        throw error;
      }
    );
  }

  public beforeChange($event: NgbTabChangeEvent) {
    if ($event.nextId === 'guest-reviews-info') {
      this.partnerReview = {
        guestReviews: []
      };
      this.hotelService
        .getHotelReviews(this.order.partnerId)
        .subscribe(resp => {
          let partnerInfo: any = resp;
          this.partnerReview.overAllReview = _.filter(
            partnerInfo.partnerReviewAggregateList,
            { isOverAllComment: 'Y' }
          )[0];
          this.partnerReview.otherReviews = _.filter(
            partnerInfo.partnerReviewAggregateList,
            { isOverAllComment: 'N' }
          );
        });
      this.getGuestReviews(false);
    }
  }
  public getGuestReviews(isRecentReview) {
    let request = {
      currentPage: this.currentPage,
      pageSize: this.pageSize
    };
    this.hotelService
      .getHotelGuestReviews(this.order.partnerId, request)
      .subscribe(
        resp => {
          let partnerInfo: any = resp;
          if (isRecentReview) {
            this.recentReview.guestReviews = this.partnerReview.guestReviews.concat(
              partnerInfo.orderReviewList
            );
          } else {
            this.partnerReview.guestReviews = this.partnerReview.guestReviews.concat(
              partnerInfo.orderReviewList
            );
          }
        },
        error => {
          throw error;
        }
      );
  }

  public loadMoreReviews() {
    this.currentPage = this.currentPage + 1;
    this.getGuestReviews(false);
  }

  public getPolicies() {
    let self = this;
    self.productSearchRequest.productIds = self.order.orderItems.map(
      orderItem => {
        return orderItem.product.productId;
      }
    );
    this.partnerPolicyService
      .getPartnerPoliciesByOrder(this.order.partnerId, self.productSearchRequest, this.datePipe.transform(this.order.orderDate,'yyyy-MM-dd'))
      .subscribe(
        policies => {
          if (policies.petPolicy !== undefined || policies.petPolicy !== null) {
            this.setPetPolicyCode(policies.petPolicy);
          }
          if (policies.internetPolicy !== undefined || policies.internetPolicy !== null) {
            this.setInternetPolicyCode(policies.internetPolicy);
          }
          if (policies.parkingPolicy !== undefined || policies.parkingPolicy !== null) {
            this.setParkingPolicyCode(policies.parkingPolicy);
          }
          if (policies.checkInOutPolicy !== undefined || policies.checkInOutPolicy !== null) {
            this.setCheckInOutPolicy(policies.checkInOutPolicy);
          }
        },
        error => {
          throw error;
        }
      );
  }
  public setCheckInOutPolicy(checkInPolicy: any) {
    if(checkInPolicy !== undefined  || checkInPolicy !== null ) {
      this.partnerCheckIn = checkInPolicy.checkInBetween;
      this.partnerCheckout = checkInPolicy.checkOutBetween;
      this.prtnrChckInAgLmt = checkInPolicy.checkInAgeLimit;
    }
  }  
  public setPetPolicyCode(petPolicy: any) {
    if (petPolicy.isAvailToGuest.langCode === 'no') {
      this.petsAllowed = false;
      this.petLangCode = 'policy.pet.no';
    } else {
      this.petsAllowed = true;
      this.petLangCode = petPolicy.chargesApplicable
        ? 'policy.pet.yur.charged'
        : 'policy.pet.yur.free';
      this.petFacCode =
        petPolicy.petFacility.langCode === 'pb'
          ? 'policy.pet.pb'
          : 'policy.pet.pt';
    }
  }
  public setInternetPolicyCode(intPolicy: any) {
    if (intPolicy.isAvailToGuest.langCode === 'no') {
      this.intAvailable = false;
      this.isIntChargeSpecified = false;
      this.intLangCode = 'policy.internet.no';
    } else if (
      intPolicy.isAvailToGuest.langCode === 'yf' ||
      intPolicy.isAvailToGuest.langCode === 'cns' ||
      intPolicy.isAvailToGuest.langCode === 'yp'
    ) {
      this.intAvailable = true;
      this.isIntChargeSpecified = false;
      this.intLangCode =
        'policy.internet.' +
        intPolicy.isAvailToGuest.langCode +
        '.' +
        intPolicy.connLocation.langCode;
      this.intConType = 'policy.internet.conn.' + intPolicy.connType.langCode;
    }
    if (intPolicy.isAvailToGuest.langCode === 'yp') {
      this.intPrice = intPolicy.price;
      this.isIntChargeSpecified = true;
      this.intPriceCode =
        'policy.internet.' +
        intPolicy.isAvailToGuest.langCode +
        '.price.' +
        intPolicy.pricePer.langCode;
      this.intConType = 'policy.internet.conn.' + intPolicy.connType.langCode;
    }
  }
  public setParkingPolicyCode(parPolicy: any) {
    if (parPolicy.isAvailToGuest.langCode === 'no') {
      this.parkAvailable = false;
      this.isParkChargeSpecified = false;
      this.intParkCode = 'policy.parking.no';
    } else if (
      parPolicy.isAvailToGuest.langCode === 'yf' ||
      parPolicy.isAvailToGuest.langCode === 'cns' ||
      parPolicy.isAvailToGuest.langCode === 'yp'
    ) {
      this.parkAvailable = true;
      this.isParkChargeSpecified = false;
      this.intParkCode =
        'policy.parking.' +
        parPolicy.isAvailToGuest.langCode +
        '.' +
        parPolicy.parType.langCode +
        '.' +
        parPolicy.parLocation.langCode;
        this.intParkResType =
        'policy.parking.res.' + parPolicy.reservation.langCode;
    }
    if (parPolicy.isAvailToGuest.langCode === 'yp') {
      this.isParkChargeSpecified = true;
      this.parkPrice = parPolicy.price;
      this.parkPriceCode =
        'policy.parking.' +
        parPolicy.isAvailToGuest.langCode +
        '.price.' +
        parPolicy.pricePer.langCode;
      this.intParkResType =
        'policy.parking.res.' + parPolicy.reservation.langCode;
    }
    this.parkFacList = [];
    for (let fac of parPolicy.parFacList) {
      this.parkFacList.push('policy.parking.fac.' + fac.langCode);
    }
  }
  collapseRoomAmenities(productId) {
    this.isCollapsedRoomAmenities.set(
      productId,
      !this.isCollapsedRoomAmenities.get(productId)
    );
  }

  public cancel() {
    if (this.cancelForm.invalid) {
      return;
    }
    let modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.order.orderNumber;
    modifiedOrder.orderCancellationReason = this.cancelForm.get(
      'cancelReason'
    ).value;
    if (this.orderItemToCancel) {
      modifiedOrder.orderStatus = 'PARTIAL_CANCELLED';
      modifiedOrder.cancelOrderId = this.orderItemToCancel;
    } else {
      modifiedOrder.orderStatus = 'CANCELLED';
    }

    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        this.order = orderDetails;
        this.orderItemToCancel = undefined;
        this.modelReference.close();
        this.toastr.success('Your order has been cancelled');
        this.orderApi();
      },
      error => {
        this.toastr.error('Your order cancellation failed');
        console.error('error while getting order details : ', error);
      }
    );
  }
  public cancelRoom() {
    let modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.order.orderNumber;
    modifiedOrder.orderStatus = 'PARTIAL_CANCELLED';
    modifiedOrder.orderItems = [];

    let orderItem: OrderItem = new OrderItem();
    orderItem.orderItemId = this.cancelRoomSelected.orderItemId;
    orderItem.product = new Product();
    orderItem.product.productId = this.cancelRoomSelected.product.productId;
    orderItem.ratePlanId = this.cancelRoomSelected.ratePlanId;
    orderItem.changeType = 'CANCEL_ROOM';


    modifiedOrder.orderItems.push(orderItem);
    this.cancelledOrderItem = this.cancelRoomSelected;
    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        this.order = orderDetails;
        this.modelReference.close();
        this.open(this.cancelRoomConfModal, "cancelRoomConfirmation");
        this.orderApi();
      },
      error => {
        this.toastr.error('Your room cancellation failed');
        console.error('error while getting order details : ', error);
      }
    );
  }
  public ignoreCancel() {
    this.modelReference.close();
  }

  onDateUpdated(updatedOrder) {
    this.order = updatedOrder;
    this.orderApi();
  }

  updateCC() {
    this.updateCCSubmitted = true;
    if (this.updateCCForm.invalid) {
      return;
    }
    let modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.order.orderNumber;
    modifiedOrder.cardDetail = new CreditCardDetails();

    modifiedOrder.cardDetail.cardType = this.updateCCForm.get('cardType').value;
    modifiedOrder.cardDetail.cardHolderName = this.updateCCForm.get(
      'cardHoldName'
    ).value;
    modifiedOrder.cardDetail.cardNumber = this.updateCCForm.get(
      'cardNumber'
    ).value;
    modifiedOrder.cardDetail.expiryMonth = this.updateCCForm.get(
      'expiryMonth'
    ).value;
    modifiedOrder.cardDetail.expiryYear = this.updateCCForm.get(
      'expiryYear'
    ).value;

    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        this.order = orderDetails;
        this.orderItemToCancel = undefined;
        this.modelReference.close();
      },
      error => {
        console.error('error while getting order details : ', error);
      }
    );
  }

  emailProperty() {
    let emailProperty = {
      partnerID: this.order.partnerId,
      orderId: this.order.orderNumber,
      message: this.message
    };

    this.orderService.emailProperty(emailProperty).subscribe(
      (data: string) => {
        this.toastr.success('', 'Message Send Successfully', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      },
      error => {
        console.error(error);
      }
    );
  }

  print() {
    // Need to enhance the code
    // const newWindow = window.open();
    // const css = '<link href="print-booking.css" rel="stylesheet" type="text/css">';
    // newWindow.document.body.innerHTML = css + document.getElementById('print-page').innerHTML;
    // newWindow.document.write();
    // window.document.getElementById('print-page').className = 'print-div';
    window.print();
  }

  getTotalCancellationCharges(): any {
    let sum = 0;
    this.order.orderItems.forEach(orderItem => {
      if (this.isMlstnDtBfrTdy(orderItem.cancelmilStoneDate)) {
        sum += orderItem.cnclchrgBfrmlStnSell;
      } else if (!this.isMlstnDtBfrTdy(orderItem.cancelmilStoneDate)) {
        sum += orderItem.cnclchrgAftrmlStnSell;
      }
      this.totalCancellationCharges = sum;
    });
  }

  isMlstnDtBfrTdy(mileStoneDate): boolean {
    const today = moment(new Date());
    if (today.isBefore(mileStoneDate)) {
      return true;
    }
    else {
      return false;
    }
  }

  fetchFAQs() {
    this.faqList = [];
    this.faqCategory= [];
    this.rootScopeService.getConfiguration('FAQ').subscribe(faqs => {
      this.faqCategoryResponce = faqs;
      this.faqCategoryResponce.forEach(element => {
          this.faqCategory.push(element.configName);
        });
    });
    this.rootScopeService.getFaqs(this.order.partnerId).subscribe(
      (data: string) => {
        this.faqResponses = data;
        this.faqResponses.forEach(response => {
          this.faqCategory.forEach(element=>{
             if (element === response.faqCategory) {
               //need to make the drropdown value as selected by this category//this code is needed
            // this.faqList.push({
            //   question: response.faqQuestion,
            //   answer: response.faqAnswer
            // });
          }
        });
      });
      },
      error => {
        console.error(error);
      }
    );
}

  toggle(index) {
    // toggle based on index
    this.hideRuleContent[index] = !this.hideRuleContent[index];
  }

  faqChanged(faqCategory) {
    this.faqList = [];
    this.faqResponses.forEach(response => {
      if (faqCategory === response.faqCategory) {
        this.faqList.push({
          question: response.faqQuestion,
          answer: response.faqAnswer
        });
      }
    });
  }
}
