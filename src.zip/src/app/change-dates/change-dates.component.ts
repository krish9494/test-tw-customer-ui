import {
  Component,
  OnInit,
  ViewChild,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import {
  NgbModal,
  ModalDismissReasons,
  NgbCalendar,
  NgbDatepickerConfig,
  NgbDate
} from '@ng-bootstrap/ng-bootstrap';

import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';

import { ProductOrder } from '../model/product-order.model';
import {
  PricingRequest,
  SelectedPartner
} from '../model/pricing-request.model';
import { Product, ProductRatePlan } from '../model/pricing-common.model';
import { SearchRequest } from '../model/search-request.model';
import { Partner } from '../model/partner.model';

import { OrderService } from '../services/order.service';
import { PricingService } from '../services/pricing.service';

import { AppConstants } from '../constants/app.contstants';

import * as moment from 'moment';

@Component({
  selector: 'app-change-dates',
  templateUrl: './change-dates.component.html',
  styleUrls: ['./change-dates.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [OrderService, PricingService]
})
export class ChangeDatesComponent implements OnInit {
  @ViewChild('contentChangeDates') modalChangeDates: any;
  @Input() order: ProductOrder;
  @Output() updatedOrder = new EventEmitter<ProductOrder>();
  dateChangeForm: FormGroup;
  moment = moment;
  updatedPrice: number;
  closeResult: string;
  modelReference: any;
  minDate;
  toDate: NgbDate;
  fromDate: NgbDate;
  invalidDateRange: boolean;
  isSoldOut: boolean;
  constructor(
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private orderService: OrderService,
    config: NgbDatepickerConfig,
    private pricingService: PricingService,
    private calendar: NgbCalendar
  ) {
    this.minDate = {
      year: calendar.getToday().year,
      month: calendar.getToday().month,
      day: calendar.getToday().day
    };
    const fromTommorow = this.calendar.getNext(
      this.calendar.getToday(),
      'd',
      1
    );
    const lastDayOfYear = this.calendar.getNext(
      this.calendar.getToday(),
      'd',
      366
    );
    config.minDate = fromTommorow;
    config.maxDate = lastDayOfYear;
  }

  ngOnInit() {
    this.dateChangeForm = this.formBuilder.group({
      checkIn: ['', Validators.required],
      checkOut: ['', Validators.required]
    });
  }
  changePeriodFrom(event: NgbDate) {
    if (event.after(this.toDate)) {
      this.toDate = event;
    } else if (this.toDate === null) {
      this.toDate = this.fromDate;
    } else if (this.calcDaysDiff() > 10) {
      this.invalidDateRange = true;
    } else {
      this.invalidDateRange = false;
    }
  }
  changePeriodTo(event: NgbDate) {
    if (event.before(this.fromDate)) {
      this.fromDate = event;
    } else if (this.fromDate === null) {
      this.fromDate = this.toDate;
    } else if (this.calcDaysDiff() > 10) {
      this.invalidDateRange = true;
    } else {
      this.invalidDateRange = false;
    }
  }
  private createDateFromNgbDate(ngbDate: NgbDate): Date {
    const date: Date = new Date(
      Date.UTC(ngbDate.year, ngbDate.month - 1, ngbDate.day)
    );
    return date;
  }

  calcDaysDiff(): number {
    const fromDate: Date = this.createDateFromNgbDate(this.fromDate);
    const toDate: Date = this.createDateFromNgbDate(this.toDate);
    const daysDiff = Math.floor(
      Math.abs(<any>fromDate - <any>toDate) / (1000 * 60 * 60 * 24)
    );
    return daysDiff;
  }

  open() {
    this.modelReference = this.modalService.open(this.modalChangeDates, {
      size: 'lg',
      windowClass: 'modalChangeDates',
      ariaLabelledBy: 'modal-basic-title'
    });

    this.fromDate = null;
    this.toDate = null;
    this.updatedPrice = null;
    this.invalidDateRange = false;
    this.isSoldOut = false;
  }

  orderSum({ saleValue, chargeValue, saleTaxValue }) {
    const saleVal = saleValue ? saleValue : 0;
    const chargeVal = chargeValue ? chargeValue : 0;
    const saleTaxVal = saleTaxValue ? saleTaxValue : 0;
    return Math.round(saleVal + chargeVal + saleTaxVal);
  }

  validatePrice() {
    if (
      this.dateChangeForm.get('checkIn').value &&
      this.dateChangeForm.get('checkOut').value
    ) {
      let todayDate = moment();
      let checkInDate = moment(
        this.dateChangeForm.get('checkIn').value.year +
          '-' +
          this.dateChangeForm.get('checkIn').value.month +
          '-' +
          this.dateChangeForm.get('checkIn').value.day,
        'YYYY-MM-DD'
      );
      let checkOutDate = moment(
        this.dateChangeForm.get('checkOut').value.year +
          '-' +
          this.dateChangeForm.get('checkOut').value.month +
          '-' +
          this.dateChangeForm.get('checkOut').value.day,
        'YYYY-MM-DD'
      );
      if (checkInDate.isSameOrAfter(checkOutDate)) {
        this.dateChangeForm.controls['checkOut'].markAsTouched();
        this.dateChangeForm.get('checkOut').setErrors({ incorrect: true });
        this.updatedPrice = null;
        return;
      }
      if (this.dateChangeForm.invalid) {
        return;
      }

      const pricingRequest: PricingRequest = new PricingRequest();
      pricingRequest.checkIn = checkInDate.format('YYYY-MM-DD');
      pricingRequest.checkOut = checkOutDate.format('YYYY-MM-DD');
      pricingRequest.noOfRooms = Number(this.order.searchRequest.noOfRooms);
      pricingRequest.adultCnt = Number(this.order.searchRequest.adultCnt);
      pricingRequest.childCnt = Number(this.order.searchRequest.childCnt);
      pricingRequest.currencyCode = this.order.searchRequest.currencyCode;
      pricingRequest.selectedPartner = new SelectedPartner();
      pricingRequest.selectedPartner.partnerId = this.order.partner.partnerId;
      pricingRequest.selectedPartner.productTOList = [];

      // Start: Logic to convert Order Items into Product->RatePlan Pricing request model.
      let productMap = new Map<number, Product>();
      let ratePlanMap = new Map<number, ProductRatePlan>();

      this.order.orderItems.forEach(orderItem => {
        let ratePlan: ProductRatePlan;
        if (ratePlanMap.has(orderItem.ratePlanId)) {
          ratePlan = ratePlanMap.get(orderItem.ratePlanId);
          ratePlan.selectedRoomCount = ratePlan.selectedRoomCount + 1;
        } else {
          ratePlan = new ProductRatePlan();
          ratePlan.productRatePlanId = orderItem.ratePlanId;
          ratePlan.selectedRoomCount = 1;
        }
        ratePlanMap.set(ratePlan.productRatePlanId, ratePlan);
      });
      this.order.orderItems.forEach(orderItem => {
        let product: Product;
        if (productMap.has(orderItem.product.productId)) {
          product = productMap.get(orderItem.product.productId);
        } else {
          product = new Product();
          product.productId = orderItem.product.productId;
          product.productRatePlanToList = [];
          if (ratePlanMap.has(orderItem.ratePlanId)) {
            const ratePlan = ratePlanMap.get(orderItem.ratePlanId);
            product.productRatePlanToList.push(ratePlan);
          }
        }
        productMap.set(product.productId, product);
      });
      productMap.forEach((value: Product, key: number) => {
        pricingRequest.selectedPartner.productTOList.push(value);
      });
      // End : Logic to convert Order Items into Product->RatePlan Pricing request model.
      console.log('Pricing Request:', pricingRequest);
      this.getOrderPrice(pricingRequest);
    }
  }

  changeBookingdates() {
    let checkInDate = moment(
      this.dateChangeForm.get('checkIn').value.year +
        '-' +
        this.dateChangeForm.get('checkIn').value.month +
        '-' +
        this.dateChangeForm.get('checkIn').value.day,
      'YYYY-MM-DD'
    );
    let checkOutDate = moment(
      this.dateChangeForm.get('checkOut').value.year +
        '-' +
        this.dateChangeForm.get('checkOut').value.month +
        '-' +
        this.dateChangeForm.get('checkOut').value.day,
      'YYYY-MM-DD'
    );
    if (checkInDate.isAfter(checkOutDate)) {
      this.dateChangeForm.controls['checkOut'].markAsTouched();
      this.dateChangeForm.get('checkOut').setErrors({ incorrect: true });
    }

    if (this.dateChangeForm.invalid || !this.updatedPrice) {
      return;
    }

    let modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.order.orderNumber;

    modifiedOrder.searchRequest = new SearchRequest();
    modifiedOrder.searchRequest.checkIn = checkInDate.format('YYYY-MM-DD');
    modifiedOrder.searchRequest.checkOut = checkOutDate.format('YYYY-MM-DD');
    modifiedOrder.orderStatus = AppConstants.ORDER_STATUS_MODIFIED;

    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        this.updatedOrder.emit(orderDetails);
        this.modelReference.close();
      },
      error => {
        console.log('error while getting order details : ', error);
      }
    );
  }

  getOrderPrice(pricingRequest: PricingRequest) {
    console.log('price req: ', pricingRequest);
    this.pricingService.getPrice(pricingRequest).subscribe(
      (pricingResponse: Partner) => {
        if (pricingResponse.soldOut) {
          // Sold out not available.
          this.updatedPrice = null;
          this.isSoldOut = true;
        } else {
          this.updatedPrice =
            pricingResponse.salePriceSelCur ||
            0 + pricingResponse.taxesSelCur ||
            0 + pricingResponse.chargesSelCur ||
            0;
          this.isSoldOut = false;
        }
      },
      error => {
        console.log('pricng service error : ', error);
      }
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}
