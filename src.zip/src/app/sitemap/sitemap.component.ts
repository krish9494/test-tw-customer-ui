import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';

@Component({
  selector: 'app-sitemap',
  templateUrl: './sitemap.component.html',
  styleUrls: ['./sitemap-ltr.component.scss','./sitemap-rtl.component.scss']
})
export class SitemapComponent implements OnInit {

  cssLayout: String = 'ltr';

  constructor(private rootScopeService : RootScopeService) { } 

  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }

}
