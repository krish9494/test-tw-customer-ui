import { DataExchangeService } from './../services/data-exchange.service';
import {
  Component,
  OnInit,
  AfterViewInit,
  Renderer2,
  HostListener
} from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';

import { ProductOrder } from '../model/product-order.model';
import { Customer } from '../model/customer.model';
import { Title } from '../model/customer.model';
import { Partner } from '../model/partner.model';
import { CreditCardDetails } from '../model/credit-card-details.model';
import { SearchRequest } from '../model/search-request.model';
import { HotelSearchModel } from '../model/hotel-search-model';
import { Charges } from '../model/charges.model';
import { OrderItem } from '../model/order-item.model';
import { Guest } from '../model/guest.model';
import {
  PricingRequest,
  SelectedPartner
} from '../model/pricing-request.model';
import { ProductRatePlan } from '../model/pricing-common.model';

import { RootScopeService } from '../services/rootscope.service';
import { OrderService } from '../services/order.service';
import { PricingService } from '../services/pricing.service';
import { RouterService } from '../services/router.service';

import * as _ from 'lodash';
import * as moment from 'moment';
import { environment } from 'src/environments/environment';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { PCIBookingService } from '../services/pci-booking/pci-booking.service';
import { AppConstants } from '../constants/app.contstants';
import { ElementRef } from '@angular/core';
import { UserLoginService } from '../services/aws/user-login.service';
import { CognitoUtil } from '../services/aws/cognito.service';
import { Tax } from '../model/tax.model';
import { Product } from '../model/product.model';
import { GoogleMapPartner } from '../model/google-map-partner.model';
import { MasterDataService } from '../shared/services/master-data.service';

declare var $: any;

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss'],
  providers: [OrderService, PricingService]
})
export class BookingComponent implements OnInit, AfterViewInit {
  productOrder: ProductOrder;
  productDetails: any;
  nightStays: number;
  productId: number;
  selectedProduct: any;
  charges: Charges[];
  taxes: Tax[];
  searchModel: HotelSearchModel;
  selectedProductDetails: any;
  orderAmount = 0.0;
  lodash = _;
  moment = moment;
  productOrderDetails: any;
  cardExpiryYear: number[] = [];
  googleMapPartnerList: GoogleMapPartner[] = [];
  customerTitles: Title[] = [
    { code: '1', name: 'Mr' },
    { code: '2', name: 'Mrs' },
    { code: '3', name: 'Miss' },
    { code: '4', name: 'Master' }
  ];
  cardExpiryMonth = {
    '01': 'common.months.Jan',
    '02': 'common.months.Feb',
    '03': 'common.months.Mar',
    '04': 'common.months.Apr',
    '05': 'common.months.May',
    '06': 'common.months.Jun',
    '07': 'common.months.Jul',
    '08': 'common.months.Aug',
    '09': 'common.months.Sep',
    '10': 'common.months.Oct',
    '11': 'common.months.Nov',
    '12': 'common.months.Dec'
  };

  configMaster: any = [];

  selectedRatePlans: any;

  productRatePlans: any = [];

  bookingForm: FormGroup;
  submitted = false;

  authenticatedUser: Customer = null;
  guestCount = 0;
  topAmenties: any = [];
  selectedRooms = '';
  productDetailsArray: any = [];
  closeResult: string;
  baseImgUrl: String = environment.IMAGE_LOC;

  selectedPartner: any;
  receiver: any;
  self;
  noOfRooms = 0;
  partnerAmenities: any[];

  constructor(
    private router: Router,
    private orderService: OrderService,
    private formBuilder: FormBuilder,
    private routerService: RouterService,
    private pricingService: PricingService,
    private rootScopeService: RootScopeService,
    private pciBookingService: PCIBookingService,
    private renderer: Renderer2,
    private ele: ElementRef,
    private modalService: NgbModal,
    private masterService: MasterDataService,
    private dataExchangeService: DataExchangeService
  ) {
    if (!this.routerService.navigationData) {
      this.productOrderDetails = undefined;
      this.router.navigate(['/']);
    }
  }

  ngOnInit() {
    this.pciBookingService.getAccessToken().subscribe(resp => {
      this.createIFrame(resp.accessToken);
    });
    this.loadPage();
  }

  loadPage() {
    // window.scrollTo(0, 0);
    if (this.routerService.navigationData === undefined) {
      this.productOrderDetails = undefined;
      this.router.navigate(['/']);
    }
    this.selectedRatePlans = this.routerService.navigationData;
    this.selectedRatePlans = this.selectedRatePlans.selectedRatePlans;
    if (this.selectedRatePlans === undefined) {
      // this to be replaced by Popup or manage gracefully. need to discuss
      alert('order session lost. Pls try again.');
      this.productOrderDetails = undefined;
      this.router.navigate(['/']);
    }

    this.rootScopeService
      .getConfiguration('WHY_SIGNUP')
      .subscribe(configMaster => {
        this.configMaster = configMaster;
      });
    this.rootScopeService.setCurrencyChangeAllowedSubject(true);

    this.bookingForm = this.formBuilder.group({
      isMainTraveller: ['', Validators.required],
      title: ['', Validators.required],
      firstName: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-zA-Z ]{2,30}')
        ])
      ],
      lastName: [
        '',
        Validators.compose([
          Validators.required,
          Validators.pattern('[a-zA-Z ]{2,30}')
        ])
      ],
      email: ['', [Validators.required, Validators.email]],
      phone: [
        '',
        [
          Validators.required,
          Validators.minLength(7),
          Validators.pattern('[0-9]{7,13}')
        ]
      ],
      travelType: ['']
    });

    let currentYear = moment().year();
    const maxExpiryYear = moment().year() + 8;
    for (; currentYear <= maxExpiryYear; currentYear++) {
      this.cardExpiryYear.push(currentYear);
    }
    // Getting the searchModel from session storage,
    // As it has been passed from hotel detail and same tab so same session.
    const searchCriteriaData = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    if (searchCriteriaData === undefined ||
      searchCriteriaData === null ||
      searchCriteriaData.searchModel === null ||
      searchCriteriaData.searchModel === undefined) {
      // If search Criteria/Model is Missing can't move forward with pricing service.
      this.router.navigate(['/']);
    }
    this.searchModel = searchCriteriaData.searchModel;
    this.productOrder = new ProductOrder();
    this.productOrder.orderStatus = 'BOOKED';
    this.productOrder.searchRequest = new SearchRequest();
    this.productOrder.searchRequest.checkIn = this.searchModel.checkIn;
    this.productOrder.searchRequest.checkOut = this.searchModel.checkOut;
    this.productOrder.searchRequest.noOfRooms = this.searchModel.noOfRooms;
    this.productOrder.searchRequest.adultCnt = Number(
      this.searchModel.adultCnt
    );
    this.productOrder.searchRequest.childCnt =
      this.searchModel.noOfChildren || 0;
    this.productOrder.searchRequest.currencyCode = this.searchModel.currencyCode;
    this.productOrder.cardDetail = new CreditCardDetails();

    const pricingRequest: PricingRequest = new PricingRequest();
    pricingRequest.checkIn = this.searchModel.checkIn;
    pricingRequest.checkOut = this.searchModel.checkOut;
    pricingRequest.noOfRooms = Number(this.searchModel.noOfRooms);
    pricingRequest.adultCnt = Number(this.searchModel.adultCnt);
    pricingRequest.childCnt = Number(this.searchModel.childCnt) || 0;
    pricingRequest.currencyCode = this.searchModel.currencyCode;
    pricingRequest.selectedPartner = new SelectedPartner();
    pricingRequest.selectedPartner.productTOList = [];

    this.bookingForm.addControl('specialRequest', new FormControl(''));
    Object.keys(this.selectedRatePlans).forEach((ratePlanId: string) => {
      // console.log(ratePlanId, this.selectedRatePlans[ratePlanId]);
      this.selectedRooms =
        this.selectedRooms +
        this.selectedRatePlans[ratePlanId].product.productDesc +
        ',';
      const selectedProductDetails = this.selectedRatePlans[ratePlanId];
      this.productOrderDetails = this.selectedRatePlans[ratePlanId];
      this.productDetails = selectedProductDetails.productDetails;
      this.getGoogleMapValue();
      this.orderAmount =
        this.orderAmount +
        selectedProductDetails.ratePlan.salePrice *
        selectedProductDetails.rooms;
      this.selectedProduct = selectedProductDetails.productDetails;
      this.productOrder.partnerId = Number(
        selectedProductDetails.productDetails.partnerId
      );
      //this.charges = selectedProductDetails.ratePlan.chargesToList;
      for (let count = 0; count < selectedProductDetails.rooms; count++) {
        this.productRatePlans.push(selectedProductDetails);
        this.bookingForm.addControl(
          'firstName' + this.guestCount,
          new FormControl('', [
            Validators.required,
            Validators.pattern('[a-zA-Z ]{2,30}')
          ])
        );
        this.bookingForm.addControl(
          'lastName' + this.guestCount,
          new FormControl('', [
            Validators.required,
            Validators.pattern('[a-zA-Z ]{2,30}')
          ])
        );
        // this.bookingForm.addControl(
        //   'specialRequest' + this.guestCount,
        //   new FormControl('')
        // );
        this.bookingForm.addControl(
          'smokingPreference' + this.guestCount,
          new FormControl('')
        );
        this.guestCount++;
      }
      const product: Product = new Product();
      product.productId = selectedProductDetails.product.productId;
      product.productRatePlanToList = [];
      const productRatePlan: ProductRatePlan = new ProductRatePlan();
      productRatePlan.productRatePlanId = Number(ratePlanId);
      productRatePlan.selectedRoomCount = selectedProductDetails.rooms;

      // TODO Logic to add ratePlan to product if product already exist.
      const prodExist = pricingRequest.selectedPartner.productTOList.find(
        prd => prd.productId === product.productId
      );
      if (prodExist !== undefined) {
        // Product already added, so rate plan will be added to existing Product entry.
        prodExist.productRatePlanToList.push(productRatePlan);
        pricingRequest.selectedPartner.productTOList = pricingRequest.selectedPartner.productTOList.filter(
          prd => prd.productId !== product.productId
        );
        pricingRequest.selectedPartner.productTOList.push(prodExist);
      } else {
        // Product doesnt exist in list.
        product.productRatePlanToList.push(productRatePlan);
        pricingRequest.selectedPartner.productTOList.push(product);
      }
      // get partner amenities.
      this.checkPartnerAmenities();
    });
    this.selectedRooms = this.selectedRooms.substring(
      0,
      this.selectedRooms.length - 1
    );
    pricingRequest.selectedPartner.partnerId = this.productOrder.partnerId;
    this.getOrderPrice(pricingRequest);

    this.rootScopeService
      .getAuthenticatedUserSubject()
      .subscribe((user: Customer) => {
        this.authenticatedUser = user;
        if (user !== null) {
          this.bookingForm
            .get('firstName')
            .setValue(this.authenticatedUser.firstName);
          this.bookingForm
            .get('lastName')
            .setValue(this.authenticatedUser.lastName);
          this.bookingForm.get('email').setValue(this.authenticatedUser.email);
          this.bookingForm.get('phone').setValue(this.authenticatedUser.phone);
          this.bookingForm.get('firstName').disable();
          this.bookingForm.get('lastName').disable();
          this.bookingForm.get('email').disable();
        } else {
          this.bookingForm.get('firstName').enable();
          this.bookingForm.get('lastName').enable();
          this.bookingForm.get('email').enable();
        }
      });
  }
  /**
   * This function is mapping the partner amenities,
   * using the master data for a partner.
   */
  checkPartnerAmenities() {
    this.partnerAmenities = [];
    const amenityListMaster = this.masterService.getLatestMasterData('AmenityList');
    const amenitiesArray = this.productDetails.topAmenities.split(',');
    // filtering out the partner amenities with the master amenity list
    this.partnerAmenities= amenityListMaster.filter(amenityMaster => 
      amenitiesArray.includes((amenityMaster.amenityId).toString())
    );
  }

  ngAfterViewInit() {
    this.productOrder.orderItems = [];
  }

  _keyPress(event: any) {
    const pattern = /[0-9]/;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  @HostListener('window:message', ['$event'])
  handleFrameMessage(e) {
    const host = 'https://service.pcibooking.net/';
    const originDomain = e.origin
      .replace('http://', '')
      .replace('https://', '');
    let postMessageOrigin = host
      .replace('http://', '')
      .replace('https://', '')
      .toLowerCase();
    if (postMessageOrigin.endsWith('/')) {
      postMessageOrigin = postMessageOrigin.substring(
        0,
        postMessageOrigin.length - 1
      );
    }
    if (originDomain.toLowerCase() === postMessageOrigin) {
      if (e.data === 'ready') {
        // iframeIsReady = true;
        // $('#iframePayment').fadeIn(1000);
        // console.log('Messaging Log: ' + e.data);
      } else if (e.data === 'valid') {
        // this.callBackForPaymentGateway(e);
      } else if (e.data.indexOf('frameDimensionsChanged') === 0) {
        const objectParts = e.data.split(':');
        const width = parseInt(objectParts[1]);
        const height = parseInt(objectParts[2]);
        $('#iframePayment')
          .height(height)
          .attr('height', height);
        console.log('Messaging Log: ' + e.data);
      } else if (e.data[0] === '{') {
        console.log('Messaging Log: ');
        console.log(JSON.parse(e.data));
      } else {
        alert('Please fill all the mandatory fields');
      }
    }
  }

  getOrderPrice(pricingRequest: PricingRequest) {
    this.pricingService.getPrice(pricingRequest).subscribe(
      (pricingResponse: Partner) => {
        this.productOrder.partner = pricingResponse;
        this.selectedPartner = this.productOrder.partner;
        if (
          !pricingResponse.bookingWithoutCC ||
          pricingResponse.bookingWithoutCC === 'N'
        ) {
        }
        this.noOfRooms = 0;
        pricingResponse.productTOList.forEach(prod => {
          prod.productRatePlanToList.forEach(ratePlan => {
            this.noOfRooms += ratePlan.selectedRoomCount;
          });
        });

        // Charges and Taxes
        if (this.selectedPartner.chargesToList !== undefined) {
          this.charges = this.selectedPartner.chargesToList;
        }
        if (this.selectedPartner.taxes !== undefined) {
          this.taxes = this.selectedPartner.taxes;
        }
      },
      error => {
        console.log('pricng service error : ', error);
      }
    );
  }

  // setFocus() {
  //   this.ele.nativeElement.querySelector('#firstName').focus();
  // }

  createIFrame(accessToken: string) {
    const PCI_URL =
      AppConstants.PCI_BOOKING_URL +
      AppConstants.PCI_BOOKING_CAPTURE_CARD +
      '?accessToken=' +
      accessToken +
      '&brand=' +
      AppConstants.TRIPWORLD_SANDBOX +
      '&autoDetectCardType=true&autoFocus=false&success=' +
      encodeURIComponent(
        window.location.origin +
        '/assets/pci-callback.component.html?cardToken={cardToken}&authToken={" + authParamName + "}&cardType={cardType}&cardNumber={cardNumber}&cvv={cvv}&expiration={expiration}&cardHolderName={cardHolderName}'
      ) +
      '&failure=' +
      encodeURIComponent(window.location.origin) +
      '&submitWithPostMessage=true&postMessageHost=' +
      encodeURIComponent(window.location.origin);
    const iFrame = this.renderer.createElement('iframe');
    iFrame.setAttribute('src', PCI_URL);
    iFrame.setAttribute('id', 'iframePayment');
    iFrame.setAttribute('frameBorder', '0');
    iFrame.setAttribute('height', '400px');
    iFrame.setAttribute('width', '790px');
    iFrame.setAttribute('onload', 'setFocus()');
    const self = this;
    self.ele.nativeElement.querySelector('#title').focus();
    iFrame.onload = function () {
      self.receiver = self.ele.nativeElement.querySelector(
        '#iframePayment'
      ).contentWindow;
      self.ele.nativeElement.querySelector('#title').focus();
      // self.pciBookingService.getTempSession().subscribe(resp => {
      //   console.log('session----', resp);
      // });
      // self.pciBookingService.getTempSession1().subscribe(resp => {
      //   console.log('session----', resp);
      // });
    };
    this.renderer.appendChild(
      this.ele.nativeElement.querySelector('#payment-gateway'),
      iFrame
    );
  }
  displayRoomName(productRatePlan) {
    if (productRatePlan) {
      return productRatePlan.product.productDesc;
    }
  }
  confirmBooking() {
    this.submitted = true;
    if (
      !this.productOrder.partner.bookingWithoutCC ||
      this.productOrder.partner.bookingWithoutCC === 'N'
    ) {
      // this.productOrder.cardDetail.expiryMonth = this.bookingForm.get(
      //   'expiryMonth'
      // ).value;
      // this.productOrder.cardDetail.expiryYear = this.bookingForm.get(
      //   'expiryYear'
      // ).value;
      if (
        this.productOrder.cardDetail.expiryMonth &&
        this.productOrder.cardDetail.expiryYear
      ) {
        const expiryDate = moment(
          this.productOrder.cardDetail.expiryYear +
          '-' +
          this.productOrder.cardDetail.expiryMonth +
          '-28'
        );
        this.bookingForm.controls['expiryMonth'].markAsTouched();
        if (moment().isAfter(expiryDate)) {
          this.bookingForm.get('expiryMonth').setErrors({ incorrect: true });
        } else {
          this.bookingForm.get('expiryMonth').setErrors(null);
        }
      }

      // this.productOrder.cardDetail.cardNumber = this.bookingForm.get(
      //   'cardNumber'
      // ).value;
      // this.productOrder.cardDetail.cvv = this.bookingForm.get('cvv').value;
      // this.productOrder.cardDetail.cardHolderName = this.bookingForm.get(
      //   'cardHolderName'
      // ).value;
    }

    if (this.bookingForm.invalid) {
      const firstElementWithError =
        document.querySelector('select.ng-invalid') ||
        document.querySelector('input.ng-invalid') ||
        document.querySelector('textarea.ng-invalid');
      if (firstElementWithError) {
        firstElementWithError.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'center'
        });
      }
      return;
    }
    this.receiver.postMessage('validate', AppConstants.PCI_BOOKING_URL);
    this.receiver.postMessage('submit', AppConstants.PCI_BOOKING_URL);
  }

  @HostListener('window:callBackForPaymentGateway', ['$event'])
  callBackForPaymentGateway(callback) {
    if (callback.detail.cardType) {
      const token = decodeURIComponent(callback.detail.cardToken);
      const tokenIndex = token.lastIndexOf('/');
      this.productOrder.accessToken = token.slice(tokenIndex + 1);
      this.populateCardDetails(callback.detail);
      this.productOrder.orderAmount =
        this.selectedProduct.minProductAmount * this.searchModel.nightStays;
      this.productOrder.baseCurrency = this.productOrderDetails.productDetails.partnerCurrencyCode;
      this.productOrder.orderCurrency = this.searchModel.currencyCode;

      this.productOrder.travelType = this.bookingForm.get('travelType').value
        ? this.bookingForm.get('travelType').value
        : null;
      this.productOrder.customer = new Customer();

      if (this.authenticatedUser !== null) {
        this.productOrder.customer.email = this.authenticatedUser.email;
      } else {
        this.productOrder.customer.email = this.bookingForm.get('email').value;
      }

      this.productOrder.customer.title = this.bookingForm.get('title').value;
      this.productOrder.customer.firstName = this.bookingForm.get(
        'firstName'
      ).value;
      this.productOrder.customer.lastName = this.bookingForm.get(
        'lastName'
      ).value;
      this.productOrder.customer.phone = this.bookingForm.get('phone').value;

      Object.keys(this.selectedRatePlans).forEach((ratePlanId: string) => {
        let selectedProductDetails = this.selectedRatePlans[ratePlanId];
        for (let count = 0; count < selectedProductDetails.rooms; count++) {
          let orderItem: OrderItem = new OrderItem();
          orderItem.guest = [new Guest()];
          orderItem.guest[0].firstName = this.bookingForm.get(
            'firstName' + count
          ).value;
          orderItem.guest[0].lastName = this.bookingForm.get(
            'lastName' + count
          ).value;
          orderItem.guest[0].guestType = 'ADULT';
          orderItem.product = new Product();
          orderItem.product.productId =
            selectedProductDetails.product.productId;
          orderItem.ratePlanId =
            selectedProductDetails.ratePlan.productRatePlanId;
          orderItem.smokingRoom = this.bookingForm.get(
            'smokingPreference' + count
          ).value;
          orderItem.specialRequest = this.bookingForm.get(
            'specialRequest'
          ).value;
          this.productOrder.orderItems.push(orderItem);
        }
      });

      this.orderService.order(this.productOrder).subscribe(
        (data: any) => {
          this.productOrder = data;
          this.routerService.navigationData = {
            orderNumber: this.productOrder.orderNumber
          };
          this.router.navigate(['/thankyou']);
        },
        error => {
          console.log(error);
        }
      );
    }
  }
  populateCardDetails(detail: any) {
    let cardDetail: CreditCardDetails = new CreditCardDetails();
    cardDetail.cardType = detail.cardType;
    cardDetail.cardNumber = detail.cardNumber;
    this.productOrder.cardDetail = cardDetail;
  }

  getGuestError(control, guest) {
    return this.submitted && this.bookingForm.get(control + guest).errors;
  }

  getGuestErrorMessage(control, guest) {
    return this.bookingForm.get(control + guest).errors.required;
  }

  getGuestPatternErrorMessage(control, guest) {
    return this.bookingForm.get(control + guest).errors.pattern;
  }

  copyCustomerNameToGuest() {
    for (let count = 0; count < this.guestCount; count++) {
      this.bookingForm
        .get('firstName' + count)
        .setValue(this.bookingForm.controls['firstName'].value);
      this.bookingForm
        .get('lastName' + count)
        .setValue(this.bookingForm.controls['lastName'].value);
    }
  }

  clearGuestNames() {
    for (let count = 0; count < this.guestCount; count++) {
      this.bookingForm.get('firstName' + count).setValue('');
      this.bookingForm.get('lastName' + count).setValue('');
    }
  }

  open(content) {
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg', windowClass: 'checkLocation' })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;

        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }


  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  backToDetail() {
    this.router.navigate(['/hotel-details/' + this.productOrder.partnerId]);
  }

  getTermsAndConditions(terms) {
    this.modalService
      .open(terms, { ariaLabelledBy: 'modal-basic-title', size: 'lg' })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  getGoogleMapValue() {
    this.googleMapPartnerList = [];
    this.googleMapPartnerList.push({
      partnerName: this.productDetails.partnerName,
      latitude: this.productDetails.latitude,
      longitude: this.productDetails.longitude,
      partnerImage: this.productDetails.partnerImage,
      starRating: this.productDetails.starRating,
      partnerAddress:this.productDetails.partnerAddress,
    })
  }
}
