import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';

@Component({
  selector: 'app-privacy-policy',
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./privacy-policy.component-ltr.scss','./privacy-policy.component-rtl.scss']
})
export class PrivacyPolicyComponent implements OnInit {

  cssLayout: String = 'ltr';
  constructor(private rootScopeService : RootScopeService) { } 

  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }

  

}
