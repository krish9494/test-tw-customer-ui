import { Brand } from './../model/Brand.model';
import { MasterDataService } from './../shared/services/master-data.service';
import { DataExchangeService } from './../services/data-exchange.service';
import { SearchCriteria } from './../model/search-criteria.model';
import {
  Component,
  OnInit,
  ViewChild,
  HostListener,
  ViewEncapsulation,
  Output,
  EventEmitter
} from '@angular/core';
import { HotelSearchModel } from '../model/hotel-search-model';
import { HotelService } from '../services/hotel.service';
import {
  NgbDateAdapter,
  NgbDateStruct,
  NgbDateNativeAdapter,
  NgbInputDatepicker,
  NgbCalendar,
  NgbDate
} from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import {
  debounceTime,
  distinctUntilChanged,
  map,
  tap,
  switchMap,
  catchError
} from 'rxjs/operators';
import { LocationService } from '../services/location.service.';
import { SearchFilterService } from '../services/search-filters.service';
import { ToastrService } from 'ngx-toastr';
import { RootScopeService } from '../services/rootscope.service';
import { Input } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'src/environments/environment';
import { FilterType, Filter } from '../model/filterType.model';

@Component({
  selector: 'app-hotel-search-filters',
  templateUrl: './hotel-search-filters.component.html',
  styleUrls: ['./hotel-search-filters.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HotelSearchFiltersComponent implements OnInit {
  filters: FilterType[];
  newFilter: FilterType;
  newFilterType: string;
  filtersCopy: any;
  filterList: any;
  searchCriteria: any;
  partnerTypes: any;
  @Input() partners: any;
  @Output() filterClick = new EventEmitter();
  closeResult: string;
  baseImgUrl: String = environment.IMAGE_LOC;
  filterTypeMap = new Map<string, FilterType>();
  selectedFiltersMap = new Map<string, FilterType>();
  filterCheck: boolean = false;

  constructor(
    private hotelService: HotelService,
    private route: ActivatedRoute,
    private searchFilterService: SearchFilterService,
    private toastr: ToastrService,
    private rootService: RootScopeService,
    private modalService: NgbModal,
    private dataExchangeService: DataExchangeService,
    private masterDataService: MasterDataService
  ) { }

  ngOnInit() {
    // if condition is to avoid null values. 
    if (this.dataExchangeService.getDataFromSessionStorage('tw-scd').searchModel) {
      this.searchCriteria = this.dataExchangeService.getDataFromSessionStorage('tw-scd').searchModel;
    }
    this.partnerTypes = this.route.snapshot.data.partnerTypes;

    this.hotelService.productSubject.subscribe(resp => {
      if (resp) {
        this.partners = resp;
        // Filters Ahad's code.
        if (this.partners.filterList) {
          // Get searchCriteria from session storage
          const searchCriteria: SearchCriteria = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
          const filterTypes: FilterType[] = this.partners.filterList;
          filterTypes.forEach(filter => {
            if (filter.filterType == 'HOTEL_TYPE') {
              this.updateHotelTypesFilter(filter);
            }
            if (filter.filterType === 'BRAND') {
              this.updateBrandFilter(filter);
            }
            if (
              searchCriteria === undefined ||
              searchCriteria.filtersApplied === false
            ) {
              this.selectedFiltersMap.clear();
            }
            // 'filterCheck' is to identify SEARCH hit between filter hit and Search hit.
            // 'filterCheck' is TRUE if SEARCH hit is made from clicking filters.
            if (
              searchCriteria !== undefined &&
              searchCriteria.filtersApplied === true &&
              this.selectedFiltersMap.get(filter.filterType)
            ) {
              let appldFltrTyp = this.selectedFiltersMap.get(
                filter.filterType
              );
              filter.filters.forEach(fil => {
                let checkedFilter: Filter[] = appldFltrTyp.filters.filter(
                  elem => elem.searchCode === fil.searchCode
                );
                if (checkedFilter.length > 0) {
                  fil.checked = true;
                }
              });
            }
            this.filterTypeMap.set(filter.filterType, filter);
          });
          // Make 'filterCheck' as false.
          this.filterCheck = false;
          this.filters = Array.from(this.filterTypeMap.values());
        }
        // Filters Ahad's code.
      }
    });
  }

  updateFilters() {
    // let filterCriteria: any;

    // filterCriteria = {"checkInDate":"2018-12-30","checkOutDate":"2018-12-31","noOfRooms":"1","adultCnt":"1","childCnt":"0","nightStays":1,"location":{"code":"AE","value":"United Arab Emirates","displayText":"United Arab Emirates","type":"COUNTRY"},"sortBy":"RECOMMENDED","order":"ASC","pageNo":"1"}

    this.searchFilterService
      .getHotelFilterDetails(this.searchCriteria)
      .subscribe(
        response => {
          this.filters = response as FilterType[];
          this.updateHotelTypes();
          this.filterList = _.cloneDeep(this.filters);
          _.forEach(this.filterList, function(filter) {
            filter.filters = [];
          });
        },
        error => {
          throw error;
        }
      );
  }

  public updateHotelTypes() {
    let hotelTypes: any = _.find(this.filters, { filterType: 'HOTEL_TYPE' });
    let self = this;
    _.forEach(hotelTypes.filters, function(hotelType) {
      let partnerType: any = _.find(self.partnerTypes, {
        partnerTypeId: _.parseInt(hotelType.searchCode)
      });
      if (partnerType) {
        hotelType.partnerTypeLanCode = partnerType.partnerTypeLanCode;
      }
    });
  }

  private updateHotelTypesFilter(hotelTypeFilter: any) {
    let hotelTypes: any = hotelTypeFilter;
    let self = this;
    _.forEach(hotelTypes.filters, function(hotelType) {
      let partnerType: any = _.find(self.partnerTypes, {
        partnerTypeId: _.parseInt(hotelType.searchCode)
      });
      if (partnerType) {
        hotelType.partnerTypeLanCode = partnerType.partnerTypeLanCode;
      }
    });
  }
  /**
   *
   * @param brandFilter - passing filter to return the brand names for respective searchCodes,
   * present in the filters(brandFilter) response.
   */
  updateBrandFilter(brandFilter: FilterType) {
    // Getting the brandFilters which have brand id and brand names for mapping to the searchCode in response
    const brandFilterList = this.masterDataService.getLatestMasterData('partnerBrands');
    if (brandFilterList !== undefined && brandFilterList !== null) {
      brandFilter.filters.forEach((searchCodeCount: Filter) => {
        const brandFound = brandFilterList.find((brand: Brand) => {
          return brand.brandId.toString() === searchCodeCount.searchCode;
        });
        // If the brand id matches with the searchCode, the associated brand name is appended to the response
        if (brandFound) {
          searchCodeCount.brandName = brandFound.brandName;
        }
      });
    }
  }

  public filterResults(index, filter: Filter, choosenFilterType: FilterType) {
    filter.checked = !filter.checked;
    // Code to save and store selected filters to 'filterTypeMap' Start.
    if (this.selectedFiltersMap.get(choosenFilterType.filterType)) {
      let filterType = this.selectedFiltersMap.get(
        choosenFilterType.filterType
      );

      if (filter.checked) {
        // Add filter to corresponding entry of map
        filterType.filters.push(filter);
      } else {
        // Remove filter from corresponding entry of map
        filterType.filters = filterType.filters.filter(
          elem => elem.searchCode != filter.searchCode
        );
      }
      this.selectedFiltersMap.set(filterType.filterType, filterType);
    } else {
      // Add new FilterType entry to Map.
      let filterType = new FilterType();
      filterType.filterType = choosenFilterType.filterType;
      filterType.filterTypeLanCode = choosenFilterType.filterTypeLanCode;
      filterType.filters = [];
      filterType.filters.push(filter);
      this.selectedFiltersMap.set(filterType.filterType, filterType);
    }
    // Code to save and store selected filters to 'filterTypeMap' End.

    // Search criteria for SEARCH hit.
    this.searchCriteria.pageNo = 1;
    this.searchCriteria.filters = Array.from(this.selectedFiltersMap.values());
    this.searchCriteria.currencyCode = this.rootService.getSelectedCurrency();

    const tempSearchCritriaData = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    if (
      tempSearchCritriaData.searchModel.checkIn !== undefined &&
      tempSearchCritriaData.searchModel.checkOut !== undefined
    ) {
      this.searchCriteria.checkIn = tempSearchCritriaData.searchModel.checkIn;
      this.searchCriteria.checkOut = tempSearchCritriaData.searchModel.checkOut;
    }

    const searchCriteriaData = {
      searchModel: this.searchCriteria,
      filtersApplied: true
    };

    // Setting Search criteria in session storage
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);

    // 'filterCheck' is TRUE when SEARCH hit is made from Filters component.
    this.filterCheck = true;
    this.hotelService.getHotels(this.searchCriteria).subscribe(
      response => {
        this.toastr.success('', 'Filtered results', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
        let searhcData = {
          products: response
        };
        //This is partners is for Google Map.
        this.partners = response;
        this.filterClick.emit(searhcData);
      },
      error => {
        throw error;
      }
    );
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      // distinctUntilChanged(),
      map(term =>
        term === ''
          ? this.selectHotel('')
          : this.partners.partnerToList
            .filter(
              partner =>
                partner.partnerName
                  .toLowerCase()
                  .indexOf(term.toLowerCase()) > -1
            )
            .slice(0, 10)
      )
    );

  formatter = (x: { partnerName: string }) => x.partnerName;

  selectHotel($event) {
    let products = _.cloneDeep(this.partners);
    if ($event) {
      products.partnerToList = [$event.item];
    }
    let searhcData = {
      products: products,
      isPaginationNotVisible: $event !== ''
    };
    this.filterClick.emit(searhcData);
  }

  trackByFilters(index, item) {
    if (!item) return null;
    return item.filterType;
  }

  open(content) {
    this.modalService
      .open(content, {
        ariaLabelledBy: 'modal-basic-title',
        windowClass: 'seeOnMapModal'
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}
