import { MasterDataService } from './../shared/services/master-data.service';
import { DataExchangeService } from './../services/data-exchange.service';
import { HotelService } from './../services/hotel.service';
import { RootScopeService } from './../services/rootscope.service';
import { HotelSearchModel } from './../model/hotel-search-model';
import { RouterService } from './../services/router.service';
import {
  Component,
  OnInit
} from '@angular/core';
import * as _ from 'lodash';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { TranslateService } from '@ngx-translate/core';
import { Partner } from '../model/partner.model';
import { SearchCriteria } from '../model/search-criteria.model';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { GoogleMapPartner } from '../model/google-map-partner.model';
@Component({
  selector: 'app-hotel-search',
  templateUrl: './hotel-search.component.html',
  styleUrls: [
    './hotel-search.component-ltr.scss',
    './hotel-search.component-rtl.scss'
  ],
  providers: []
})
export class HotelSearchComponent implements OnInit {
  cssLayout: String = 'ltr';
  products: any;
  googleMapPartnerList: GoogleMapPartner[] = [];
  recPerPage: number = 20;
  currentPage: number = 1;
  totalResultsCount: number = 100;
  baseImgUrl: String = environment.IMAGE_LOC;
  lodash = _;
  currencyCode;
  amenityList;
  primaryTagList;
  searchModel: any;
  searchModelTemp: any;
  showPagination: boolean = false;
  closeResult: string;
  sessionID: string;
  constructor(
    private routerService: RouterService,
    private rootScopeService: RootScopeService,
    private hotelService: HotelService,
    private route: ActivatedRoute,
    private translate: TranslateService,
    private modalService: NgbModal,
    private dataExchangeService: DataExchangeService,
    private masterDataService: MasterDataService,
    private router: Router
  ) { }

  ngOnInit() {
    // Get value from SS.
    const searchCriteriaData = this.dataExchangeService.getDataFromSessionStorage('tw-scd');

    if (searchCriteriaData === undefined || searchCriteriaData === null) {
      // Re-route to Home page.
      this.router.navigate(['/']);
    }
    this.searchModel = searchCriteriaData.searchModel;
    this.currencyCode = this.searchModel.currencyCode;

    // TODO: From Resolver :
    this.amenityList = this.route.snapshot.data.message[0];
    this.primaryTagList = this.route.snapshot.data.message[1];

    if (!this.amenityList && !this.primaryTagList) {
      if (!this.amenityList) {
        this.amenityList = this.masterDataService.getLatestMasterData('AmenityList');
      }
      if (!this.primaryTagList) {
        this.primaryTagList = this.masterDataService.getLatestMasterData('primaryTagList');
      }
    }
    this.searchHotels(this.searchModel);


    // Subscribe to Currency change subject.
    this.rootScopeService.getCurrencyChangeSubject().subscribe(res => {
      this.searchModel.currencyCode = res;
      this.searchHotels(this.searchModel);
      this.currencyCode = res;
      const searchCriteriaDataOnCurChange = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
      const scData = {
        searchModel: this.searchModel,
        filtersApplied: searchCriteriaDataOnCurChange.filtersApplied
      };
      this.dataExchangeService.setDataInSessionStorage('tw-scd', scData);
    });

    this.rootScopeService.getCSSLayout().subscribe(resp => {
      this.cssLayout = resp;
    });

    const searchCriteriaDataTemp = {
      searchModel: this.searchModel,
      filtersApplied: false
     };
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaDataTemp);

      // This is used for currency dropdown changes.
    this.rootScopeService.setCurrencyChangeAllowedSubject(true);
  }

  onSearchClick(searchReq: any) {
    this.currentPage = 1;
    const searchCriteriaData = { searchModel: searchReq, filtersApplied: false };
    // Setting Search criteria in session storage
    this.dataExchangeService.setDataInSessionStorage('tw-scd',searchCriteriaData);
    this.searchHotels(searchReq);
  }
  searchHotels(searchReq) {
    searchReq = this.prepareSearchReq(searchReq);
    this.hotelService.getHotels(searchReq).subscribe(
      response => {
        this.products = response;
        this.products.partnerToList.forEach(element =>
          this.googleMapPartnerList.push({
            partnerName: element.partnerName,
            reviewBand: element.reviewBand,
            reviewCount: element.reviewCount,
            productDescription: element.minPriceProduct ? element.minPriceProduct.productDesc : null,
            originalPriceSelCur: element.origPriceSelCur,
            salePriceSelCur: element.salePriceSelCur,
            roomsLeft: element.roomsLeft,
            latitude: element.latitude,
            longitude: element.longitude,
            partnerImage: element.partnerImage,
            starRating: element.starRating,
            reviewScore: element.reviewScore,
            noOfNights: element.noOfNights,
            partnerAddress: element.partnerAddress,
          })
        );


        // this.partnerNames = this.products.partnerToList.map(partner=> ({ 'partnerName': partner.partnerName }) );
        this.totalResultsCount = this.products.totalResultCount;
        if (this.products.recPerPage != null) {
          this.recPerPage = this.products.recPerPage;
        }
        // Set selectedPage for Pagination
        if (this.products.selectedPage != null) {
          this.currentPage = this.products.selectedPage;
        }
        // Set Product amenities and ProductType names.
        if (this.products && this.products.partnerToList) {
          this.checkProductAmenities();
          this.setProductPrimaryTag();
        }
        if (searchReq.currencyCode) {
          this.currencyCode = searchReq.currencyCode;
        }
      },
      error => {
        throw error;
      }
    );
    this.setSortComponent(searchReq.sortBy);
  }

  prepareSearchReq(searchReq) {
    searchReq.currencyCode = this.rootScopeService.getSelectedCurrency();
    if (searchReq.sortBy === undefined) {
      searchReq.sortBy = 'RECOMMENDED';
      searchReq.order = 'ASC';
    }
    searchReq.pageNo = this.currentPage;
    if (searchReq && searchReq.selectedPartner) {
      searchReq.selectedPartner = undefined;
    }
    return searchReq;
  }

  checkProductAmenities() {
    _.forEach(this.products.partnerToList, product => {
      product['amenities'] = [];
      if(product.topAmenities!==undefined && product.topAmenities!==null){
        let amenitiesArray = product.topAmenities.split(',');
      _.forEach(amenitiesArray, amenity => {
        let amenityFound = _.find(this.amenityList, [
          'amenityId',
          parseInt(amenity)
        ]);
        if (amenityFound) {
          product['amenities'].push(amenityFound);
        }
      });
      }
    });
  }

  setProductPrimaryTag() {
    _.forEach(this.products.partnerToList, product => {
      // product['primaryTag'];
      let primaryTag = _.find(this.primaryTagList, [
        'primaryTagId',
        product.primaryTag
      ]);
      if (primaryTag) {
        product['primaryTag'] = primaryTag;
      }
    });
  }

  /**
   * Function to set Products & pagination data when search is initiated form Filters.
   *
   * @param data Search response emitted from Filters.
   *
   */
  onFilterClick(data) {
    this.products = data.products;
    this.showPagination = data.isPaginationNotVisible;
    this.currentPage = 1;
    this.totalResultsCount = this.products.totalResultCount;
    if (this.products.recPerPage != null) {
      this.recPerPage = this.products.recPerPage;
    }
    if (this.products.selectedPage != null) {
      this.currentPage = this.products.selectedPage;
    }
    if (this.products && this.products.partnerToList) {
      this.checkProductAmenities();
      this.setProductPrimaryTag();
    }
  }

  onViewRoomsClick(product) {

    // To create a session Id while moving to hotel details page(another tab)
    this.sessionID = this.dataExchangeService.createSessionID();

    const searchCriteriaData = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    const searchModel: HotelSearchModel = searchCriteriaData.searchModel;
    if(searchModel.filters){
      searchModel.filters = [];
    }
    this.currencyCode = searchModel.currencyCode;
    if (product.minPriceProduct !== null && product.minPriceProduct !== undefined) {
      const selectedPartner = {
        partnerId: product.partnerId,
        productTOList: [
          {
            productId: product.minPriceProduct.productId,
            productRatePlanToList: [
              {
                productRatePlanId:
                  product.minPriceProduct.minPriceRatePlan.productRatePlanId,
                selectedRoomCount: searchModel.noOfRooms
              }
            ]
          }
        ]
      };
      searchModel.selectedPartner = selectedPartner;
    }
    this.dataExchangeService.setDataInLocalStorage(this.sessionID + '-detail-tw-scd', searchModel);
  }

  sortTypes = [
    {
      sortType: 'RECOMMENDED',
      languageCode: 'recommended',
      isActive: true,
      isSort: false
    },
    {
      sortType: 'STAR_RATING',
      languageCode: 'hotel_star_rating',
      isActive: false,
      isSort: false
    },
    {
      sortType: 'GUEST_RATING',
      languageCode: 'guest_rating',
      isSort: false,
      isActive: false
    },
    {
      sortType: 'LOWEST_PRICE',
      languageCode: 'lowest_price',
      isSort: false,
      isActive: false
    }
  ];

  setSortComponent(sortType) {
    _.forEach(this.sortTypes, sortDetails => {
      if (sortDetails.sortType === sortType) {
        sortDetails.isActive = true;
      } else {
        sortDetails.isActive = false;
      }
    });
  }
  onSortClick(sortType) {
    // let sortBy =  this.translate.instant(category) === 'HOTEL STAR RATING' ? 'STAR_RATING' :  this.translate.instant(category);
    // this.sortTypes[0].isActive = false;
    _.forEach(this.sortTypes, sortDetails => {
      if (sortDetails.sortType === sortType.sortType) {
        sortDetails.isActive = true;
      } else {
        sortDetails.isActive = false;
      }
    });
    if (
      this.dataExchangeService.getDataFromSessionStorage('tw-scd') !== undefined ||
      this.dataExchangeService.getDataFromSessionStorage('tw-scd').searchModel !== undefined
    ) {
      this.searchModel = this.dataExchangeService.getDataFromSessionStorage('tw-scd').searchModel;
    }

    this.searchModel.sortBy = sortType.sortType;
    this.searchModel.order = sortType.isSort ? 'ASC' : 'DESC';
    this.searchModel.pageNo = 1;
    if (this.searchModel.currencyCode === undefined) {
      this.searchModel.currencyCode = this.rootScopeService.getSelectedCurrency();
    }
    sortType.isSort = !sortType.isSort;
    this.hotelService.getHotels(this.searchModel).subscribe(
      response => {
        this.products = response;
        this.totalResultsCount = this.products.totalResultCount;
        if (this.products.recPerPage != null) {
          this.recPerPage = this.products.recPerPage;
        }
        if (this.products.selectedPage != null) {
          this.currentPage = this.products.selectedPage;
        }

        if (this.products && this.products.partnerToList) {
          this.checkProductAmenities();
          this.setProductPrimaryTag();
        }
      },
      error => {
        throw error;
      }
    );
    // Setting Search criteria in Session Storage
    const searchCriteriaData = {
      searchModel: this.searchModel,
      filtersApplied: true
    };
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);
  }

  /**
   * This function is called when clicking on page number for pagination.
   * @param page Page number from paginaton component.
   */
  searchResults(page) {
    // Get searchCriteria for Pagination from session storage
    const searchCriteria = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    // Get searchCriteria for Pagination

    this.searchModel = searchCriteria.searchModel;
    this.searchModel.pageNo = page;
    this.currentPage = page;

    // Setting Search criteria in session storage
    const searchCriteriaData: SearchCriteria = {
      searchModel: this.searchModel,
      filtersApplied: true
    };
    // Setting Search criteria in session storage
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);
    this.searchHotels(this.searchModel);
  }
  // filter by khalid

  openFilter() {
    let dropFilter = document.getElementById('dropFilter');
    dropFilter.classList.toggle('show')
  }
  closeFilter() {
    let closeFilter = document.getElementById('dropFilter');
    closeFilter.classList.remove('show');
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  open(content, MODAL) {
    const Modal_Class = MODAL;
    this.modalService
      .open(content, {
        ariaLabelledBy: 'modal-basic-title',
        windowClass: Modal_Class
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }
}
