import { RootScopeService } from './../services/rootscope.service';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { HotelService } from "../services/hotel.service";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class PartnerResolver implements Resolve<any> {

    constructor(private rootScopeService: RootScopeService){

    }
    
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        return this.rootScopeService.getPartnerTypes();
    }

}