
import { RootScopeService } from './../services/rootscope.service';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from "@angular/router";
import { HotelService } from "../services/hotel.service";
import { Injectable } from "@angular/core";
import { forkJoin } from "rxjs";
@Injectable({
    providedIn: 'root'
})
export class HotelSearchResolver implements Resolve<any> {

    constructor(private rootScopeService: RootScopeService){

    }

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        let amenities =  this.rootScopeService.getAmenities();
        let primaryList =  this.rootScopeService.getPrimaryTagMaster();
        return forkJoin(amenities, primaryList);
    }

}