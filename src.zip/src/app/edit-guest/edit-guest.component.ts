import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';

import {
  NgbModal,
  ModalDismissReasons,
  NgbModalOptions,
  NgbActiveModal
} from '@ng-bootstrap/ng-bootstrap';

import { ProductOrder } from '../model/product-order.model';
import { OrderItem } from '../model/order-item.model';

import { Guest } from '../model/guest.model';

import { OrderService } from '../services/order.service';

import * as _ from 'lodash';
import { Product } from '../model/product.model';

@Component({
  selector: 'edit-guest',
  templateUrl: './edit-guest.component.html',
  styleUrls: ['./edit-guest.component.scss'],
  providers: [OrderService],
  encapsulation: ViewEncapsulation.None
})
export class EditGuestComponent implements OnInit {
  @Input() orderItem;
  @Input() orderNumber;
  editGuestForm: FormGroup;
  submitted = false;
  maxRoomOccupancy: number = 4; // need to pull partner service.
  lodash = _;
  errorBoolean = false;
  errorBooleanFirstName = false;
  guestTypesOptions = [
    { value: 'ADULT', desc: 'Adult' },
    { value: 'CHILD', desc: 'Child' }
  ];
  constructor(
    public modelReference: NgbActiveModal,
    private formBuilder: FormBuilder,
    private orderService: OrderService
  ) {}

  ngOnInit() {
    this.editGuestForm = this.formBuilder.group({});
    for (
      let guestCount = 0;
      guestCount < this.orderItem.guest.length;
      guestCount++
    ) {
      this.editGuestForm.addControl(
        'firstName' + guestCount,
        new FormControl(
          this.orderItem.guest[guestCount].firstName,
          Validators.compose([this.noWhitespaceValidator])
        )
      );
      this.editGuestForm.addControl(
        'lastName' + guestCount,
        new FormControl(
          this.orderItem.guest[guestCount].lastName,
          Validators.compose([this.noWhitespaceValidator])
        )
      );
      this.editGuestForm.addControl(
        'guestType' + guestCount,
        new FormControl(
          this.orderItem.guest[guestCount].guestType,
          Validators.compose([Validators.required])
        )
      );
    }
    /*
     * other guests, loop
     */
    for (
      let guestCount = this.orderItem.guest.length;
      guestCount < this.maxRoomOccupancy;
      guestCount++
    ) {
      this.editGuestForm.addControl(
        'firstName' + guestCount,
        new FormControl('', Validators.compose([]))
      );
      this.editGuestForm.addControl(
        'lastName' + guestCount,
        new FormControl(null)
      );
      this.editGuestForm.addControl(
        'guestType' + guestCount,
        new FormControl()
      );
    }
  }
  getFirstError(control, guest) {
    return this.submitted && this.editGuestForm.get(control + guest).errors;
  }

  getFirstErrorMessage(control, guest) {
    return this.editGuestForm.get(control + guest).errors.whitespace;
  }
  getGuestErrorLastName(control, firstName, guest) {
    const name = this.editGuestForm.get(firstName + guest).value;
    if (name !== '') {
      this.editGuestForm
        .get(control + guest)
        .setValidators([Validators.required]);
      this.editGuestForm.get(control + guest).updateValueAndValidity();
      if (this.editGuestForm.get(control + guest).errors) {
        this.errorBoolean = true;
      } else {
        this.errorBoolean = false;
      }
    }
    return this.submitted && this.editGuestForm.get(control + guest).errors;
  }

  getGuestErrorMessageLastName(control, firstName, guest) {
    const name = this.editGuestForm.get(firstName + guest).value;
    if (name === '') {
      this.confirmEdit();
    } else {
      return this.editGuestForm.get(control + guest).errors.required;
    }
  }

  getGuestErrorFirstName(lastName, firstName, guest) {
    const name = this.editGuestForm.get(lastName + guest).value;
    if (name !== '' && name != null) {
      this.editGuestForm
        .get(firstName + guest)
        .setValidators([Validators.required]);
      this.editGuestForm.get(firstName + guest).updateValueAndValidity();
      if (this.editGuestForm.get(firstName + guest).errors) {
        this.errorBooleanFirstName = true;
      } else {
        this.errorBooleanFirstName = false;
      }
    }
    return this.submitted && this.editGuestForm.get(firstName + guest).errors;
  }

  getGuestErrorMessageFirstName(lastName, firstName, guest) {
    const name = this.editGuestForm.get(lastName + guest).value;
    if (name === '' && name != null) {
      this.confirmEdit();
    } else {
      return this.editGuestForm.get(firstName + guest).errors.required;
    }
  }
  getGuestErrorMessageGuestType(lastName, guestType, guest){
    const name = this.editGuestForm.get(lastName + guest).value;
    if (name === '' && name != null) {
      this.confirmEdit();
    } else {
      return this.editGuestForm.get(guestType + guest).errors.required;
    }
  }
  
  noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { whitespace: true };
  }
  confirmEdit() {
    this.submitted = true;
    if (
      this.editGuestForm.invalid ||
      this.errorBoolean === true ||
      this.errorBooleanFirstName === true
    ) {
      return;
    }
    const modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.orderNumber;
    modifiedOrder.orderStatus = 'MODIFIED';
    modifiedOrder.orderItems = [];

    const orderItem: OrderItem = new OrderItem();
    orderItem.orderItemId = this.orderItem.orderItemId;
    orderItem.product = new Product();
    orderItem.product.productId = this.orderItem.product.productId;

    orderItem.ratePlanId = this.orderItem.ratePlanId;

    orderItem.guest = [];
    for (let guestCount = 0; guestCount < this.maxRoomOccupancy; guestCount++) {
      if (
        this.editGuestForm.get('firstName' + guestCount).value !== '' &&
        this.editGuestForm.get('lastName' + guestCount).value !== ''
      ) {
        const roomOccupant = new Guest();
        if (guestCount < this.orderItem.guest.length) {
          if (this.orderItem.guest[guestCount].guestId) {
            roomOccupant.guestId = this.orderItem.guest[guestCount].guestId;
          }
        }
        roomOccupant.firstName = this.editGuestForm.get(
          'firstName' + guestCount
        ).value;
        roomOccupant.lastName = this.editGuestForm.get(
          'lastName' + guestCount
        ).value;
        roomOccupant.guestType = this.editGuestForm.get(
          'guestType' + guestCount
        ).value;
        orderItem.guest.push(roomOccupant);
      }
    }
    orderItem.changeType = 'EDIT_GUEST';
    modifiedOrder.orderItems.push(orderItem);

    console.log(modifiedOrder);
    debugger;
    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        console.log('modified order ', orderDetails);
        this.modelReference.close('success');
      },
      error => {
        console.log('error while getting order details : ', error);
      }
    );
  }
}
