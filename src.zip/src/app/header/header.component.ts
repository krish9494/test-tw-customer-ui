import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

import { HeaderService } from '../services/header.service';
import { AppConstants } from '../constants/app.contstants';
import { RootScopeService } from '../services/rootscope.service';
import { environment } from '../../environments/environment';
import { GeoLocationService } from '../services/geo-location.service';

declare let $: any;

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component-ltr.scss', './header.component-rtl.scss']
})
export class HeaderComponent implements OnInit {
  baseImgUrl: String = environment.IMAGE_LOC;
  allLanguages: any;
  selectedLanguage: Object;
  allCurrencies: any;
  selectedCurrency: any;
  showCurrency: boolean;
  currencyMessage: String;
  cssLayout: String = 'ltr';
  isCurrencyChangeAllowed: boolean = true;
  showCountryListPopUp = false;
  geolocation: any;
  showGeoLocation = false;
  @ViewChild('currencyBtn') currencyBtn: ElementRef;
  @ViewChild('currencyDrpDwn') currencyDrpDwn: ElementRef;

  constructor(
    private translate: TranslateService,
    private headerService: HeaderService,
    private rootScopeService: RootScopeService,
    /* private geoLocation: Geolocation */ private geoLocationService: GeoLocationService,
    private renderer: Renderer2
  ) {}

  ngOnInit() {
    this.currencyMessage = AppConstants.CURRENCY_MESSAGE;
    let language = window.navigator.language;
    let currency = 'AED';
    if (language) {
      language = language.split('-')[0];
    } else {
      language = 'en';
    }
    this.translate.setDefaultLang(language + '_us');
    this.headerService.getLanguages().subscribe(
      response => {
        this.allLanguages = response;
        for (let l of this.allLanguages) {
          if (l.languageCode == language) {
            this.selectedLanguage = l;
            this.translate.use(l.languageCode + '_' + l.countryCode);
          }
        }
      },
      error => {
        throw error;
      }
    );

    this.rootScopeService.getCSSLayout().subscribe(resp => {
      this.cssLayout = resp;
    });

    this.rootScopeService
      .isCurrencyChangeAllowed()
      .subscribe((isCurrencyChangeAllowed: boolean) => {
        this.isCurrencyChangeAllowed = isCurrencyChangeAllowed;
      });

    // window.navigator.geolocation.getCurrentPosition(post => {
    this.getLocationCurrencyDetails();
    // });
  }

  changeLanguage(selectedLanguage: any) {
    this.selectedLanguage = selectedLanguage;
    this.translate.use(
      selectedLanguage.languageCode + '_' + selectedLanguage.countryCode
    );
    let contentDirection = selectedLanguage.textDirection;
    $('body').css('direction', contentDirection);
    this.rootScopeService.setCSSLayout(contentDirection);
  }
  changeCurrency(selectedCurrency: any) {
    this.selectedCurrency = selectedCurrency;
  }

  toggleCurrency() {
    this.showCurrency = !this.showCurrency;
    this.renderer.listen('body', 'click', (e: Event) => {
      if (this.currencyBtn && this.currencyDrpDwn) {
        if (
          e.target !== this.currencyBtn.nativeElement &&
          e.target !== this.currencyDrpDwn.nativeElement
        ) {
          this.showCurrency = false;
        }
      }
    });
  }

  onSelection(selectObject) {
    this.selectedCurrency = selectObject;
    this.rootScopeService.setSelectedCurrencyCode(selectObject.currencyCode);
    this.showCurrency = false;
  }

  getLocationCurrencyDetails() {
    this.geoLocationService.getLocation().subscribe(resp => {
      this.geolocation = resp;
      this.headerService.getCurrencies().subscribe(
        response => {
          this.allCurrencies = response;
          for (let curr of this.allCurrencies) {
            if (curr.countryCode === resp.country_code) {
              this.selectedCurrency = curr;
              this.rootScopeService.setSelectedCurrencyCode(
                this.selectedCurrency.currencyCode
              );
            }
          }
          if (!this.selectedCurrency) {
            this.showCountryListPopUp = true;
          }
        },
        error => {
          throw error;
        }
      );
      this.rootScopeService.setCountryCode(resp.country_code);
    });
  }
}
