export const AppConstants = {
    FILTER_API_ENDPOINT: 'http://52.76.200.40:8280/search/product/filtercount',
    PARTNER_REVIEW_API_ENDPOINT: 'http://52.76.200.40:8280/partners/',
    PARTNER_AMENITIES_ENDPOINT: 'http://52.76.200.40:8180/amenities',
    PARTNER_TYPE_ENDPOINT: 'http://52.76.200.40:8180/productTypes',
    CURRENCY_MESSAGE: "Select your preferred Currency",
    PARTNER_POLICIES_ENDPOINT: 'http://52.76.200.40:8280/partner',
    PARTNER_SERVICE_ENDPOINT: 'http://52.76.200.40:8280',
    CONFIG_SERVICE_URL: 'http://52.76.200.40:8180/configuration/',
    MASTER_SERVICE_URL: 'http://52.76.200.40:8180/',
    PCI_BOOKING_URL: 'https://service.pcibooking.net',
    PCI_BOOKING_CAPTURE_CARD: '/api/payments/capturecard',
    TRIPWORLD_SANDBOX: 'tripworld_sandbox',
    GENERATE_PCI_ACCESS_TOKEN: 'http://52.76.200.40:8989/admin/pcibooking/token',
    ORDER_STATUS_MODIFIED: 'MODIFIED'
}