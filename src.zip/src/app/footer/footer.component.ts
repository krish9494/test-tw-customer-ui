import { Component, OnInit } from '@angular/core';
import { environment } from '../../environments/environment';
import { RootScopeService } from '../services/rootscope.service';


@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component-ltr.scss','./footer.component-rtl.scss']
})
export class FooterComponent implements OnInit {

  baseImgUrl: String = environment.IMAGE_LOC;
  
  constructor(private rootScopeService: RootScopeService) { }

  cssLayout: String = 'ltr';

  ngOnInit() {
    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });
  }


}
