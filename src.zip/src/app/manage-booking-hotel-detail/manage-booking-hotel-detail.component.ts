import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-booking-hotel-detail',
  templateUrl: './manage-booking-hotel-detail.component.html',
  styleUrls: ['./manage-booking-hotel-detail.component.scss']
})
export class ManageBookingHotelDetailComponent implements OnInit {

  lat: number = 25.219999;
  lng: number = 55.321918;
  
  constructor() { }

  ngOnInit() {
  }

}
