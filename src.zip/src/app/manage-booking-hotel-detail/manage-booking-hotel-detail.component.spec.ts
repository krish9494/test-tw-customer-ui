import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageBookingHotelDetailComponent } from './manage-booking-hotel-detail.component';

describe('ManageBookingHotelDetailComponent', () => {
  let component: ManageBookingHotelDetailComponent;
  let fixture: ComponentFixture<ManageBookingHotelDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageBookingHotelDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBookingHotelDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
