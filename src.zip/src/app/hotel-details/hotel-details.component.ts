import { MasterDataService } from './../shared/services/master-data.service';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { HotelSearchModel } from '../model/hotel-search-model';
import { HotelService } from '../services/hotel.service';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { RouterService } from '../services/router.service';
import { NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { RootScopeService } from '../services/rootscope.service';
import { environment } from '../../environments/environment';
import { PartnerPolicyService } from '../services/policy.service';
import {
  NgxGalleryOptions,
  NgxGalleryImage,
  NgxGalleryAnimation
} from 'ngx-gallery';
import { HotelSearchRequestModel } from '../model/hotel-search-request-model';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SearchCriteria } from '../model/search-criteria.model';
import * as moment from 'moment';
import { GoogleMapPartner } from '../model/google-map-partner.model';
import { ResponseContentType } from '@angular/http';
import { Faq } from '../model/Faq';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/filter';
import { DataExchangeService } from '../services/data-exchange.service';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-hotel-details',
  templateUrl: './hotel-details.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: [
    './hotel-details.component-ltr.scss',
    './hotel-details.component-rtl.scss'
  ]
})
export class HotelDetailsComponent implements OnInit {

  constructor(
    private hotelService: HotelService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private routerService: RouterService,
    private rootScopeService: RootScopeService,
    private partnerPolicyService: PartnerPolicyService,
    private modalService: NgbModal,
    private dataExchangeService: DataExchangeService,
    private masterDataService: MasterDataService,
    private toastr: ToastrService
  ) { }
  galleryOptions: NgxGalleryOptions[];
  galleryImages: NgxGalleryImage[] = [];
  sessionID: any;
  cssLayout: String = 'ltr';
  productDetails: any;
  partnerAncillaryList: any[];
  searchModel: HotelSearchModel;
  partnerId: any;
  baseImgUrl: String = environment.IMAGE_LOC;
  lodash = _;
  selectedRatePlans: any = {};
  faqList: Faq[] = [];
  faqCategory = [];
  faqCategoryResponce: any;
  partnerReview: any = {
    guestReviews: []
  };
  recentReview: any = {
    guestReviews: []
  };
  currentPage = 0;
  pageSize = 4;
  aroundDetails: any = {};
  showMoreAmenities = false;
  currencyCode;
  hotelDetailsModel;
  searchDisplay;
  // Pet Policy variable
  petLangCode: any;
  petFacCode: any;
  petsAllowed: boolean;
  // Internet Policy variables.
  intLangCode: any;
  intConType: any;
  intPriceCode: any;
  intAvailable: boolean;
  intPrice: any;
  isIntChargeSpecified: boolean;
  // Parking Policy cariables.
  parkPriceCode: any;
  parkPrice: any;
  parkAvailable: boolean;
  intParkCode: any;
  isParkChargeSpecified: boolean;
  intParkResType: any;
  parkFacList = [];
  // Check in out policy
  partnerCheckIn: string;
  partnerCheckout: string;
  prtnrChckInAgLmt: string;

  childPolicies = {};
  cotPolicies = [];
  extraBedPolicies = [];
  public isCollapsedRoomAmenities = new Map();
  public bedTypes = new Map();
  googleMapPartnerList: GoogleMapPartner[] = [];
  closeResult: string;
  private searchCriteria: SearchCriteria;
  public today = moment(new Date());
  totalRoomCount = 0;
  nightStays: number;
  faqResponses;
  faqDetailResponse$: Observable<any>;
  public hideRuleContent: boolean[] = [];
  whatIsAround: any[] = [];
  selectedProductClicked = false;

  ngOnInit() {
    const params = this.activatedRoute.snapshot.params;

    // Set Route param which is PartnerId.
    this.partnerId = params.id;

    this.activatedRoute.queryParams
      .filter(qParams => qParams.sessionId)
      .subscribe(qParams => {
        this.sessionID = qParams.sessionId;
      });

    // To check the searchCriteria is present in LocalStorage or SessionStorage
    if (this.dataExchangeService.getDataFromLocalStorage(this.sessionID + '-detail-tw-scd')) {
      const searchCriteria = {
        searchModel: this.dataExchangeService.getDataFromLocalStorage(this.sessionID + '-detail-tw-scd')
      };
      this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteria);
      // Removing the localStorage item once the data is set in session storage.
      localStorage.removeItem(this.sessionID + '-detail-tw-scd');
    } else if (this.dataExchangeService.getDataFromSessionStorage('tw-scd')) {

      // Do nothing,as it iis being assigned the same below.
    } else {

      // Re-route to home page if searchCriteria is not present.
      this.router.navigate(['/']);
    }

    const searchCriteriaData = this.dataExchangeService.getDataFromSessionStorage('tw-scd');

    if (searchCriteriaData) {
      this.hotelDetailsModel = searchCriteriaData.searchModel;
      this.searchDisplay = this.dataExchangeService.getDataFromSessionStorage('tw-sdd');
      this.nightStays = this.hotelDetailsModel.nightStays;
      this.searchCriteria = searchCriteriaData;
      this.setGuestsDisplay();
      this.getHotelDetails(this.partnerId);
      this.loadAroundDetails();
      this.rootScopeService.getCurrencyChangeSubject().subscribe(res => {
        this.hotelDetailsModel.currencyCode = res;
        this.currencyCode = res;
      });

      this.rootScopeService.getCSSLayout().subscribe(resp => {
        this.cssLayout = resp;
      });

      this.recentReview = {
        guestReviews: []
      };
      this.hotelService.getHotelReviews(this.partnerId).subscribe(
        resp => {
          let partnerInfo: any = resp;
          this.recentReview.overAllReview = _.filter(
            partnerInfo.partnerReviewAggregateList,
            { isOverAllComment: 'Y' }
          )[0];
          this.recentReview.otherReviews = _.filter(
            partnerInfo.partnerReviewAggregateList,
            { isOverAllComment: 'N' }
          );
        },
        error => {
          throw error;
        }
      );
      this.getGuestReviews(true);
      this.rootScopeService.setCurrencyChangeAllowedSubject(true);

      this.galleryOptions = [
        {
          width: '100%',
          height: '500px',
          imagePercent: 100,
          thumbnailsColumns: 8,
          thumbnailsRemainingCount: true,
          imageAnimation: NgxGalleryAnimation.Slide
        },

        // max-width 800
        {
          breakpoint: 800,
          width: '100%',
          height: '600px',
          thumbnailsPercent: 20,
          thumbnailsMargin: 20,
          thumbnailMargin: 20
        },
        // max-width 400
        {
          breakpoint: 400,
          preview: false
        }
      ];
    }
  }

  loadAroundDetails() {
    this.hotelService.getAroundDetails(this.partnerId).subscribe(
      resp => {
        this.aroundDetails = resp;
      },
      error => {
        throw error;
      }
    );
  }

  onSearchClick(data) {
    const searchCriteriaData = { searchModel: data, filtersApplied: false };
    // Setting Search criteria in session storage
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);

    this.routerService.navigationData = {
      products: data.products
    };
    this.router.navigate(['/hotel-search']);
  }
  getHotelDetails(partnerId: number) {
    this.hotelService
      .getHotelDetail(this.hotelDetailsModel, partnerId)
      .subscribe(response => {
        if (response === undefined || response === null) {
          return;
        }
        this.productDetails = response;
        this.partnerAncillaryList = this.productDetails.partnerAncillaryList;

        this.googleMapPartnerList.push({
          partnerName: response.partnerName,
          reviewBand: response.reviewBand,
          reviewCount: response.reviewCount,
          productDescription: response.selectedProduct ? response.selectedProduct.productDesc : '',
          originalPriceSelCur: response.selectedProduct ? response.selectedProduct.productRatePlanToList[0].origPriceSelCur : null,
          salePriceSelCur: response.selectedProduct ? response.selectedProduct.productRatePlanToList[0].salePriceSelCur : null,
          roomsLeft: response.selectedProduct ? response.selectedProduct.productRatePlanToList[0].roomsLeft : null,
          latitude: response.latitude,
          longitude: response.longitude,
          partnerImage: response.partnerImage,
          starRating: response.starRating,
          reviewScore: response.reviewScore,
          noOfNights: this.nightStays ? this.nightStays : null,
          partnerAddress: response.partnerAddress,
        });

        const amenityListMaster = this.masterDataService.getLatestMasterData('AmenityList');
        const primaryTagList = this.masterDataService.getLatestMasterData('primaryTagList');

        const primaryTag = _.find(primaryTagList, [
          'primaryTagId',
          this.productDetails.primaryTag
        ]);
        if (primaryTag) {
          this.productDetails.primaryTag = primaryTag;
        }

        _.forEach(this.productDetails.partnerAmenityList, partnerAmenity => {
          let amenityFound = _.find(amenityListMaster, [
            'amenityId',
            partnerAmenity.amenityId
          ]);
          if (amenityFound) {
            partnerAmenity.amenityMasterTO = amenityFound;
          }
        });
        _.forEach(this.productDetails.productTOList, product => {
          _.forEach(product.productRatePlanToList, ratePlan => {
            ratePlan['origPriceDisplay'] = ratePlan.origPriceSelCur;
            ratePlan['salePriceDisplay'] = ratePlan.salePriceSelCur;
            ratePlan.rooms = 0;
            if (ratePlan.rmCnclPolicy) {
              ratePlan['isBefore'] = this.isMlstnDtBfrTdy(ratePlan.rmCnclPolicy.custMileStoneDate);
            }
          });
          // assigning roomsSelected in product level as zero initially
          if (product) {
            product.roomsSelected = 0;
          }
          _.forEach(product.productAmenityList, productAmenity => {
            let amenityFound = _.find(amenityListMaster, [
              'amenityId',
              productAmenity.amenityId
            ]);
            if (amenityFound) {
              productAmenity.amenityMasterTO = amenityFound;
            }
          });
          // Bed Types
          if (product.bedDetails) {
            let bedTypesList = product.bedDetails.split('/');
            _.forEach(bedTypesList, bedType => {
              let bedObj = { type: String, count: String };
              bedObj.type = bedType.substring(0, 2);
              bedObj.count = bedType.substring(3);
              let bedObjList = this.bedTypes.get(product.productId);
              if (!bedObjList) {
                bedObjList = [];
              }
              bedObjList.push(bedObj);
              this.bedTypes.set(product.productId, bedObjList);
            });
          }
        });
        _.forEach(this.productDetails.partnerGalleryImages, propertyImage => {
          const imagePathOriginal =
            this.baseImgUrl + '/' + propertyImage.originalImage;
          const obj = {
            small: imagePathOriginal,
            medium: imagePathOriginal,
            big: imagePathOriginal
          };
          this.galleryImages.push(obj);
        });
        if (this.productDetails.whatIsNearBy) {
          this.whatIsAround = this.productDetails.whatIsNearBy.split('\n');
        }
      });
  }

  addPlan(product, productDetails, ratePlan, roomsSelected) {
    const noOfRooms = parseInt(roomsSelected, 10);

    if (this.selectedProductClicked) {
      this.selectedRatePlans = {};
      this.selectedRatePlans[ratePlan.productRatePlanId] = {
        product: product,
        productDetails: productDetails,
        ratePlan: ratePlan,
        rooms: noOfRooms
      };
    } else {
      ratePlan.rooms = 0;
      this.calculateRoomsSelected(product);
      if (noOfRooms <= (product.roomsAvailable - product.roomsSelected)) {
        ratePlan.rooms = noOfRooms;
        product.roomsSelected += noOfRooms;
        this.selectedRatePlans[ratePlan.productRatePlanId] = {
          product: product,
          productDetails: productDetails,
          ratePlan: ratePlan,
          rooms: noOfRooms
        };
        if (roomsSelected > 0) {
          ratePlan['origPriceDisplay'] = ratePlan.origPriceSelCur * roomsSelected;
          ratePlan['salePriceDisplay'] = ratePlan.salePriceSelCur * roomsSelected;
        } else {
          ratePlan['origPriceDisplay'] = ratePlan.origPriceSelCur * 1;
          ratePlan['salePriceDisplay'] = ratePlan.salePriceSelCur * 1;
        }
      }
      else if(roomsSelected === ''){
        delete this.selectedRatePlans[ratePlan.productRatePlanId];
      } 
      else {
        this.toastr.error('', 'Number of rooms selected exceeds than total room count available.', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
        //TODO: Add logic to reset the Drop Down.
      }
    }
  }
  // to calculate total no of rooms selected from a product
  calculateRoomsSelected(product) {
    product.roomsSelected = 0;
    product.productRatePlanToList.forEach(ratePlan => {
      product.roomsSelected += ratePlan.rooms;
    });
  }

  calTotalNoOfRooms() {
    let totalRoomCount = 0;
    _.forOwn(this.selectedRatePlans, (ratePlan) => {
      totalRoomCount += ratePlan.rooms;
    });
    return totalRoomCount;
  }

  arrayFill(roomLeftCount) {
    let count = roomLeftCount;
    if (roomLeftCount > 9) {
      count = 9;
    }
    return Array(count).fill(0).map((x, i) => {
      return i + 1;
    });
  }

  selectProduct() {
    if (Object.keys(this.selectedRatePlans).length === 0) {
      this.toastr.error('', 'Please select a room!', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    } else if (this.calTotalNoOfRooms() <= 9) {
      this.routerService.navigationData = {
        selectedRatePlans: this.selectedRatePlans
      };
      this.router.navigate(['/booking']);
    } else {
      this.toastr.error('', 'Number of rooms selected exceeds than 9.', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    }
  }
  onSelectedProductBook(product, ratePlan) {
    this.selectedProductClicked = true;
    this.selectedRatePlans = {};
    this.addPlan(
      product,
      this.productDetails,
      ratePlan,
      this.hotelDetailsModel.noOfRooms
    );
    this.selectProduct();
  }

  public beforeChange($event: NgbTabChangeEvent) {
    if ($event.nextId === 'guest-reviews-info') {
      this.partnerReview = {
        guestReviews: []
      };
      this.hotelService.getHotelReviews(this.partnerId).subscribe(resp => {
        let partnerInfo: any = resp;
        this.partnerReview.overAllReview = _.filter(
          partnerInfo.partnerReviewAggregateList,
          { isOverAllComment: 'Y' }
        )[0];
        this.partnerReview.otherReviews = _.filter(
          partnerInfo.partnerReviewAggregateList,
          { isOverAllComment: 'N' }
        );
      });
      this.getGuestReviews(false);
    }
  }
  public getGuestReviews(isRecentReview) {
    let request = {
      currentPage: this.currentPage,
      pageSize: this.pageSize
    };
    this.hotelService.getHotelGuestReviews(this.partnerId, request).subscribe(
      resp => {
        let partnerInfo: any = resp;
        if (isRecentReview) {
          this.recentReview.guestReviews = this.partnerReview.guestReviews.concat(
            partnerInfo.orderReviewList
          );
        } else {
          this.partnerReview.guestReviews = this.partnerReview.guestReviews.concat(
            partnerInfo.orderReviewList
          );
        }
      },
      error => {
        throw error;
      }
    );
  }

  public loadMoreReviews() {
    this.currentPage = this.currentPage + 1;
    this.getGuestReviews(false);
  }
  public getPolicies() {
    let hotelSearchReq: HotelSearchModel = new HotelSearchModel();
    hotelSearchReq.productIds = [];
    this.productDetails.productTOList.forEach(product => {
      hotelSearchReq.productIds.push(product.productId);
    });
    if (!hotelSearchReq.productIds.length) {
      hotelSearchReq.productIds.push(
        this.productDetails.selectedProduct.productId
      );
    }
    this.partnerPolicyService
      .getPartnerPolicies(this.partnerId, hotelSearchReq)
      .subscribe(
        policies => {
          if (policies.petPolicy !== undefined || policies.petPolicy !== null) {
            this.setPetPolicyCode(policies.petPolicy);
          }
          if (policies.internetPolicy !== undefined || policies.internetPolicy !== null) {
            this.setInternetPolicyCode(policies.internetPolicy);
          }
          if (policies.parkingPolicy !== undefined || policies.parkingPolicy !== null) {
            this.setParkingPolicyCode(policies.parkingPolicy);
          }
          if (policies.checkInOutPolicy !== undefined || policies.checkInOutPolicy !== null) {
            this.setCheckInOutPolicy(policies.checkInOutPolicy);
          }
        }
      );
  }

  public setCheckInOutPolicy(checkInPolicy: any) {
    if (checkInPolicy !== undefined || checkInPolicy !== null) {
      this.partnerCheckIn = checkInPolicy.checkInBetween;
      this.partnerCheckout = checkInPolicy.checkOutBetween;
      this.prtnrChckInAgLmt = checkInPolicy.checkInAgeLimit;
    }
  }
  public setPetPolicyCode(petPolicy: any) {
    if (petPolicy.isAvailToGuest.langCode === 'no') {
      this.petsAllowed = false;
      this.petLangCode = 'policy.pet.no';
    } else {
      this.petsAllowed = true;
      this.petLangCode = petPolicy.chargesApplicable
        ? 'policy.pet.yur.charged'
        : 'policy.pet.yur.free';
      if (petPolicy.petFacility !== undefined || petPolicy.petFacility !== null) {
        this.petFacCode =
          petPolicy.petFacility.langCode === 'pb'
            ? 'policy.pet.pb'
            : 'policy.pet.pt';
      }
    }
  }
  public setInternetPolicyCode(intPolicy: any) {
    if (intPolicy.isAvailToGuest.langCode === 'no') {
      this.intAvailable = false;
      this.isIntChargeSpecified = false;
      this.intLangCode = 'policy.internet.no';
    } else if (
      intPolicy.isAvailToGuest.langCode === 'yf' ||
      intPolicy.isAvailToGuest.langCode === 'ync' ||
      intPolicy.isAvailToGuest.langCode === 'yp'
    ) {
      this.intAvailable = true;
      this.isIntChargeSpecified = false;
      this.intLangCode =
        'policy.internet.' +
        intPolicy.isAvailToGuest.langCode +
        '.' +
        intPolicy.connLocation.langCode;
      this.intConType = 'policy.internet.conn.' + intPolicy.connType.langCode;
    }
    if (intPolicy.isAvailToGuest.langCode === 'yp') {
      this.intPrice = intPolicy.price;
      this.isIntChargeSpecified = true;
      this.intPriceCode =
        'policy.internet.' +
        intPolicy.isAvailToGuest.langCode +
        '.price.' +
        intPolicy.pricePer.langCode;
      this.intConType = 'policy.internet.conn.' + intPolicy.connType.langCode;
    }
  }
  public setParkingPolicyCode(parPolicy: any) {
    if (parPolicy.isAvailToGuest.langCode === 'no') {
      this.parkAvailable = false;
      this.isParkChargeSpecified = false;
      this.intParkCode = 'policy.parking.no';
    } else if (
      parPolicy.isAvailToGuest.langCode === 'yf' ||
      parPolicy.isAvailToGuest.langCode === 'ync' ||
      parPolicy.isAvailToGuest.langCode === 'yp'
    ) {
      this.parkAvailable = true;
      this.isParkChargeSpecified = false;
      this.intParkCode = 'policy.parking.' + parPolicy.isAvailToGuest.langCode +
        '.' +
        parPolicy.parType.langCode +
        '.' +
        parPolicy.parLocation.langCode;
      this.intParkResType =
        'policy.parking.res.' + parPolicy.reservation.langCode;
    }
    if (parPolicy.isAvailToGuest.langCode === 'yp') {
      this.isParkChargeSpecified = true;
      this.parkPrice = parPolicy.price;
      this.parkPriceCode =
        'policy.parking.' +
        parPolicy.isAvailToGuest.langCode +
        '.price.' +
        parPolicy.pricePer.langCode;
      this.intParkResType =
        'policy.parking.res.' + parPolicy.reservation.langCode;
    }
    this.parkFacList = [];
    for (let fac of parPolicy.parFacList) {
      this.parkFacList.push('policy.parking.fac.' + fac.langCode);
    }
  }
  collapseRoomAmenities(productId) {
    this.isCollapsedRoomAmenities.set(
      productId,
      !this.isCollapsedRoomAmenities.get(productId)
    );
  }

  open(content) {
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg', windowClass: 'checkLocation' })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  private setGuestsDisplay() {
    if (
      this.searchCriteria !== undefined &&
      this.searchCriteria.searchModel !== undefined
    ) {
      this.searchDisplay.guests =
        this.searchCriteria.searchModel.noOfAdults +
        ' Guest(s) in ' +
        this.searchCriteria.searchModel.noOfRooms +
        ' Room(s)';
    }
  }

  public isMlstnDtBfrTdy(mileStoneDate: moment.Moment): boolean {
    const today = moment(new Date());
    if (today.isBefore(mileStoneDate)) {
      return true;
    }
    else {
      return false;
    }
  }

  fetchFAQs() {
    this.faqList = [];
    this.faqCategory = [];
    this.rootScopeService.getConfiguration('FAQ').subscribe(faqs => {
      this.faqCategoryResponce = faqs;
      this.faqCategoryResponce.forEach(element => {
        this.faqCategory.push(element.configName);
      });
    });
    this.rootScopeService.getFaqs(this.partnerId).subscribe(
      (data: string) => {
        this.faqResponses = data;
        this.faqResponses.forEach(element => {
          this.faqCategory.push(element.category);
        });
        this.faqCategory = this.faqCategory.filter(
          (el, i, a) => i === a.indexOf(el)
        );
        this.faqResponses.forEach(response => {
          this.faqCategory.forEach(element => {
            if (element === response.faqCategory) {
              //need to make the drropdown value as selected by this category//this code is needed
              // this.faqList.push({
              //   question: response.faqQuestion,
              //   answer: response.faqAnswer
              // });
            }
          });
        });
      },
      error => {
        console.log(error);
      }
    );
  }

  toggle(index) {
    // toggle based on index
    this.hideRuleContent[index] = !this.hideRuleContent[index];
  }

  faqChanged(faqCategory) {
    this.faqList = [];
    this.faqResponses.forEach(response => {
      if (faqCategory === response.faqCategory) {
        this.faqList.push({
          question: response.faqQuestion,
          answer: response.faqAnswer
        });
      }
    });
  }
}
