import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';

@Component({
  selector: 'app-faqs',
  templateUrl: './faqs.component.html',
  styleUrls: ['./faqs-ltr.component.scss','./faqs-rtl.component.scss']
})
export class FaqsComponent implements OnInit {

  cssLayout: String = 'ltr';
  public isCollapsed = true;
  public toggleDDIcon = true;
  
  constructor(private rootScopeService : RootScopeService) { } 

  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }

  clickToToggle() {
    this.isCollapsed = !this.isCollapsed;
    this.toggleDDIcon = !this.toggleDDIcon;
  }

}
