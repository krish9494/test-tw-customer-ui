import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us-ltr.component.scss', './contact-us-rtl.component.scss']
})
export class ContactUsComponent implements OnInit {

  cssLayout: String = 'ltr';

  constructor(private rootScopeService : RootScopeService) { } 
  
  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }


}
