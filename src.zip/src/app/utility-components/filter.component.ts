import { Component, OnInit, ViewChild, HostListener, ViewEncapsulation, Input, Output, EventEmitter, ElementRef, AfterViewInit } from '@angular/core';
import {HotelSearchModel} from '../model/hotel-search-model';
import {HotelService} from '../services/hotel.service';
import {NgbDateAdapter, NgbDateStruct, NgbDateNativeAdapter, NgbInputDatepicker, NgbCalendar, NgbDate} from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import * as moment from 'moment';
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Observable, of } from 'rxjs';
import {debounceTime, distinctUntilChanged, map, tap, switchMap, catchError} from 'rxjs/operators';
import { LocationService } from '../services/location.service.';
import { SearchFilterService } from '../services/search-filters.service';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css', './filter.component.scss'],
})

export class FilterComponent implements OnInit,AfterViewInit {

  @Input() data: any;
  @Input() attributeName: any;
  @Input() message: any;
  @Input() autofocus: boolean;
  @Output() selection = new EventEmitter<any>();
  @ViewChild('searchCurrency') searchCurrency:ElementRef;
  items: any;

  constructor(private hotelService: HotelService, private route: ActivatedRoute, private searchFilterService: SearchFilterService, private elementRef:ElementRef) {
  }

  onSearchChange(value: any){
    if(!value){
      this.items = this.data;
    }
    let self = this;
    this.items = _.filter(this.data, function(item){
                  return item[self.attributeName].toLowerCase().includes(value.toLowerCase());
                });
  }
  ngOnInit() {
    this.items = this.data;
  }

  onDropDownSelection(selectedData){
    this.selection.emit(selectedData);
  }
  ngAfterViewInit(): void {
    if(this.autofocus){
      this.searchCurrency.nativeElement.focus();
    }
  }
}