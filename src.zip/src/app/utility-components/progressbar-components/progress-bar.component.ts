import { Component, EventEmitter, Input, Output, OnInit } from "@angular/core";


@Component({
  selector: 'progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.scss'],
})

export class ProgressBarComponent implements OnInit {

  @Input() value: any;
  @Input() totalValue: any;
  item: any = [];
  totalProgressBar = 5;
  
  constructor() {
  }

  ngOnInit() {
    let percentValue = 0;
    if(this.value){
      percentValue = this.value/this.totalValue*100;
    }
    let eachProgressValue = 100/this.totalProgressBar;

    for(let i=0; i<this.totalProgressBar; i++){
      if(percentValue - eachProgressValue>0){
        percentValue = percentValue - eachProgressValue;
        this.item.push({progressValue: 100});
      } else if(percentValue - eachProgressValue === 0){
        this.item.push({progressValue: 0});
      } else {
        let val = percentValue/eachProgressValue*100;
        this.item.push({progressValue: val});
        percentValue = 0;
      }
    }
  }

}


