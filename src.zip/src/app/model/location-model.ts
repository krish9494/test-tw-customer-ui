export interface LocationModel {
    code: String;
    value: String;
    displayText: String;
    locationType: String;
    arptCode: String;
    cityCode: String;
    countryCode: String;
    stateCode: String;
    areaCode: String;
    propertyId: String;
}