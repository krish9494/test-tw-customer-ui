
export class Country {
    continentId: number;
    countryCode: string;
    countryId: number
    countryName: string;
    currencyCode: string;
    languageCode: string;
}