import {ProductOrder} from './product-order.model';

export class Orders {
  orders: ProductOrder[];
  totalPages: number;
  currentPage: number;
  totalOrders: number;
}
