export class GoogleMapPartner {
    partnerName?: string;
    reviewBand?: string;
    reviewCount?: string;
    productDescription?: string;
    originalPriceSelCur?: string;
    salePriceSelCur?: string;
    roomsLeft?: string;
    latitude: number;
    longitude: number;
    partnerImage?: string;
    starRating?: string;
    reviewScore?: string;
    noOfNights?: number;
    partnerAddress?: string;
}
