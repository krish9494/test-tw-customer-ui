export class HotelSearchModel {
  partnerId: string;
  productSearchText: string;
  checkIn: string;
  checkOut: string;
  noOfAdults: number;
  noOfChildren: number;
  noOfInfants: number;
  nightStays: number;
  noOfRooms: string;
  adultCnt: string;
  childCnt: string;
  childAges: string[];
  currencyCode: string;
  location: HotelLocation;
  sortBy: string;
  order: string;
  filters: Filters[];
  pageNo: string;
  selectedPartner: any;
  productIds: number[];
}
/* 

export class SelectedPartner{
  partnerId : number;
 // productTOList : [];
} */

export class Filters {
  filterType: string;
  filterTypeLanCode: string;
  filters: FilterSearch[];
}

export class HotelLocation {
  code: string;
  cityId: string;
  value?: string;
  type?: string;
  cityCode?: string;
  countryCode?: string;
  areaCode?: string;
  displayText?: string;
}

export class FilterSearch {
  searchCode: string;
  languageCode: string;
  count: string;
}