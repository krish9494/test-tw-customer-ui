export class Address {
  addressLines: string[];
  city: string;
  state: string;
  country: string;
}
