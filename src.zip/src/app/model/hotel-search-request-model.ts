import { LocationModel } from "./location-model";

export interface HotelSearchRequestModel {

    locationTo: LocationModel;
    checkInDate: String;
    checkOutDate: String;
    noOfRooms: number;
    adultCnt: number;
    childCnt: number;
    childAges: Array<number>;
    currencyCode: String;
    sortBy: String;
    order: String;
    filters: Array<Object>;
    pageNo: number;
}
