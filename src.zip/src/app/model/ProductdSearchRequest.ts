export class ProductdSearchRequest{
    public productIds:any[];

}
