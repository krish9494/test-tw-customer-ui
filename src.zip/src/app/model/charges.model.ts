export class Charges {
  partnerChargeId: number;
  partnerId: number;
  uiKey: string;
  uiKeyValue: string;
  chargeCode: string;
  chargeDescription: string;
  included: string;
  chargeUnit: string;
  chargeValue: number;
  amount: number;
  calcAmtSelCur: number;
  calcAmtBaseCur: number;
}
