import {Address} from './address.model';

export class Customer {
    customerId:number;
  title: Title;
  firstName: string;
  lastName: string;
  isMainTraveller: boolean;
  dateOfBirth: string;
  address: Address;
  email: string;
  phone: string;
username:string;
cognitoUsername:string;
password:string;
confirmPassword:string;
preferredLanguage:string;
}

export class Title{
  code : string;
  name : string;
}

export class Parameters {
    name: string;
    value: string;
}