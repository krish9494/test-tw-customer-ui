export interface Faq {
    question: string;
    answer: string;
}