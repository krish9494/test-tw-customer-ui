import { ProductRatePlan } from "./pricing-common.model";
import { PartnerImages } from "./partner-images.model";

export class Product {
  productId: number;
  productDesc: string;
  bedDetails?: string;
  size?: number;
  sizeUnit?: string;
  productAmenityList: any[];
  productQty: number;
  minOccupancy: number;
  maxOccupancy: number;
  productRatePlanToList: ProductRatePlan[];
  noOfBeds?: number;
  bedDescription?: string;
  partnerImagesTOS?: PartnerImages[];
}
