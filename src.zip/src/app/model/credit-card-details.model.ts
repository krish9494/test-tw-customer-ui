export class CreditCardDetails {
  cardType: string;
  cardNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: number;
  cardHolderName: string;
}
