export class Language {
    countryCode: string;
    languageCode: string;
    textDirection: string;
}