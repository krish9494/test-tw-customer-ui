export class Tax {
  taxId: number;
  taxCode: string;
  uiKey: string;
  uiKeyValue: string;
  taxDescription: string;
  included: boolean;
  taxUnit: string;
  taxValue: number;
  countryCode: string;
  calcAmtSelCur: number;
  calcAmtBaseCur: number;
  taxType: string;
}
