export interface ConfigMaster {
        configId: number;
        configType: string;
        configName: string;
        configValue: string;
    }