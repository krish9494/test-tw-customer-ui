import { Guest } from './guest.model';
import { Product } from './product.model';

export class OrderItem {
  product: Product;
  ratePlanId: number;
  adultCount: number;
  childCount: number;
  smokingRoom: string;
  guest: Guest[];
  specialRequest: string;
  cancelmilStoneDate: Date;
  freeCancellation: boolean;
  cancelmilStoneCharges: number;
  cancelmilStoneTime: string;
  changeType: string;
  orderItemQty?: number;
  orderItemId: number;
  cnclchrgAftrmlStnBase?: number;
  cnclchrgAftrmlStnSell?: number;
  cnclchrgBfrmlStnBase?: number;
  cnclchrgBfrmlStnSell?: number; 

}
