import {CreditCardDetails} from './credit-card-details.model';
import {Customer} from './customer.model';
import { Partner } from '../model/partner.model';
import {SearchRequest} from './search-request.model';
import {OrderItem} from './order-item.model';

export class ProductOrder {
  orderNumber: string;
  orderDate: Date;
  partnerId: number;
  cardDetail: CreditCardDetails;
  customer: Customer;
  orderStatus: string;
  orderAmount: number;
  totalNights: number;
  baseCurrency: string;
  orderCurrency: string;
  searchRequest: SearchRequest;
  travelType: string;
  orderItems: OrderItem[];
  partner: Partner;
  orderCancellationReason: string;
  chargeValue: number;
  saleTaxValue: number;
  saleValue: number;
  cancelOrderId: number;
  accessToken?: string;
  productOrder?: OrderItem[];
}
