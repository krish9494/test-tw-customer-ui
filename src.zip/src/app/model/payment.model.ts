import {CreditCardDetails} from './credit-card-details.model';

export class Payment {
  paymentMode: string;
  cardDetails: CreditCardDetails;
}
