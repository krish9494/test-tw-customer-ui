
export class Filter {
    searchCode: string;
    languageCode:string;
    count: number;
    displayOrder: number;
    checked?:boolean=false;
    brandName?:string;
}

export class FilterType {
    filterType: string;
    filterTypeLanCode: string;
    filters:Filter[]
}