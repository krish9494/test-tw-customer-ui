export class PartnerImages {
    productId?: number;
    isGalleryImage?: string;
    includeInPartnerGallery?: string;
    isMainImage?: string;
    originalImage?: string;
    thumbnailImage?: string;
    mediumImage?: string;
}