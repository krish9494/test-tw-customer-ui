export class Guest {
  guestId: number;
  firstName: string;
  lastName: string;
  dateOfBirth: Date;
  gender: string;
  guestType: string;
}
