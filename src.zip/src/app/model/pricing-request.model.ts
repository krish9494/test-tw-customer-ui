import { Product } from './pricing-common.model';


export class PricingRequest {
    checkIn: string;
    checkOut: string;
    noOfRooms: number;
    adultCnt: number;
    childCnt: number;
    currencyCode: string;
    selectedPartner: SelectedPartner;
}

export class SelectedPartner {
    partnerId: number;
    productTOList: Product[];
}
