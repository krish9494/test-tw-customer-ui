
export class SearchRequest {
    checkIn:string;
    checkOut:string;
    noOfRooms:string;
    adultCnt:number;
    childCnt:number;
    childAges:number[];
    currencyCode:string;
    nightStays:number;
}
