export class SearchCriteria {
  searchModel:any;
  filtersApplied?:boolean=false;
}
