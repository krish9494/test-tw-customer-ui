export interface ReviewScore {
  rating: number;
  ratingType: string;
  reviewCounts: number;
}
