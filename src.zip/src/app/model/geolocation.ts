export interface GeoLocation {
  area_code: number;
  city: string;
  continent_code: string;
  country: string;
  country_code: string;
  country_code3: string;
  ip: number;
  latitude: number;
  longitude: number;
  region: string;
  timezone: string;
}
