	export class Product {   
        productId: number;
        productDesc: string;
        productQty: number;
        minOccupancy: number;
        maxOccupancy: number;
        productRatePlanToList: ProductRatePlan[];
    }
	
	export class ProductRatePlan {
        productRatePlanId: number;
        productRatePlanMasterTO: RatePlanMaster;
        origPriceSelCur: number;
        salePriceSelCur: number;
        offerPriceSelCur: number;
        origPriceBaseCur: number;
        salePriceBaseCur: number;
        offerPriceBaseCur: number;
        productPricingToList: ProductPricing[];
        chargesToList: Charges[];
        taxes: any[];
        appliedOfferTo: AppliedOffer;
        selectedRoomCount: number;
    }
	
	export class RatePlanMaster {
        productRatePlanMasterId: number;
        productRatePlanMasterDesc: string;
        toc: string;
    }
	
	export class ProductPricing {
        productPricingId: number;
        productBasePrice: number;
        productCurrentQty: number;
        productPriceDate: Date;
    }
	
	export class Charges {
        chargeId: number;
        partnerChargeId: number;
        partnerId: number;
        uiKey: string;
        uiKeyValue: string;
        chargeCode: string;
        chargeDescription: string;
        included: boolean;
        chargeUnit: string;
        chargeValue: number;
        amount: number;
        countryCode: string;
        cityCode: string;
        calcAmtSelCur: number;
        calcAmtBaseCur: number;
        taxes: any[];
        chargeType: string;
    }
	
	export class AppliedOffer {
        offerId: number;
        offerCode: string;
        offerDesc: string;
        offerValue: number;
        offerValueUnit: string;
        noOfDaysEarly: number;
        noOfNightsFrom: number;
        noOfNightsTo: number;
        hoursToCheckIn: number;
        promoCode: string;
        travellerType: string;
        partnerId: number;
        productId: number;
        productRatePlanId: number;
        priority: number;
    }