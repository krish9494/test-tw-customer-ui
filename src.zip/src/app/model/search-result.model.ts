import {ReviewScore} from './review-score.model';

export interface SearchResult {
  productId: string;
  name: string;
  price: number;
  rating: number;
  longLat: string;
  distanceFromCityCentre: string;
  reviewScore: ReviewScore;
  image: string;
}
