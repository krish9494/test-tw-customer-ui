export class Currency {
    currencyCode: string;
    currencyName: string;
    currencyShortName: string;
    countryCode: string;
}