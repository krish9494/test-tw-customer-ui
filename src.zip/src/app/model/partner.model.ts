import {
  Product,
  ProductRatePlan,
  RatePlanMaster,
  ProductPricing,
  AppliedOffer
} from './pricing-common.model';
import { Charges } from './charges.model';

export class Partner {
  partnerId: number;
  partnerName: string;
  partnerAddress: string;
  partnerLocation: string;
  partnerHqAddress: string;
  partnerCurrencyCode: string;
  origPriceSelCur: number;
  salePriceSelCur: number;
  offerPriceSelCur: number;
  chargesSelCur: number;
  taxesSelCur: number;
  origPriceBaseCur: number;
  salePriceBaseCur: number;
  offerPriceBaseCur: number;
  chargesBaseCur: number;
  taxesBaseCur: number;
  productTOList: Product[];
  exchangeRate: number;
  checkInTime: string;
  checkOutTime: string;
  bookingWithoutCC: string;
  latitude: number;
  longitude: number;
  chargesToList: Charges;
  starRating: number;
  soldOut: boolean;
}
