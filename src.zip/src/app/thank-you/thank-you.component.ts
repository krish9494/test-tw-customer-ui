import { Component, OnInit } from '@angular/core';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { RouterService } from '../services/router.service';


import { OrderService } from '../services/order.service';
import { PartnerService } from '../services/partner.service';

import { ProductOrder } from '../model/product-order.model';
import { Charges } from '../model/charges.model';
import { environment } from '../../environments/environment';
import { RootScopeService } from '../services/rootscope.service';

import * as _ from 'lodash';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { MasterDataService } from '../shared/services/master-data.service';
import { GoogleMapPartner } from '../model/google-map-partner.model';

@Component({
	selector: 'app-thank-you',
	templateUrl: './thank-you.html',
	styleUrls: ['./thankyou.scss'],
	providers: [OrderService, PartnerService]
})
export class ThankYouComponent implements OnInit {

	lat: number = 51.678418;
	lng: number = 7.809007;
	public isCollapsed = true;
	baseImgUrl: String = environment.IMAGE_LOC;
	order: ProductOrder;
	orderAterBooking: any;
	charges: Charges[];
	finalPrice: number;
	partner: any;
	productRatePlans: any = [];
	productDetails: any;
	lodash = _;
	productDetailsArray: any = [];
	closeResult: string;
	isFormLoaded = false;
	googleMapPartnerList: GoogleMapPartner[] = [];
	public bedTypes = new Map();
	constructor(private router: Router, private orderService: OrderService, private route: ActivatedRoute,
		private partnerService: PartnerService, private routerService: RouterService,
		private rootScopeService: RootScopeService, private modalService: NgbModal, private masterService: MasterDataService) {
	}

	ngOnInit() {
		window.scrollTo(0, 0);
		console.log("thank you component loaded! on load");
		// order , productOrderDetails
		const orderDetails = this.routerService.navigationData;
		this.orderService.getOrderDetails(orderDetails.orderNumber).subscribe((order: ProductOrder) => {
			this.isFormLoaded = true;
			this.order = order;
			this.updateOrder();
			this.partner = this.order.partner;
			if (orderDetails === undefined) {
				// this to be replaced by Popup or manage gracefully. need to discuss			  
				alert("order session lost. Please check your booking in manage bookings.");
				// customer id will ome from cognito login
				this.routerService.navigationData = {
					customerId: 78
				};
				this.router.navigate(['/manage-booking']);
			}
		}
		);
		//this.order.orderNumber='20190730132621110';

		// this.productDetailsArray[0] = this.productDetails

		// Object.keys(orderDetails.selectedRatePlans).forEach((ratePlanId: string) => {
		// 	console.log(ratePlanId, orderDetails.selectedRatePlans[ratePlanId]);
		// 	this.productRatePlans.push(orderDetails.selectedRatePlans[ratePlanId]);
		// 	let ratePlan = orderDetails.selectedRatePlans[ratePlanId];
		// 	this.partner = ratePlan.productDetails;
		// });

		this.rootScopeService.setCurrencyChangeAllowedSubject(false);
		this.getMapView();

	}

	updateOrder() {
		const amenityListMaster = this.masterService.getLatestMasterData('AmenityList');
		this.order.productOrder = _.uniqBy(this.order.orderItems, 'ratePlanId');
		this.order.productOrder.forEach(item => {
			const orderItem = _.filter(this.order.orderItems, { ratePlanId: item.ratePlanId });
			item.orderItemQty = orderItem.length;
		});

		// Set bedTypes
		this.order.orderItems.forEach(orderItem => {

			// Each orderItem
			if (orderItem.product !== undefined && orderItem.product.bedDetails !== undefined) {
				const bedTypesList = orderItem.product.bedDetails.split('/');
				bedTypesList.forEach(bedType => {
					// Each bed type from 'bedDetails' field.
					let bedObjList = this.bedTypes.get(orderItem.product.productId);
					if (!bedObjList) {
						bedObjList = [];
					}
					bedObjList.push({
						type: bedType.substring(0, 2),
						count: bedType.substring(3)
					});
					this.bedTypes.set(orderItem.product.productId, bedObjList);
				});
			}

			//Set Room Amenities
			if (orderItem.product !== undefined && orderItem.product.productAmenityList !== undefined) {
				orderItem.product.productAmenityList.forEach(productAmenity => {
					const amenityFound = _.find(amenityListMaster, ['amenityId', productAmenity.amenityId]);
					if (amenityFound) {
						productAmenity.amenityMasterTO = amenityFound;
					}
				});
			}
			Object.assign(orderItem, {
				amenityToggle: true,
				adultGuestCount: orderItem.guest.filter(g => g.guestType === 'ADULT').length,
				childGuestCount: orderItem.guest.filter(g => g.guestType === 'CHILD').length
			});
		});
	}

	viewBooking(orderNumber) {
		this.router.navigate(['/view-booking/' + orderNumber]);
	}

	printConfirmation() {
		this.router.navigate(['print/booking-confirmation']);
	}

	open(content) {
		this.modalService.open(content, { windowClass: 'HotelViewMap', ariaLabelledBy: 'modal-basic-title', size: 'lg' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		}, (reason) => {
			this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
		});
	}
	private getDismissReason(reason: any): string {
		if (reason === ModalDismissReasons.ESC) {
			return 'by pressing ESC';
		} else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
			return 'by clicking on a backdrop';
		} else {
			return `with: ${reason}`;
		}
	}
	getMapView() {
		this.googleMapPartnerList.push({
			partnerName: this.partner.partnerName,
			latitude: this.partner.latitude,
			longitude: this.partner.longitude,
			partnerImage: this.partner.partnerImage,
			starRating: this.partner.starRating,
			partnerAddress:this.partner.partnerAddress,
		})
	}
}
