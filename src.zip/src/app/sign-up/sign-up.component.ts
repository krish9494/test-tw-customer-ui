import { Component, OnInit, ViewEncapsulation, ɵConsole } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl
} from '@angular/forms';

import {
  NgbModal,
  ModalDismissReasons,
  NgbModalConfig
} from '@ng-bootstrap/ng-bootstrap';

import { Title } from '../model/customer.model';
import { Customer, Parameters } from '../model/customer.model';
import { environment } from '../../environments/environment';

import { RootScopeService } from '../services/rootscope.service';
import { UserRegistrationService } from '../services/aws/user-registration.service';
import { UserLoginService } from '../services/aws/user-login.service';
import { UserParametersService } from '../services/aws/user-parameters.service';
import { ToastrService } from 'ngx-toastr';
import {
  CognitoCallback,
  LoggedInCallback,
  CognitoUtil,
  Callback
} from '../services/aws/cognito.service';
import { CustomerService } from '../services/customer.service';
import { GoogleAnalyticsEventsService } from '../google-analytics-events.service';
import { Router } from '@angular/router';

@Component({
  selector: 'sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up-ltr.component.scss', './sign-up-rtl.component.scss'],
  providers: [
    UserRegistrationService,
    UserLoginService,
    UserParametersService,
    CustomerService
  ],
  encapsulation: ViewEncapsulation.None
})
export class SignUpComponent
  implements OnInit, CognitoCallback, LoggedInCallback {
  baseImgUrl: String = environment.IMAGE_LOC;
  parameters: Array<Parameters> = [];
  errorMessage: string;
  modelReference: any;
  signupForm: FormGroup;
  submitted = false;
  awsErrorCode: string;
  signUpFlag = false;
  forgotPassFlag = false;
  resetPassword = false;
  isUserRegistered: boolean = false;
  switchTab = 'member-sign-in';
  userType: string = 'USERMODULE';
  pmsRegistertab: boolean = false;

  confirmAccountForm: FormGroup;
  confirmAccountFormsubmitted = false;

  signinForm: FormGroup;
  forgotPasswordform: FormGroup;
  signinSubmitted = false;
  isUserAuthenticated: boolean;
  authenticatedUser: Customer = null;
  closeResult: string;
  firstLoad: boolean = false;
  emailToRegister: string;
  loginAttempts = 0;
  firstName = new FormControl('', [Validators.required]);
  lastName = new FormControl('', [Validators.required]);
  username = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required]);

  password = new FormControl('', [
    Validators.required,
    Validators.minLength(7)
  ]);
  rePassword = new FormControl('', [
    Validators.required,
    Validators.minLength(7)
  ]);
  showError = false;
  showErrorText: string;
  constructor(
    private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private userRegistrationService: UserRegistrationService,
    private userLoginService: UserLoginService,
    private userParametersService: UserParametersService,
    private cognitoUtil: CognitoUtil,
    public customerService: CustomerService,
    public rootScopeService: RootScopeService,
    public googleAnalyticsEventsService: GoogleAnalyticsEventsService,
    private toastr: ToastrService,
    config: NgbModalConfig,
    private router: Router
  ) {
    config.backdrop = 'static';
  }

  ngOnInit() {
    this.initialForm();
    this.firstLoad = true;

    // for login
    console.log(
      'Checking if the user is already authenticated. If so, then redirect to the secure site'
    );
    this.userLoginService.isAuthenticated(this);
    this.userLoginService.isAuthenticatedPMS(this);
  }

  initialForm() {
    this.signupForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('[A-Za-z]*')]],
      lastName: ['', [Validators.required, Validators.pattern('[A-Za-z]*')]],
      email: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(7)]]
      // lastName: [
      //   "",
      //   Validators.compose([
      //     Validators.required,
      //     Validators.pattern("[a-zA-Z ]{2,30}")
      //   ])
      // ],
      // email: ["", [Validators.required, Validators.email]],
      // password: ["", [Validators.required, Validators.minLength(7)]]
    });

    this.signinForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
    this.forgotPasswordform = this.formBuilder.group({
      username: this.username,
      password: this.password,
      rePassword: this.rePassword,
      confirmationCode: ['']
    });
    this.confirmAccountForm = this.formBuilder.group({
      confirmationCode: [
        ''
        /*
         * , Validators.required,
         * Validators.pattern('[0-9]{6}')
         */
      ]
    });
  }

  open(content, { size: lg }, modelType) {
    this.modalService.dismissAll();
    this.isUserRegistered = false;
    this.resetPassword = false;
    this.forgotPassFlag = false;
    this.userType = 'USERMODULE';
    this.switchTab = 'member-sign-in';
    this.confirmAccountForm.reset();
    if (modelType === 'signUp') {
      this.submitted = false;
      this.signupForm.reset();
      this.signUpFlag = true;
    } else {
      this.signUpFlag = false;
      this.signinForm.reset();
    }
    this.modelReference = this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      size: 'lg'
    });
    this.modelReference.result.then(
      result => {
        this.closeResult = `Closed with: ${result}`;
        this.signinForm.reset();
      },
      reason => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      }
    );
  }

  changeTab(userType: string) {
    this.userType = userType;
    this.switchTab = userType === 'PMS' ? 'manage-property' : 'member-sign-in';
  }

  forgotPasswordTab() {
    this.isUserRegistered = false;
    this.forgotPassFlag = true;
    this.signinForm.reset();
    this.forgotPasswordform.reset();
    const memberSignInTabsElement  = document.querySelector('.nav.nav-pills.justify-content-start');
    memberSignInTabsElement.remove();
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  register(userType) {
    if (userType === 'PMS') {
      this.pmsRegistertab = true;
    } else {
      this.pmsRegistertab = false;
    }
    this.googleAnalyticsEventsService.emitEvent(
      'Register',
      'Register',
      'Register',
      10
    );
    this.submitted = true;
    if (this.signupForm.invalid) {
      console.log('invalid signup');
      this.toastr.error('', 'Invalid Sign Up', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
      return;
    }
    let user = new Customer();
    user.username = this.signupForm.get('email').value;
    user.password = this.signupForm.get('password').value;
    // user.preferredLanguage = this.selectedLanguage.languageCode;
    user.preferredLanguage = 'en';
    user.firstName = this.signupForm.get('firstName').value;
    user.lastName = this.signupForm.get('lastName').value;
    user.email = this.signupForm.get('email').value;

    this.errorMessage = null;
    this.userType = userType;
    this.userRegistrationService.register(user, userType, this);
  }

  onConfirmRegistration(userType) {
    console.log('conf acnt');
    console.log(userType);
    this.confirmAccountFormsubmitted = true;
    if (this.confirmAccountForm.invalid) {
      console.log('invalid confirm');
      return;
    }
    let confirmationCode = this.confirmAccountForm.get('confirmationCode')
      .value;
    this.errorMessage = null;
    this.userRegistrationService.confirmRegistration(
      this.emailToRegister,
      confirmationCode,
      userType,
      this
    );
  }

  // login
  onLogin(userType) {
    if (this.loginAttempts === 3) {
      this.toastr.error(
        '',
        'Password attempts exceeded. Kindly refresh the page',
        {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        }
      );
      return;
    }
    if (this.signinForm.invalid) {
      return true;
    }
    this.googleAnalyticsEventsService.emitEvent(
      'Sign In',
      'Sign In',
      'Sign In',
      10
    );
    this.firstLoad = false;
    this.authenticatedUser = new Customer();
    this.authenticatedUser.username = this.signinForm.controls.username.value;
    this.authenticatedUser.password = this.signinForm.controls.password.value;

    if (
      this.authenticatedUser.username == null ||
      this.authenticatedUser.password == null
    ) {
      this.awsErrorCode = 'header.signin.required';
      return;
    }
    this.errorMessage = null;
    this.userType = userType;
    this.userLoginService.authenticate(
      this.authenticatedUser.username,
      this.authenticatedUser.password,
      userType,
      this
    );
  }

  isLoggedIn(message: string, isLoggedIn: boolean, userType: string) {
    if (isLoggedIn) {
      console.log('isLoggedIn::LOGGED IN.......');
      this.userParametersService.getParameters(
        userType,
        new UserParameterCallback(this, this.cognitoUtil, userType, this.router)
      );
    }
  }

  logout() {
    this.authenticatedUser = null;
    this.rootScopeService.setAuthenticatedUser(this.authenticatedUser);
    this.userLoginService.logout(this.userType);
    this.isUserAuthenticated = false;
    this.router.navigate(['/']);
  }

  resendConfirmationCode(userType: string) {
    this.userRegistrationService.resendCode(
      this.forgotPassFlag
        ? this.forgotPasswordform.get('username').value
        : this.signupForm.get('email').value,
      this,
      userType
    );
  }

  forgotPassword(userType: string) {
    if (this.forgotPasswordform.get('username')) {
      this.userLoginService.forgotPassword(
        this.forgotPasswordform.get('username').value,
        this,
        userType
      );
    } else {
      this.toastr.error('', 'Plaese write a mail address.', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    }
  }

  confirmNewPassword(userType: string) {
    const userName = this.forgotPasswordform.get('username').value;
    const password = this.forgotPasswordform.get('password').value;
    const rePassword = this.forgotPasswordform.get('rePassword').value;
    if (!password || !rePassword) {
      return this.toastr.error('', 'Password should not be empty', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    }
    if (password !== rePassword) {
      return this.toastr.error('', 'Password should be same', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    }
    const securityCode = this.confirmAccountForm.get('confirmationCode').value;
    this.userLoginService.confirmNewPassword(
      userName,
      securityCode,
      password,
      this,
      userType
    );
  }

  // callback

  cognitoCallback(message: string, result: any, userType: string) {
    this.showError = false;

    if (message != null && message !== 'logedIn') {
      // error
      if (message === 'User is not confirmed.') {
        this.awsErrorCode = 'service.signin.aws.unconfirmedUser';
        this.toastr.error('', 'User is not confirmed.', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      } else if (message === 'User needs to set password.') {
        this.awsErrorCode = 'service.signin.aws.changePassword';
        this.toastr.error('', 'User needs to set password.', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      } else if (message === 'User does not exist.') {
        this.showError = true;
        this.showErrorText = 'User does not exist';
        this.toastr.error('', 'User does not exist', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      } else if (message === 'Incorrect username or password.') {
        this.showError = true;
        this.showErrorText = 'Incorrect username or password';
        this.toastr.error('', 'Incorrect username or password', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      } else if (message.includes('Security code send to')) {
        this.resetPassword = this.forgotPassFlag;
        this.isUserRegistered = true;
        this.pmsRegistertab = userType == 'USERMODULE' ? false : true;
        this.toastr.success('', message, {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      } else if (message === 'Password changed successfully.') {
        this.toastr.success('', message, {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
        this.modelReference.close();
      }
      else {
        this.toastr.error('', message, {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      }
      this.loginAttempts = this.loginAttempts + 1;
    } else {
      // success
      this.showError = false;
      this.toastr.success('', 'Successfully Logged In', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
      this.userParametersService.getParameters(
        userType,
        new UserParameterCallback(this, this.cognitoUtil, userType, this.router)
      );
      this.modelReference.close();
    }
  }

  cognitoSignupCallback(
    user: Customer,
    message: string,
    result: any,
    userType: string
  ) {
    if (message != null && message !== 'logedIn' && message !== 'registered') {
      // error
      if (this.errorMessage === 'User is not confirmed.') {
        this.toastr.error('', 'User is not confirmed.', {
          timeOut: 2000,
          closeButton: true,
          positionClass: 'toast-top-full-width'
        });
      }
      this.awsErrorCode = 'service.signup.aws.' + message;
      this.toastr.error('', message, {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    } else {
      // success
      this.isUserRegistered = true;
      this.emailToRegister = result.user.username;
      //create tw customer.
      user.title = new Title();
      user.title.code = '1'; // need to discuss
      if (userType === 'PMS') {
        this.customerService.createPMSCustomer(user).subscribe(
          (data: Customer) => {
            console.log(data);
            this.toastr.success('', 'Security code sent to your email.', {
              timeOut: 2000,
              closeButton: true,
              positionClass: 'toast-top-full-width'
            });
          },
          error => {
            console.log(error);
          }
        );
      }
      if (userType === 'USERMODULE') {
        this.customerService.createCustomer(user).subscribe(
          (data: Customer) => {
            console.log(data);
            this.toastr.success('', 'Security code sent to your email.', {
              timeOut: 2000,
              closeButton: true,
              positionClass: 'toast-top-full-width'
            });
          },
          error => {
            console.log(error);
          }
        );
      }
    }
  }

  cognitoConfirmAccountCallback(message: string, result: any) {
    if (message != null) {
      //error
      console.log('message: ' + message);
      this.awsErrorCode = 'service.confirm.aws.' + message;
      this.toastr.error('', message, {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
    } else {
      //success
      this.signinForm.reset();
      this.toastr.success('', 'Sign up successfully', {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      });
      this.isUserRegistered = false;
      this.isUserRegistered = true;
      this.modelReference.close();
    }
  }
}

export class UserParameterCallback implements Callback {
  constructor(
    public signUpComponent: SignUpComponent,
    public cognitoUtil: CognitoUtil,
    public userType: String,
    public router: Router
  ) {}

  callback() {}

  callbackWithParam(result: any) {
    this.signUpComponent.authenticatedUser = new Customer();
    this.signUpComponent.authenticatedUser.preferredLanguage = 'en';
    for (let count = 0; count < result.length; count++) {
      let parameter = new Parameters();
      parameter.name = result[count].getName();
      parameter.value = result[count].getValue();
      this.signUpComponent.parameters.push(parameter);
      if (parameter.name === 'name') {
        let customerName: Array<string> = parameter.value.split(' ');
        this.signUpComponent.authenticatedUser.firstName = customerName[0];
        this.signUpComponent.authenticatedUser.lastName = customerName[1];
      } else if (parameter.name === 'email') {
        this.signUpComponent.authenticatedUser.email = parameter.value;
      } else if (parameter.name === 'phone_number') {
        this.signUpComponent.authenticatedUser.phone = parameter.value;
      } else if (parameter.name === 'sub') {
        this.signUpComponent.authenticatedUser.cognitoUsername =
          parameter.value;
      }
    }
    if (!this.signUpComponent.firstLoad) {
      let param = new Parameters();
      param.name = 'cognito ID';
      param.value = this.cognitoUtil.getCognitoIdentity();
      this.signUpComponent.parameters.push(param);
    }
    this.signUpComponent.isUserAuthenticated = true;
    console.log(
      'user parameters: ',
      this.signUpComponent.parameters,
      this.signUpComponent.authenticatedUser
    );
    if (this.userType === 'USERMODULE') {
      this.signUpComponent.customerService
        .updateCustomer(this.signUpComponent.authenticatedUser)
        .subscribe(
          (data: Customer) => {
            this.signUpComponent.authenticatedUser = data;
            this.signUpComponent.rootScopeService.setAuthenticatedUser(
              this.signUpComponent.authenticatedUser
            );
          },
          error => {
            console.log(error);
          }
        );
    } else if (this.userType === 'PMS') {
      this.signUpComponent.customerService
        .createPMSCustomer(this.signUpComponent.authenticatedUser)
        .subscribe(
          (data: Customer) => {
            this.signUpComponent.authenticatedUser = data;
            this.signUpComponent.rootScopeService.setAuthenticatedUser(
              this.signUpComponent.authenticatedUser
            );
          },
          error => {
            console.log(error);
          }
        );
    }
  }
}
