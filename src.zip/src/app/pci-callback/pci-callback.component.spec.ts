import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PciCallbackComponent } from './pci-callback.component';

describe('PciCallbackComponent', () => {
  let component: PciCallbackComponent;
  let fixture: ComponentFixture<PciCallbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PciCallbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PciCallbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
