import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-pci-callback',
  templateUrl: './pci-callback.component.html',
  styleUrls: ['./pci-callback.component.scss']
})
export class PciCallbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // if (window.addEventListener) {
    //   window.addEventListener('callBackForPaymentGateway', this.test);
    // }
  }

  test(e) {
    console.log(e);
  }
}
