import {
  Component,
  OnInit,
  ViewChild,
  ViewEncapsulation,
  Input
} from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import * as moment from 'moment';
import {
  NgxGalleryOptions,
  NgxGalleryImage,
  NgxGalleryAnimation
} from 'ngx-gallery';

import { environment } from '../../environments/environment';
import { HotelService } from '../services/hotel.service';
import { OrderService } from '../services/order.service';

import { HotelSearchModel } from '../model/hotel-search-model';
import { ProductOrder } from '../model/product-order.model';
import { Partner } from '../model/partner.model';
import { OrderItem } from '../model/order-item.model';
import {ProductRatePlan } from '../model/pricing-common.model';
import { Product } from '../model/product.model';

@Component({
  selector: 'app-add-room',
  templateUrl: './add-room.component.html',
  styleUrls: ['./add-room.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [OrderService]
})
export class AddRoomComponent implements OnInit {
  lodash = _;
  @Input() order;
  moment = moment;

  productDetails: any;
  galleryImages: NgxGalleryImage[] = [];
  baseImgUrl = environment.IMAGE_LOC;
  modalAddRoom: any;
  currencyCode;
  public bedTypes = new Map();
  constructor(
    public modelReference: NgbActiveModal,
    private hotelService: HotelService,
    private orderService: OrderService
  ) {}

  ngOnInit() {
    // productTOList should not be required... as of now required by partnerDetails service.
    // commented code of lodash functionality will be removed once the new code is tested  and fully fine.

    let hotelDetailsModel = {
      checkIn: this.moment(this.order.searchRequest.checkIn).format(
        'YYYY-MM-DD'
      ),
      checkOut: this.moment(this.order.searchRequest.checkOut).format(
        'YYYY-MM-DD'
      ),
      noOfRooms: this.order.searchRequest.noOfRooms,
      adultCnt: this.order.searchRequest.adultCnt,
      childCnt: this.order.searchRequest.childCnt,
      currencyCode: this.order.searchRequest.currencyCode,
      selectedPartner: {
        partnerId: this.order.partner.partnerId,
        productTOList: [
          {
            productId: this.order.orderItems[0].product.productId,
            productRatePlanToList: [
              {
                productRatePlanId: this.order.orderItems[0].ratePlanId,
                selectedRoomCount: 1
              }
            ]
          }
        ]
      }
    };
    this.currencyCode = this.order.searchRequest.currencyCode;
    this.hotelService.getHotelDetail(hotelDetailsModel,this.order.partner.partnerId).subscribe(response => {
      this.productDetails = response;

      let amenityListMaster = JSON.parse(localStorage.getItem('AmenityList'));
      let primaryTagList = JSON.parse(localStorage.getItem('primaryTagList'));
      
      //this.productDetails.primaryTag
      // let primaryTag = _.find(primaryTagList, [
      //   'primaryTagId',
      //   this.productDetails.primaryTag
      // ]);
      // if (primaryTag) {
      //   this.productDetails.primaryTag = primaryTag;
      // }

      const self = this;
      const primaryTag = primaryTagList.find((primaryTag) => {
        return primaryTag.primaryTagId === self.productDetails.primaryTag;
      });

      if (primaryTag) {
        this.productDetails.primaryTag = primaryTag;
      }
     
      // Setting Amenity master for Partner Amenities.
      if (this.productDetails.partnerAmenityList) {
        this.productDetails.partnerAmenityList.forEach(partnerAmenity => {
          const amenityFound = amenityListMaster.find((amenity) => {
            return parseInt(amenity.amenityId, 10) === parseInt(partnerAmenity.amenityId, 10);
          });
          if (amenityFound) {
            console.log('Partner amenityFound:',amenityFound);
              partnerAmenity.amenityMasterTO = amenityFound;
          }
        });
      }

      if(this.productDetails.productTOList){
        this.productDetails.productTOList.forEach(product => {
          if(product.maxNoOfAdult){
            Object.assign(product, {
              maxNoOfAdultArr:new Array(product.maxNoOfAdult)
            });
          }
          if(product.maxNoOfChild){
            Object.assign(product, {
              maxNoOfChildArr:new Array(product.maxNoOfChild)
            });
          }

          // Mapping Prices to display
          product.productRatePlanToList.forEach(ratePlan => {
            ratePlan['origPriceDisplay'] = ratePlan.origPriceSelCur;
            ratePlan['salePriceDisplay'] = ratePlan.salePriceSelCur;

            // Checking if MSD of cancellation policy has already been crossed by TODAY.
            if(ratePlan.rmCnclPolicy){
              ratePlan['isBefore'] = this.isMlstnDtBfrTdy(ratePlan.rmCnclPolicy.custMileStoneDate);
            }
          });

          // Setting Amenity Master for Product Amenities.
          product.productAmenityList.forEach(productAmenity => {
            const amenityFound = amenityListMaster.find((amenity)=>{
              return parseInt(amenity.amenityId, 10) === parseInt(productAmenity.amenityId, 10);
            });
            if (amenityFound) {
              productAmenity.amenityMasterTO = amenityFound;
            }
          });

          // Bed Types
          if (product.bedDetails) {
            let bedTypesList = product.bedDetails.split('/');
            bedTypesList.forEach(bedType => {
              let bedObj = { type: String, count: String };
              bedObj.type = bedType.substring(0, 2);
              bedObj.count = bedType.substring(3);
              let bedObjList = this.bedTypes.get(product.productId);
              if (!bedObjList) {
                bedObjList = [];
              }
              bedObjList.push(bedObj);
              this.bedTypes.set(product.productId, bedObjList);
            });
          }
        });
      }
      
      // Setting Gallery Images.
      if (this.productDetails.propertyImageList){
          this.productDetails.propertyImageList.forEach(propertyImage => {
            let imagePath = this.baseImgUrl + '' + propertyImage.imagePath + '.jpg';
            let obj = {
              small: imagePath,
              medium: imagePath,
              big: imagePath
            };
            this.galleryImages.push(obj);
          });
      }
    });
  }

  addRoom(selectedRatePlan) {
    let modifiedOrder = new ProductOrder();
    modifiedOrder.orderNumber = this.order.orderNumber;
    modifiedOrder.searchRequest = this.order.searchRequest;
    modifiedOrder.searchRequest.checkIn = this.moment(
      this.order.searchRequest.checkIn
    ).format('YYYY-MM-DD');
    modifiedOrder.searchRequest.checkOut = this.moment(
      this.order.searchRequest.checkOut
    ).format('YYYY-MM-DD');
    modifiedOrder.orderStatus = 'MODIFIED';
    modifiedOrder.orderItems = [];
    modifiedOrder.partnerId = this.order.partner.partnerId;
    modifiedOrder.orderCurrency = this.order.orderCurrency;
    let orderItem: OrderItem = new OrderItem();
    orderItem.product = new Product();
    orderItem.product.productId = selectedRatePlan.productId;
    orderItem.ratePlanId = selectedRatePlan.productRatePlanId;
    orderItem.changeType = 'ADD_ROOM';
    modifiedOrder.orderItems.push(orderItem);

    this.orderService.modifyOrder(modifiedOrder).subscribe(
      orderDetails => {
        this.order = orderDetails;
        this.modelReference.dismiss(this.order);
      },
      error => {
        console.log('error while getting order details : ', error);
      }
    );
  }

  /**
   * Function checks if MSD is before today or Not.
   * @param mileStoneDate MSD of the cancellation policy.
   */
  public isMlstnDtBfrTdy(mileStoneDate: moment.Moment):boolean {
    const today = moment(new Date());
    if (today.isBefore(mileStoneDate)) {
      return true;
    }
    else {
      return false;
    }
  }
}
