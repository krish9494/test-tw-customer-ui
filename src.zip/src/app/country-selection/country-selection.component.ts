import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {NgbModal, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { CountryService } from '../services/country.service';
import * as _ from 'lodash';
import { RootScopeService } from '../services/rootscope.service';
import { Country } from '../model/country.model';

declare let $: any;

@Component({
  selector: 'app-country-selection',
  templateUrl: './country-selection.component.html',
  styleUrls: ['./country-selection.component.css'],
  providers: [CountryService],
  encapsulation: ViewEncapsulation.None
})
export class CountrySelectionComponent implements OnInit{
    
    modelReference:any;
    closeResult: string;
    countries:Country[];
    countryForm: FormGroup;
    lodash = _;

  constructor(private modalService: NgbModal, private countryService: CountryService, private formBuilder: FormBuilder, private rootScopeService: RootScopeService) { 
  }
  
  ngOnInit() {
      this.countryForm = this.formBuilder.group({
          country: ['', [Validators.required]]
      });
      
      let countryCode = localStorage.getItem('countryCode');
      if(!countryCode){
          this.countryService.getAllCountries().subscribe((response) =>{
           console.log(response);  
           this.countries = response;
           $("#countrySelection").click();
          },
          (error) => {
              console.log('error: ',error);
          });
      }
  }
  
  open(content) {
      this.modelReference = this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title',size:'lg'})
      this.modelReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
  
 onCountrySubmit(){
      
      if (this.countryForm.invalid) {
          console.log('invalid form');
          return;
      }
      this.modelReference.close();
      
      console.log(this.countryForm.get('country').value);
      
      let countryObj:Country = new Country();
      countryObj.countryCode = this.countryForm.get('country').value;
      
      let selectedCountry:Country = _.filter(this.countries, countryObj)[0];
      
      this.rootScopeService.setSelectedCurrencyCode(selectedCountry.currencyCode);
      localStorage.setItem('countryCode', selectedCountry.currencyCode);
      localStorage.setItem('currencyCode', selectedCountry.languageCode);
      localStorage.setItem('languageCode', selectedCountry.countryCode);

      // set lang related stuff.
      
  }
  
}
