import { Injectable, PipeTransform, Pipe } from "@angular/core";

@Pipe({
  name: 'ancillaryFilter'
})
@Injectable()
export class AncillaryTypeFilter implements PipeTransform {
  transform(ancilaries: any[], type: string): any {
    return ancilaries.filter(ancillary => ancillary.code === type);
  }
}