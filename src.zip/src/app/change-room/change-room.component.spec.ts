import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeRoomComponent } from './change-room.component';

describe('ChangeRoomComponent', () => {
  let component: ChangeRoomComponent;
  let fixture: ComponentFixture<ChangeRoomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangeRoomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeRoomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
