import { DataExchangeService } from './../services/data-exchange.service';
import { Router } from '@angular/router';
import { RouterService } from './../services/router.service';
import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ViewEncapsulation
} from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {
  NgbAccordionConfig,
  NgbCarousel,
  NgbCalendar
} from '@ng-bootstrap/ng-bootstrap';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '../../environments/environment';
import { RootScopeService } from '../services/rootscope.service';
import { HomeService } from '../services/home.service';
import { GeoLocationService } from '../services/geo-location.service';
import { HotelSearchModel, HotelLocation } from '../model/hotel-search-model';
import * as moment from 'moment';
import { GoogleAnalyticsEventsService } from '../google-analytics-events.service';
import { LocationService } from '../services/location.service.';

declare let $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component-ltr.scss', './home.component-rtl.scss'],
  encapsulation: ViewEncapsulation.None
  // providers: [NgbCarouselConfig]
})
export class HomeComponent implements OnInit {
  baseImgUrl: String = environment.IMAGE_LOC;
  recommendationsList: any = [];
  hotDealsList: any = [];
  countryCode: string;
  currencyCode: string;
  images = [
    environment.IMAGE_LOC + '/assets/img/slider/dubai6.png',
    environment.IMAGE_LOC + '/assets/img/slider/dubai4.jpg',
    environment.IMAGE_LOC + '/assets/img/slider/dubai5.png'
  ];

  searchCriteria: HotelSearchModel = new HotelSearchModel();
  moment = moment;
  noOfDays = 0;

  imagesCarousel = [
    '../../assets/img/img-1.jpg',
    '../../assets/img/img-2.jpg',
    '../../assets/img/img-3.jpg'
  ];

  constructor(
    private routerService: RouterService,
    private router: Router,
    config: NgbCarouselConfig,
    private rootScopeService: RootScopeService,
    private homeService: HomeService,
    private geoLocationService: GeoLocationService,
    private calendar: NgbCalendar,
    public googleAnalyticsEventsService: GoogleAnalyticsEventsService,
    private dataExchangeService: DataExchangeService,
    private locationService: LocationService
  ) {
    config.interval = 3000;
    config.wrap = true;
    config.keyboard = true;
    config.pauseOnHover = true;
    config.showNavigationArrows = false;
  }

  cssLayout: String = 'ltr';

  ngOnInit() {
    this.getHotDeals();
    localStorage.removeItem('searchDisplay');
    localStorage.removeItem('searchModel');
    sessionStorage.clear();
    this.rootScopeService.getCSSLayout().subscribe(resp => {
      this.cssLayout = resp;
    });

    this.rootScopeService.setCurrencyChangeAllowedSubject(true);

    this.rootScopeService.getCurrencyChangeSubject().subscribe(res => {
      this.countryCode = this.rootScopeService.getCountryCode();
      this.currencyCode = this.rootScopeService.getSelectedCurrency();
      this.homeService
        .getRecommendations(this.countryCode, this.currencyCode)
        .subscribe(response => {
          this.recommendationsList = response;
        });
    });
  }
  getHotDeals() {
    this.homeService.getHotDeals().subscribe(response => {
      this.hotDealsList = response;
    });
  }

  onSearchClick(data) {
    const searchCriteriaData = { searchModel: data, filtersApplied: false };
    // Setting Search criteria in session storage
    this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);
    this.router.navigate(['/hotel-search']);
  }

  /**
   * Function called upon clicking Recommendation Explore.
   * @param recommendation Selected from client.
   */
  recommendationExplore(recommendation: any) {
    console.log('Upon Explore click RD:',recommendation);
    this.googleAnalyticsEventsService.emitEvent('Desired Destination Click', 'Desired Destination Click', 'Desired Destination Click', 10);
    this.noOfDays = 2;
    this.searchCriteria.noOfRooms = '1';
    this.searchCriteria.adultCnt = '1';
    this.searchCriteria.noOfAdults = 1;
    this.searchCriteria.childCnt = '0';
    this.searchCriteria.nightStays = this.noOfDays;
    this.searchCriteria.currencyCode = this.rootScopeService.getSelectedCurrency();
    let checkInDay = this.calendar.getNext(this.calendar.getToday(), 'd', 1);
    let checkoutDay = this.calendar.getNext(this.calendar.getToday(), 'd', 3);
    this.searchCriteria.checkIn = this.moment([checkInDay.year, checkInDay.month, checkInDay.day]).format('YYYY-MM-DD');
    this.searchCriteria.checkOut = this.moment([checkoutDay.year, checkoutDay.month, checkoutDay.day]).format('YYYY-MM-DD');
    this.searchCriteria.sortBy = 'RECOMMENDED';
    this.searchCriteria.order = 'ASC';
    this.searchCriteria.currencyCode = this.rootScopeService.getSelectedCurrency();
    this.searchCriteria.pageNo = '1';

    // Request body for Single location search.
    const location = {
      code: recommendation.destinationCityId,
      type: 'CITY'
    };
    this.locationService.getLocationByCityCode(location).subscribe(data => {
      this.searchCriteria.location = data;
      this.onSearchClick(this.searchCriteria);
    });
  }
}
