import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, Params } from '@angular/router';
import { Orders } from '../model/orders.model';
import { Customer } from '../model/customer.model';
import { OrderService } from '../services/order.service';
import { RouterService } from '../services/router.service';
import { environment } from '../../environments/environment';
import { RootScopeService } from './../services/rootscope.service';
import * as moment from 'moment';
import { GoogleMapPartner } from '../model/google-map-partner.model';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-manage-booking',
  templateUrl: './manage-booking.html',
  styleUrls: ['./manage-booking.scss'],
  providers: [OrderService]
})
export class ManageBookingComponent implements OnInit, AfterViewInit {
  baseImgUrl: String = environment.IMAGE_LOC;
  orders: Orders;
  propertyToModify: any;
  orderNumber: string;
  authenticatedUser: Customer = null;
  public today = moment(new Date());
  order: any;
  closeResult: string;
  googleMapPartnerList: GoogleMapPartner[] = [];
  constructor(
    private router: Router,
    private routerService: RouterService,
    private orderService: OrderService,
    private rootScopeService: RootScopeService,
    private modalService: NgbModal
  ) { }

  ngOnInit() {
    window.scrollTo(0, 0);
    this.rootScopeService.setCurrencyChangeAllowedSubject(false);

    this.rootScopeService
      .getAuthenticatedUserSubject()
      .subscribe((user: Customer) => {
        this.authenticatedUser = user;

        // get all bookings based on the customer.
        if (this.authenticatedUser != null) {
          this.getOrders(1, 10);
        } else {
          this.router.navigate(['/']);
        }
      });

    //this.googleMapView();
  }

  ngAfterViewInit() { }

  loadOrders($event) {
    window.scrollTo(0, 0);
    this.getOrders($event, 10);
  }

  private getOrders(pageNumber: number, pageSize: number) {
    this.orderService
      .getOrdersByCustomerId(
        this.authenticatedUser.customerId,
        pageNumber,
        pageSize
      )
      .subscribe(
        (data: Orders) => {
          this.orders = data;
          this.orders.orders.forEach(order => {
            this.order = order;
            this.order.orderItems.forEach(orderItem => {
              if (orderItem.cancelmilStoneDate) {
                orderItem['isBeforeMSD'] = this.isMlstnDtBfrTdy(orderItem.cancelmilStoneDate);
              }
            });

          });
          console.log(this.orders);
        },
        error => {
          console.log(error);
        }
      );
  }

  isMlstnDtBfrTdy(mileStoneDate): boolean {
    const today = moment(new Date());
    if (today.isBefore(mileStoneDate)) {
      return true;
    }
    else {
      return false;
    }
  }
  open(content, partner) {
    this.googleMapPartnerList = [];
    this.googleMapPartnerList.push({
      partnerName: partner.partnerName,
      latitude: partner.latitude,
      longitude: partner.longitude,
      partnerImage: partner.partnerImage,
      starRating: partner.starRating,
      partnerAddress:partner.partnerAddress,
    })
    this.modalService
      .open(content, { ariaLabelledBy: 'modal-basic-title', size: 'lg', windowClass: 'checkLocation' })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;

        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

}
