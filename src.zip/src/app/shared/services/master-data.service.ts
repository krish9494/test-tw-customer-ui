import { Injectable } from '@angular/core';
import { Subscription, forkJoin } from 'rxjs';
import { RootScopeService } from 'src/app/services/rootscope.service';


@Injectable({
  providedIn: 'root'
})
export class MasterDataService {

  masterDataKeys = [];
  private subcription: Array<Subscription> = [];
  constructor(private rootScopeService: RootScopeService) {
    this.masterDataKeys = [
      'AmenityList',
      'primaryTagList'
    ];
  }
  setValueInLocalStorage(key: string, value: any) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  getValueFromLocalStorage(key: string) {
    return localStorage.getItem(key);
  }

  getLocalStorageValue(key: any) {
    const value = this.getValueFromLocalStorage(key);
    if (
      value === '' ||
      value === null ||
      value === 'null' ||
      value === undefined ||
      value === 'undefined'
    ) {
      return false;
    }
    return JSON.parse(value);
  }

  isEmpty(object: any) {
    if (!object || object === 'null') {
      return true;
    }
    return false;
  }

  getMasterData() {
    const self = this;
    self.masterDataKeys.forEach(key => {
      if (!self.getLocalStorageValue(key)) {
        self.getLatestMasterData(key);
      }
    });
  }

  getLatestMasterData(key: string) {
    const self = this;
    switch (key) {
      case 'AmenityList': {
        return self.getAmenityList();
      }
      case 'primaryTagList': {
        return self.getPrimaryTagList();
      }
      case 'partnerBrands': {
        return self.getPartnerBrands();
      }
      default: {
        break;
      }
    }
  }

  getPartnerBrands() {
    const self = this;
    const key = 'partnerBrands';
    const value = self.getLocalStorageValue(key);
    if (self.isEmpty(value)) {
      self.rootScopeService.getpartnerBrands().then(
        data => {
          self.setValueInLocalStorage(key, data);
          return data;
        },
        err => {
          console.log(err);
        }
      );
    } else {
      return value;
    }
  }

  getAmenityList() {
    const self = this;
    const key = 'AmenityList';
    const value = self.getLocalStorageValue(key);
    if (self.isEmpty(value)) {
      self.rootScopeService.getAmenities().subscribe(
        data => {
          self.setValueInLocalStorage(key, data);
          return data;
        },
        err => {
          console.log(err);
        }
      );
    } else {
      return value;
    }
  }

  getPrimaryTagList() {
    const self = this;
    const key = 'primaryTagList';
    const value = self.getLocalStorageValue(key);
    if (self.isEmpty(value)) {
      self.rootScopeService.getPrimaryTagMaster().subscribe(
        data => {
          self.setValueInLocalStorage(key, data);
          return data;
        },
        err => {
          console.log(err);
        }
      );
    } else {
      return value;
    }
  }
}
