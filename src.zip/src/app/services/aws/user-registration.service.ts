import { Inject, Injectable } from '@angular/core';
import { CognitoCallback, CognitoUtil } from './cognito.service';
import {
  AuthenticationDetails,
  CognitoUser,
  CognitoUserAttribute
} from 'amazon-cognito-identity-js';
import { Customer } from '../../model/customer.model';
import { ToastrService } from 'ngx-toastr';

@Injectable()
export class UserRegistrationService {
  constructor(
    @Inject(CognitoUtil) public cognitoUtil: CognitoUtil,
    private toastr: ToastrService
  ) {}

  register(user: Customer, userType: string, callback: CognitoCallback): void {
    console.log('UserRegistrationService: user is ', user);

    let attributeList = [];
    //name, email, birthdate, locale, phone_number
    let dataEmail = {
      Name: 'email',
      Value: user.email
    };
    let dataPhoneNumber = {
      Name: 'phone_number',
      Value: user.phone ? user.phone : '+971545647388'
    };
    let dataName = {
      Name: 'name',
      Value: user.firstName + ' ' + user.lastName
    };
    let dataLocale = {
      Name: 'locale',
      Value: user.preferredLanguage
    };
    let dataBirthdate = {
      Name: 'birthdate',
      Value: user.dateOfBirth ? user.dateOfBirth : '01-01-1900'
    };
    let dataRole = {
      Name: 'custom:role',
      Value: 'WEB_CUSTOMER'
    };

    attributeList.push(new CognitoUserAttribute(dataName));
    attributeList.push(new CognitoUserAttribute(dataEmail));
    attributeList.push(new CognitoUserAttribute(dataBirthdate));
    attributeList.push(new CognitoUserAttribute(dataLocale));
    attributeList.push(new CognitoUserAttribute(dataPhoneNumber));
    attributeList.push(new CognitoUserAttribute(dataRole));

    if (userType === 'PMS') {
      this.cognitoUtil
        .getUserPoolPms()
        .signUp(
          user.username,
          user.password,
          attributeList,
          null,
          (err, result) => {
            if (err) {
              callback.cognitoSignupCallback(user, err.message, null, userType);
            } else {
              console.log(
                'UserRegistrationService: registered user is ' + result
              );
              callback.cognitoSignupCallback(
                user,
                'registered',
                result,
                userType
              );
            }
          }
        );
    }
    if (userType === 'USERMODULE') {
      this.cognitoUtil
        .getUserPool()
        .signUp(
          user.username,
          user.password,
          attributeList,
          null,
          (err, result) => {
            if (err) {
              callback.cognitoSignupCallback(user, err.message, null, userType);
            } else {
              console.log(
                'UserRegistrationService: registered user is ' + result
              );
              callback.cognitoSignupCallback(user, null, result, userType);
            }
          }
        );
    }
  }

  confirmRegistration(
    username: string,
    confirmationCode: string,
    userType: string,
    callback: CognitoCallback
  ): void {
    let userData;
    if (userType === 'USERMODULE') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPool()
      };
    }
    if (userType === 'PMS') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPoolPms()
      };
    }

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.confirmRegistration(confirmationCode, true, function(
      err,
      result
    ) {
      if (err) {
        //this.toastr.success('', 'Invalid verification code provided, please try again.', { timeOut: 2000, closeButton: true, positionClass: 'toast-top-full-width' });
        console.log(err.message);
        callback.cognitoConfirmAccountCallback(err.message, null, userType);
      } else {
        //this.toastr.success('', 'Confirmed Succesfully', { timeOut: 2000, closeButton: true, positionClass: 'toast-top-full-width' });
        callback.cognitoConfirmAccountCallback(null, result, userType);
      }
    });
  }

  resendCode(
    username: string,
    callback: CognitoCallback,
    userType: string
  ): void {
    console.log('resend code: ', username);
    let userData;
    if (userType === 'USERMODULE') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPool()
      };
    }
    if (userType === 'PMS') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPoolPms()
      };
    }

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.resendConfirmationCode(function(err, result) {
      if (err) {
        callback.cognitoCallback(err.message, null, userType);
      } else {
        console.log('code sended ');
        callback.cognitoCallback(
          'Security code send to your email address.',
          result,
          userType
        );
      }
    });
  }
}
