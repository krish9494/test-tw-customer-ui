import { environment } from '../../../environments/environment';
import { Injectable } from '@angular/core';
import {
  CognitoCallback,
  CognitoUtil,
  LoggedInCallback
} from './cognito.service';
import {
  AuthenticationDetails,
  CognitoUser,
  CognitoUserSession
} from 'amazon-cognito-identity-js';

@Injectable()
export class UserLoginService {
  userData: any;

  private onLoginSuccess = (
    callback: CognitoCallback,
    session: CognitoUserSession,
    userType: string
  ) => {
    console.log('In authenticateUser onSuccess callback');
    let loginCredentials;
    if (userType === 'USERMODULE') {
      loginCredentials = this.cognitoUtil.buildCognitoCreds(
        session.getIdToken().getJwtToken()
      );
    }
    if (userType === 'PMS') {
      loginCredentials = this.cognitoUtil.buildCognitoCredsPMS(
        session.getIdToken().getJwtToken()
      );
    }
    console.log(
      'UserLoginService: Successfully set the AWS credentials',
      loginCredentials
    );
    callback.cognitoCallback('logedIn', session, userType);
  };

  private onLoginError = (callback: CognitoCallback, err, userType) => {
    callback.cognitoCallback(err.message, null, userType);
  };

  constructor(public cognitoUtil: CognitoUtil) {}

  authenticate(
    username: string,
    password: string,
    userType: string,
    callback: CognitoCallback
  ) {
    console.log('UserLoginService: starting the authentication');

    let authenticationData = {
      Username: username,
      Password: password
    };
    let authenticationDetails = new AuthenticationDetails(authenticationData);
    if (userType === 'USERMODULE') {
      this.userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPool()
      };
    }
    //checking whether pms tab is clicked or not
    if (userType === 'PMS') {
      this.userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPoolPms()
      };
    }

    console.log('UserLoginService: Params set...Authenticating the user');

    let cognitoUser = new CognitoUser(this.userData);
    console.log('UserLoginService: config is .. aws config. :P');
    cognitoUser.authenticateUser(authenticationDetails, {
      newPasswordRequired: (userAttributes, requiredAttributes) =>
        callback.cognitoCallback(`User needs to set password.`, null, userType),
      onSuccess: (result: any) => {
        localStorage.setItem('token', result.idToken.jwtToken);
        this.onLoginSuccess(callback, result, userType);
      },
      onFailure: err => this.onLoginError(callback, err, userType),
      mfaRequired: (challengeName, challengeParameters) => {
        callback.handleMFAStep(
          challengeName,
          challengeParameters,
          (confirmationCode: string) => {
            cognitoUser.sendMFACode(confirmationCode, {
              onSuccess: result =>
                this.onLoginSuccess(callback, result, userType),
              onFailure: err => this.onLoginError(callback, err, userType)
            });
          }
        );
      }
    });
  }

  forgotPassword(
    username: string,
    callback: CognitoCallback,
    userType: string
  ) {
    console.log('forgotPassword pool: ', userType);
    let userData;
    if (userType === 'USERMODULE') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPool()
      };
    }
    if (userType === 'PMS') {
      userData = {
        Username: username,
        Pool: this.cognitoUtil.getUserPoolPms()
      };
    }

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.forgotPassword({
      onSuccess: function() {
        console.log('forgotPassword onSuccess ');
      },
      onFailure: function(err) {
        console.log('forgotPassword onFailure ');
        callback.cognitoCallback(err.message, null, userType);
      },
      inputVerificationCode() {
        console.log('forgotPassword inputVerificationCode ');
        callback.cognitoCallback(
          'Security code send to you email address.',
          null,
          userType
        );
      }
    });
  }

  confirmNewPassword(
    email: string,
    verificationCode: string,
    password: string,
    callback: CognitoCallback,
    userType: string
  ) {
    let userData;
    if (userType === 'USERMODULE') {
      userData = {
        Username: email,
        Pool: this.cognitoUtil.getUserPool()
      };
    }
    if (userType === 'PMS') {
      userData = {
        Username: email,
        Pool: this.cognitoUtil.getUserPoolPms()
      };
    }

    let cognitoUser = new CognitoUser(userData);

    cognitoUser.confirmPassword(verificationCode, password, {
      onSuccess: function() {
        callback.cognitoCallback(
          'Password changed successfully.',
          null,
          userType
        );
      },
      onFailure: function(err) {
        callback.cognitoCallback(err.message, null, userType);
      }
    });
  }

  logout(userType) {
    console.log('UserLoginService: Logging out');
    if (userType === 'PMS') {
      this.cognitoUtil.getCurrentUserPMS().signOut();
      localStorage.setItem('token', null);
    }
    if (userType === 'USERMODULE') {
      this.cognitoUtil.getCurrentUser().signOut();
      localStorage.setItem('token', null);
    }
  }

  isAuthenticated(callback: LoggedInCallback) {
    if (callback == null)
      throw 'UserLoginService: Callback in isAuthenticated() cannot be null';

    let cognitoUser = this.cognitoUtil.getCurrentUser();

    if (cognitoUser != null) {
      cognitoUser.getSession(function(err, session) {
        if (err) {
          console.log(
            "UserLoginService: Couldn't get the session: " + err,
            err.stack
          );
          callback.isLoggedIn(err, false, 'USERMODULE');
        } else {
          console.log('UserLoginService: Session is ' + session.isValid());
          callback.isLoggedIn(err, session.isValid(), 'USERMODULE');
        }
      });
    } else {
      console.log("UserLoginService: can't retrieve the current user");
      callback.isLoggedIn(
        "Can't retrieve the CurrentUser",
        false,
        'USERMODULE'
      );
    }
  }

  isAuthenticatedPMS(callback: LoggedInCallback) {
    if (callback == null)
      throw 'UserLoginService: Callback in isAuthenticated() cannot be null';

    let cognitoUser = this.cognitoUtil.getCurrentUserPMS();

    if (cognitoUser != null) {
      cognitoUser.getSession(function(err, session) {
        if (err) {
          console.log(
            "UserLoginService: Couldn't get the session: " + err,
            err.stack
          );
          callback.isLoggedIn(err, false, 'PMS');
        } else {
          localStorage.set('auth');
          console.log('UserLoginService: Session is ' + session.isValid());
          callback.isLoggedIn(err, session.isValid(), 'PMS');
        }
      });
    } else {
      console.log("UserLoginService: can't retrieve the current user");
      callback.isLoggedIn("Can't retrieve the CurrentUser", false, 'PMS');
    }
  }
}
