import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GeoLocation } from '../model/geolocation';

@Injectable({
  providedIn: 'root'
})
export class GeoLocationService {
  constructor(private http: HttpClient) {}

  getLocation() {
    return this.http.get<GeoLocation>('https://get.geojs.io/v1/ip/geo.json');
  }
}
