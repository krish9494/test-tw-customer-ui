import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

 // baseUrl: String = 'https://kor80rx103.execute-api.ap-southeast-1.amazonaws.com/prod/';
  //baseUrl: String = 'http://54.254.146.153:8080/search/product/';
  //baseUrl: String = 'http://54.254.146.153:8080/search/product/';
  baseUrl: String = 'http://52.76.200.40:8280/search/product/';
  mainUrl: String = 'http://52.76.200.40:8280/';
  newApi: String = 'http://52.76.200.40:8280/es/api/';
  
  constructor(private http: HttpClient) {
  }

  get(url){
   return this.http.get(this.baseUrl + url)
  }

  getWithURL(url){
    return this.http.get(url);
   }

  post(url, request) : Observable<any>{
    return this.http.post(this.baseUrl + url,request);
  }
  postMain(url, request): Observable<any> {
    return this.http.post(this.mainUrl + url, request);
  }
  
  postWithURL(url, request){
    return this.http.post(url,request);
  }

  postNew(url, request) : Observable<any>{
    return this.http.post(this.newApi + url,request);
  }

}
