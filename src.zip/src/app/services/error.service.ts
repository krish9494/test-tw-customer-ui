import {
  ErrorHandler,
  Injectable,
  Injector,
  ViewContainerRef
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { ToastrService, ToastrConfig } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class CustomErrorHandler implements ErrorHandler {
  constructor(private injector: Injector) {}

  handleError(error: any): void {
    /*  let router = this.injector.get(Router);
        console.log('URL: ' + router.url); */
    let toastaService = this.injector.get(ToastrService);
    if (error instanceof HttpErrorResponse) {
      // console.error ( error.message );
    } else {
      // client-side or network error
      console.error('An error occurred:', error.message);

      // toastaService.error('',error.message,{ timeOut: 3000,closeButton:true , positionClass:'toast-top-full-width' });
    }
  }
}
