import { Injectable } from '@angular/core';
import { CognitoUtil } from '../aws/cognito.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private toastr: ToastrService, public cognitoUtil: CognitoUtil) {}

  public isAuthenticated() {
    let cognitoUser = this.cognitoUtil.getCurrentUser();
    if (cognitoUser != null) {
      return true;
    } else {
      return false;
    }
  }
}
