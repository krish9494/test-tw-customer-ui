import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { AuthService } from './auth.service';
import { ToastrService } from 'ngx-toastr';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(
    private router: Router,
    private auth: AuthService,
    private toastr: ToastrService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.auth.isAuthenticated()) {
      // logged in so return true
      return true;
    }
    // not logged in so redirect to login page with the return url
    this.toastr.error(
      '',
      'You are signed out. Sign In to perform this action',
      {
        timeOut: 2000,
        closeButton: true,
        positionClass: 'toast-top-full-width'
      }
    );
    return false;
  }
}
