import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HotelSearchModel} from '../model/hotel-search-model';
import { HttpService } from './http.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { AppConstants } from '../constants/app.contstants';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HotelService {
  productSubject: BehaviorSubject<any> = new BehaviorSubject<any>('');

  constructor(private httpService: HttpService) {
  }

  getHotels(searchCriteria: HotelSearchModel):Observable<any> {     
    return this.httpService.postNew('hotels', searchCriteria).pipe(map(di=>{
      this.productSubject.next(di);
      return di;
    }));
  }

  getHotelDetail(searchModel, partnerId) {
    return this.httpService.postMain('search/partner/' + partnerId + '/details', searchModel);
  }

  getHotelReviews(partnerId){
      return this.httpService.getWithURL(AppConstants.PARTNER_REVIEW_API_ENDPOINT+partnerId+"/reviews");
  }

  getHotelGuestReviews(partnerId, request){
      return this.httpService.postWithURL(AppConstants.PARTNER_REVIEW_API_ENDPOINT+partnerId+"/guestreviews", request);
  }

  getAroundDetails(partnerId){
    return this.httpService.getWithURL(AppConstants.PARTNER_REVIEW_API_ENDPOINT+partnerId+"/landmarks");
  }
}
