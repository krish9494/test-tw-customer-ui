import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataExchangeService {

  constructor() { }
  setDataInLocalStorage(key,value){
    localStorage.setItem(key,JSON.stringify(value));
  }
  public getDataFromLocalStorage(key) {
    if (localStorage.getItem(key)) {
      return JSON.parse(localStorage.getItem(key));
    } else {
      return null;
    }
  }
  public setDataInSessionStorage(key, value) {
    sessionStorage.setItem(key, JSON.stringify(value));
  }
  public getDataFromSessionStorage(key){
    if(sessionStorage.getItem(key)){
      return JSON.parse(sessionStorage.getItem(key));
    }
    else{
      return null;
    }
  }
  // public getModel(sID){
  //   if(localStorage.getItem(sID + '-tw-searchCriteria')){
  //     return localStorage.getItem(sID + '-tw-searchCriteria');
  //   }
  //   else if(sessionStorage.getItem('searchCriteriaData')){
  //     return sessionStorage.getItem('searchCriteriaData');
  //   }
  //   else{
  //     return null;
  //   }
  // }
  public createSessionID(){
    const date = new Date().getTime();
    return date.toString();
  }
}
