import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConstants } from '../constants/app.contstants';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class PartnerPolicyService {

  baseURL: string = AppConstants.PARTNER_POLICIES_ENDPOINT;
  constructor(private http: HttpClient) {
  }

  getPartnerPolicies(partnerId: number, hotelSearchReq) {
    return this.http.post<any>(this.baseURL + '/' + partnerId + '/policies', hotelSearchReq);
  }
  getPartnerPoliciesByOrder(partnerId: number, hotelSearchReq, orderDate) {
    return this.http.post<any>(this.baseURL + '/' + partnerId + '/policies?date=' + orderDate, hotelSearchReq);
  }
}