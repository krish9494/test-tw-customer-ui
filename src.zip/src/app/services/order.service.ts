import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ProductOrder } from '../model/product-order.model';
import { Orders } from '../model/orders.model';
import { map } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class OrderService {
  baseURL: String = 'http://52.76.200.40:9090/';

  // baseURL:string = 'http://localhost:9090/';

  constructor(private http: HttpClient) {}

  order(productOrder: ProductOrder): Observable<string> {
    return this.http
      .put<string>(this.baseURL + 'order', productOrder, httpOptions)
      .pipe(
        map(response => {
          console.log('From Order Service', response);
          return response;
        })
      );
  }

  modifyOrder(productOrder: ProductOrder): Observable<ProductOrder> {
    return this.http.patch<ProductOrder>(
      this.baseURL + 'order',
      productOrder,
      httpOptions
    );
  }

  getOrdersByCustomerId(
    customerId: number,
    currentPage: number = 1,
    pageSize: number = 10
  ): Observable<Orders> {
    return this.http.get<Orders>(
      this.baseURL +
        'orders/customers/' +
        customerId +
        '?currentPage=' +
        currentPage +
        '&pageSize=' +
        pageSize,
      httpOptions
    );
  }

  getOrderDetails(orderNumber): Observable<ProductOrder> {
    return this.http.get<ProductOrder>(
      this.baseURL + 'orders/' + orderNumber,
      httpOptions
    );
  }

  emailProperty(emailProperty: any): Observable<any> {
    return this.http.post(
      `${this.baseURL}partner/${emailProperty.partnerID}/product/order/${emailProperty.orderId}/message`,
      emailProperty,
      httpOptions
    );
  }
}
