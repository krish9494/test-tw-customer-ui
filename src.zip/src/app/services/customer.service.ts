import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Customer } from '../model/customer.model';
import { ProductOrder } from '../model/product-order.model';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CustomerService {
  baseURL: String = 'http://52.76.200.40:9292/';
  baseURLPMS: string = 'http://52.76.200.40:8580/';

  //baseURL:string = 'http://localhost:9292/';

  constructor(private http: HttpClient) {}

  getCustomerById(customerId: number): Observable<Customer> {
    return this.http.get<Customer>(
      this.baseURL + 'customers/' + customerId,
      httpOptions
    );
  }

  createCustomer(customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(
      this.baseURL + 'customers/',
      customer,
      httpOptions
    );
  }

  createPMSCustomer(customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(
      this.baseURLPMS + 'pms/createUser',
      customer,
      httpOptions
    );
  }

  getCustomerByEmail(customer: Customer): Observable<Customer> {
    return this.http.get<Customer>(
      this.baseURL + 'customers/email/' + customer.email,
      httpOptions
    );
  }

  updateCustomer(customer: Customer): Observable<Customer> {
    return this.http.patch<Customer>(
      this.baseURL + 'customers/',
      customer,
      httpOptions
    );
  }
}
