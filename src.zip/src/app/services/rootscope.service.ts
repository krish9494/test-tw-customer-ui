import { HttpService } from './http.service';
import { Injectable, EventEmitter, Output } from "@angular/core";
import { ReplaySubject, Observable, Subject, BehaviorSubject } from "rxjs";
import { AppConstants } from '../constants/app.contstants';
import { Customer } from '../model/customer.model';
import { HotelSearchModel } from '../model/hotel-search-model';
import { SearchCriteria } from '../model/search-criteria.model';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Brand } from '../model/Brand.model';


@Injectable({
    providedIn: 'root'
})
export class RootScopeService {

    private currencyChangeSubject = new ReplaySubject(1);
    private countryCodeChangeSubject = new ReplaySubject(1);
    private cssLayoutChangeSubject = new ReplaySubject(1);
    private searchSubject = new Subject();
    selectedCurrencyCode: string;
    selectedCountryCode: string;
    private authenticatedUser: Customer;
    private currencyChangeAllowedSubject = new ReplaySubject<boolean>(1);
    private userLoginSubject = new ReplaySubject<Customer>(1);
    url = environment.MASTER_SERVICE;

    private searchCriteriaData: SearchCriteria;

    public getSearchCriteriaData(): SearchCriteria {
        return this.searchCriteriaData;
    }

    public setSearchCriteriaData(value: SearchCriteria) {
        this.searchCriteriaData = value;
    }

    constructor(private httpService: HttpService, private http: HttpClient) {
    }

    getSearchEvent(): Observable<any> {
        return this.searchSubject.asObservable();
    }

    callSearchEvent() {
        this.searchSubject.next();
    }

    getCurrencyChangeSubject(): Observable<any> {
        return this.currencyChangeSubject.asObservable();
    }

    setSelectedCurrencyCode(currency: string) {
        this.selectedCurrencyCode = currency;
        this.currencyChangeSubject.next(currency);
    }

    setCSSLayout(cssDirection: String) {
        this.cssLayoutChangeSubject.next(cssDirection);
    }

    getCSSLayout(): Observable<any> {
        return this.cssLayoutChangeSubject.asObservable();
    }

    getSelectedCurrency() {
        return this.selectedCurrencyCode;
    }

    getPrimaryTagMaster() {
        return this.httpService.get('primaryTagMaster');
    }

    getAmenities() {
        return this.httpService.getWithURL(AppConstants.PARTNER_AMENITIES_ENDPOINT);
    }

    getPartnerTypes() {
        return this.httpService.getWithURL(AppConstants.PARTNER_TYPE_ENDPOINT);
    }

    setAuthenticatedUser(authenticatedUser: Customer) {
        this.authenticatedUser = authenticatedUser;
        this.userLoginSubject.next(authenticatedUser);
    }

    getAuthenticatedUserSubject(): Observable<Customer> {
        return this.userLoginSubject.asObservable();
    }

    getAuthenticatedUser() {
        return this.authenticatedUser;
    }

    isCurrencyChangeAllowed(): Observable<Boolean> {
        return this.currencyChangeAllowedSubject.asObservable();
    }

    setCurrencyChangeAllowedSubject(isCurrencyChangeAllowed: boolean) {
        this.currencyChangeAllowedSubject.next(isCurrencyChangeAllowed);
    }
    setCountryCode(countryCode) {
        this.selectedCountryCode = countryCode;
    }
    getCountryCode() {
        return this.selectedCountryCode;
    }

    getConfiguration(category: string) {
        return this.httpService.getWithURL(AppConstants.CONFIG_SERVICE_URL + category);
    }
    getFaqs(partnerId) {
        return this.http.get(`${AppConstants.PARTNER_SERVICE_ENDPOINT}/search/partner/partner/${partnerId}/faq`);
    }

    async getpartnerBrands() {
        return await this.http
          .get<Brand[]>(`${this.url}/ref/partner/brands`)
          .toPromise();
      }

}
