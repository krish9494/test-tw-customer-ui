import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { HttpService } from './http.service';
import { AppConstants } from '../constants/app.contstants';

@Injectable({
  providedIn: 'root'
})
export class SearchFilterService {

  constructor(private httpService: HttpService) {
  }

  getHotelFilterDetails(filterCriteria: Object) {
    return this.httpService.postWithURL(AppConstants.FILTER_API_ENDPOINT,filterCriteria);
  }
}
