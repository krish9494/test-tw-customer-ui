import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {HotelSearchModel} from '../model/hotel-search-model';
import { HttpService } from './http.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { AppConstants } from '../constants/app.contstants';
import { map } from 'rxjs/operators';


@Injectable({
    providedIn: 'root'
  })
  export class HomeService {

    constructor(private httpService: HttpService) {
    }
    getRecommendations(countryCode:string,currencyCode:string){
        return this.httpService.getWithURL(AppConstants.PARTNER_SERVICE_ENDPOINT+"/recommendations/"+countryCode+"/"+currencyCode);
    }
    getHotDeals(){
      return this.httpService.getWithURL(AppConstants.PARTNER_SERVICE_ENDPOINT+"/user/hotDeals");
  }
  }   