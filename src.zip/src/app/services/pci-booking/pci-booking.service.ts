import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import { AppConstants } from '../../constants/app.contstants';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'text/xml', 'authorization': 'APIKEY b915b8858b4145a6a38bbba7edba520f',
    'Access-Control-Allow-Origin': '*'})
};

@Injectable({
  providedIn: 'root'
})
export class PCIBookingService {

  headers = new Headers();
  baseURL: String = 'https://service.pcibooking.net/api/payments';

  constructor(private http: HttpClient) {
    this.headers.set('Access-Control-Allow-Origin', '*');
  }

  getAccessToken(): Observable<any> {
    return this.http.get<any>(AppConstants.GENERATE_PCI_ACCESS_TOKEN);
  }

}
