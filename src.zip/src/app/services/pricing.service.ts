import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';

import { PricingRequest } from '../model/pricing-request.model';
import { Partner } from '../model/partner.model';


const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable()
export class PricingService {


  baseURL:string = 'http://52.76.200.40:8280/';

  constructor(private http: HttpClient) {
  }

  getPrice(pricingRequest: PricingRequest): Observable<Partner> {
    return this.http.post<Partner>(this.baseURL + 'search/partner/'+ pricingRequest.selectedPartner.partnerId+'/price', pricingRequest, httpOptions);
  }
  
}
