import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';

import {Charges} from '../model/charges.model';
import {ProductOrder} from '../model/product-order.model';



const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable()
export class PartnerService {

   baseURL: String = 'http://13.250.101.46:9191/';

   //baseURL:string = 'http://localhost:9191/';

  constructor(private http: HttpClient) {
  }

  getOrderCharges(order:ProductOrder ): Observable<Charges[]> {
    return this.http.post<Charges[]>(this.baseURL + 'partners/'+order.partnerId+'/charges/' , order, httpOptions);
  }

}
