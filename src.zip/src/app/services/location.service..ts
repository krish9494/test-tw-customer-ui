import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { HttpService } from './http.service';
import { AppConstants } from '../constants/app.contstants';
import { HotelLocation } from '../model/hotel-search-model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  baseURL: string = AppConstants.PARTNER_SERVICE_ENDPOINT;
  
  constructor(private httpService: HttpService) {
  }

  getLocationDetails(searchCriteria: String) {
    return this.httpService.getWithURL(this.baseURL + '/location/'+searchCriteria);
  }
  getLocationByCityCode(location): Observable<any> {
    return this.httpService.postWithURL(this.baseURL + '/location', location);
  }
}
