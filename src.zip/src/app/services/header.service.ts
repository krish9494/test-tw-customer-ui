import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Language} from '../model/language.model';
import {Currency} from '../model/currency.model';



const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};
@Injectable({
  providedIn: 'root'
})
export class HeaderService {
  
  //baseUrl: string = 'http://54.254.146.153:8180';
  baseUrl: string = 'http://52.76.200.40:8180';
  //baseUrl: string = 'http://localhost:9090';
  constructor(private http: HttpClient) {
  }

  getLanguages(): Observable<Language[]>{
    return this.http.get<Language[]>(this.baseUrl+'/languages');
  }

  getCurrencies(): Observable<Currency[]>{
    return this.http.get<Currency[]>(this.baseUrl+'/currencies');
  }

}