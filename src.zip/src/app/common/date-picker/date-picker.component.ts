import { DataExchangeService } from './../../services/data-exchange.service';
import {
  Component,
  OnInit,
  ViewChild,
  HostListener,
  Output,
  EventEmitter
} from '@angular/core';

import {
  NgbDateAdapter,
  NgbDateNativeAdapter,
  NgbInputDatepicker,
  NgbCalendar,
  NgbDate,
  NgbModal,
  NgbDropdown,
  NgbPopover,
  NgbDateStruct
} from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import * as moment from 'moment';
import { Router } from '@angular/router';
import { RootScopeService } from '../../services/rootscope.service';

@Component({
  selector: 'date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: [
    './date-picker-ltr.component.scss',
    './date-picker-rtl.component.scss'
  ],
  providers: [{ provide: NgbDateAdapter, useClass: NgbDateNativeAdapter }]
})
export class DatePickerComponent implements OnInit {
  @ViewChild('d') private datePicker: NgbInputDatepicker;
  @ViewChild('datePopOver') private datePopOver: NgbPopover;
  @Output() dateClick = new EventEmitter();
  lodash = _;
  moment = moment;
  minDate;
  maxDate;
  cssLayout: String = 'ltr';

  hoveredDate: NgbDate;
  fromDate: NgbDate;
  toDate: NgbDate;
  displayDate = '';

  displayMonths = 2;
  navigation = 'select';
  showWeekNumbers = false;
  outsideDays = 'visible';

  constructor(
    private calendar: NgbCalendar,
    private router: Router,
    private rootScopeService: RootScopeService,
    private dataExchangeService : DataExchangeService
  ) {
    this.minDate = {
      year: calendar.getToday().year,
      month: calendar.getToday().month,
      day: calendar.getToday().day
    };
    this.maxDate = {
      year: calendar.getToday().year + 1,
      month: calendar.getToday().month,
      day: calendar.getToday().day - 1
    };
  }

  routerUrl;
  ngOnInit() {
    this.routerUrl = this.router.url;

    if (this.dataExchangeService.getDataFromSessionStorage('tw-sdd')) {
      const displayData = this.dataExchangeService.getDataFromSessionStorage('tw-sdd');
      if (displayData) {
        this.displayDate = displayData.date;
      }
    }
    this.rootScopeService.getCSSLayout().subscribe(resp => {
      this.cssLayout = resp;
    });

    if (!this.dataExchangeService.getDataFromSessionStorage('tw-sdd')) {
      this.fromDate = this.calendar.getToday();
      this.toDate = this.calendar.getNext(this.calendar.getToday(), 'd', 2);

      this.displayDate =
        this.moment([
          this.fromDate.year,
          this.fromDate.month - 1,
          this.fromDate.day
        ]).format('ddd,MMM DD') +
        ' - ' +
        this.moment([
          this.toDate.year,
          this.toDate.month - 1,
          this.toDate.day
        ]).format('ddd,MMM DD');
      this.dateClick.emit({
        fromDate: this.fromDate,
        toDate: this.toDate,
        displayDate: this.displayDate
      });
    }
  }

  validate() {
    this.datePopOver.open();
  }
  //TODO -> DAte Picker Code: Move to seperate component

  onDateSelection(date) {
    console.log(date);
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date.after(this.fromDate)) {
      this.toDate = date;
      this.datePicker.close();
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
    this.displayDate =
      this.fromDate && this.toDate
        ? this.moment([
            this.fromDate.year,
            this.fromDate.month - 1,
            this.fromDate.day
          ]).format('ddd,MMM DD') +
          ' - ' +
          this.moment([
            this.toDate.year,
            this.toDate.month - 1,
            this.toDate.day
          ]).format('ddd,MMM DD')
        : this.moment([
            this.fromDate.year,
            this.fromDate.month - 1,
            this.fromDate.day
          ]).format('ddd,MMM DD');
    if (this.fromDate && this.toDate) {
      const noOfDays = this.moment(this.toDate).diff(this.moment(this.fromDate), 'days');
      if (noOfDays > 10) {
        this.datePopOver.open();
      }
      const data = {
        fromDate: this.fromDate,
        toDate: this.toDate,
        displayDate: this.displayDate
      };
      console.log(data);
      this.dateClick.emit(data);
    }
  }

  isHovered(date: NgbDate) {
    return (
      this.fromDate &&
      !this.toDate &&
      this.hoveredDate &&
      date.after(this.fromDate) &&
      date.before(this.hoveredDate)
    );
  }

  isInside(date: NgbDate) {
    return date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return (
      date.equals(this.fromDate) ||
      date.equals(this.toDate) ||
      this.isInside(date) ||
      this.isHovered(date)
    );
  }

  @HostListener('document:click', ['$event'])
  closeDatepickerOnclick(event) {
    if (event.target.id === 'searchDatePicker') {
      event.stopPropagation();
      return false;
    }
    if (event.target.offsetParent == null) this.datePicker.close();
    else if (event.target.offsetParent.nodeName != 'NGB-DATEPICKER')
      this.datePicker.close();
  }
}
