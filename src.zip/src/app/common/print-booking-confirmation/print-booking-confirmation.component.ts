import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductOrder } from 'src/app/model/product-order.model';
import { RootScopeService } from 'src/app/services/rootscope.service';
import { RouterService } from 'src/app/services/router.service';

@Component({
  selector: 'app-print-booking-confirmation',
  templateUrl: './print-booking-confirmation.component.html',
  styleUrls: ['./print-booking-confirmation.component.scss']
})
export class PrintBookingConfirmationComponent implements OnInit {

  constructor(private router: Router, private rootScopeService: RootScopeService,
    private routerService: RouterService) { }
  order: ProductOrder;
  productDetails: any;
  selectedRatePlans:Array<any>;
  cancelationPolicy:any;

  ngOnInit() {
    let orderDetails = this.routerService.navigationData;
    console.log('orderDetails', orderDetails);
    if (orderDetails === undefined) {
      this.router.navigate(['/thankyou']);
    }
    else {
      this.order = orderDetails.order;
      this.productDetails = orderDetails.productDetails;
      this.selectedRatePlans=orderDetails.selectedRatePlans;
      setTimeout(() => {
        window.print();
        this.router.navigate(['/thankyou']);
      });
    }

  }

}
