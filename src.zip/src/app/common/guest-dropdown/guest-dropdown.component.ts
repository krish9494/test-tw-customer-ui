import { DataExchangeService } from './../../services/data-exchange.service';
import {
  Component,
  OnInit,
  ViewChild,
  HostListener,
  Output,
  EventEmitter
} from '@angular/core';
import * as moment from 'moment';
import { HotelSearchModel } from '../../model/hotel-search-model';
import { NgbDropdown } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../environments/environment';
import { RootScopeService } from '../../services/rootscope.service';
import { ActivatedRoute } from '@angular/router';
import { SearchCriteria } from 'src/app/model/search-criteria.model';
@Component({
  selector: 'app-guest',
  templateUrl: './guest-dropdown.component.html',
  styleUrls: ['./guest-dropdown.component.scss']
})
export class GuestComponent implements OnInit {
  @ViewChild('guestNgbDropdown') private guestDropDownRef: NgbDropdown;
  @Output() guestSelection = new EventEmitter();
  noOfAdultsDisplay: any;
  moment = moment;
  guests = [1, 2, 3, 4];
  searchCriteria: HotelSearchModel = new HotelSearchModel();
  minDate;
  maxDate;
  noOfAdults = 1;
  noOfChildren = 0;
  noOfInfants = 0;
  noOfRooms = 1;
  maxAdultCount = environment.MAX_ADULT_COUNT;
  maxChildCount = environment.MAX_CHILD_COUNT;
  maxRoomCount = environment.MAX_ROOM_COUNT;
  maxInfantCount = environment.MAX_INFANT_COUNT;
  constructor(
    private rootService: RootScopeService,
    private route: ActivatedRoute,
    private dataExchangeService : DataExchangeService
  ) {}
  ngOnInit() {
    const searchCriteria = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    
    if ((searchCriteria !== undefined && searchCriteria !== null)&& searchCriteria.searchModel !== undefined &&
      this.route.snapshot.routeConfig.path !== ''
    ) {
      // This is for Search Page.
      this.noOfAdults = Number(searchCriteria.searchModel.noOfAdults);
      this.noOfChildren = Number(searchCriteria.searchModel.noOfChildren);
      this.noOfRooms = Number(searchCriteria.searchModel.noOfRooms);
      this.noOfInfants = Number(searchCriteria.searchModel.noOfInfants);
    } else if (searchCriteria === undefined && this.route.snapshot.routeConfig.path !== ''
    ) {
      // This is for Detail Page.
      // const searchCriteriaData: SearchCriteria = JSON.parse(
      //   localStorage.getItem('searchCriteriaData')
      // );
      const searchCriteriaData: SearchCriteria = this.dataExchangeService.getDataFromSessionStorage('searchCriteriaData');
      if (searchCriteriaData !== undefined) {
        this.noOfAdults = Number(searchCriteriaData.searchModel.noOfAdults);
        this.noOfChildren = Number(searchCriteriaData.searchModel.noOfChildren);
        this.noOfRooms = Number(searchCriteriaData.searchModel.noOfRooms);
        this.noOfInfants = Number(searchCriteriaData.searchModel.noOfInfants);
      }
    }
    this.noOfAdultsDisplay =
      this.noOfAdults + ' Guest(s) in ' + this.noOfRooms + ' Room(s) ';
  }

  @HostListener('click', ['$event'])
  closeDatepickerOnclick(event) {
    if (
      event.target.id.startsWith('guestDropDown') ||
      event.target.parentElement.id.startsWith('guestDropDown') ||
      event.target.parentElement.parentElement.id.startsWith('guestDropDown')
    ) {
      if (event.target.id !== 'guestClose') {
        this.noOfAdultsDisplay =
          this.noOfAdults + ' Guest(s) in ' + this.noOfRooms + ' Room(s) ';
        event.stopPropagation();
        return false;
      } else {
        let data = {
          noOfAdults: this.noOfAdults,
          noOfChildren: this.noOfChildren,
          noOfInfants: this.noOfInfants,
          noOfRooms: this.noOfRooms,
          noOfAdultsDisplay: this.noOfAdultsDisplay
        };
        this.guestSelection.emit(data);
      }
    }
  }

  decreaseGuest(guest) {
    switch (guest) {
      case 'Adults':
        this.noOfAdults =
          this.noOfAdults > 1 ? this.noOfAdults - 1 : this.noOfAdults;
        break;
      case 'Children':
        this.noOfChildren =
          this.noOfChildren > 0 ? this.noOfChildren - 1 : this.noOfChildren;
        break;
      case 'Infants':
        this.noOfInfants =
          this.noOfInfants > 0 ? this.noOfInfants - 1 : this.noOfInfants;
        break;
      case 'Room':
        this.noOfRooms =
          this.noOfRooms > 1 ? this.noOfRooms - 1 : this.noOfRooms;
        break;
    }
    this.emmitGuestDetails();
  }
  increaseGuest(guest) {
    switch (guest) {
      case 'Adults':
        if (this.noOfAdults < this.maxAdultCount) {
          this.noOfAdults = this.noOfAdults + 1;
        }
        break;
      case 'Children':
        if (this.noOfChildren < this.maxChildCount) {
          this.noOfChildren = this.noOfChildren + 1;
        }
        break;
      case 'Infants':
        if (this.noOfInfants < this.maxInfantCount) {
          this.noOfInfants = this.noOfInfants + 1;
        }
        break;
      case 'Room':
        if (this.noOfRooms < this.maxRoomCount) {
          this.noOfRooms = this.noOfRooms + 1;
        }
        break;
    }
    this.emmitGuestDetails();
  }
  guestOpenChange(guestDrpDwnOpenCloseEvent) {
    if (!guestDrpDwnOpenCloseEvent) {
      //Dropdown is closed
      let data = {
        noOfAdults: this.noOfAdults,
        noOfChildren: this.noOfChildren,
        noOfInfants: this.noOfInfants,
        noOfRooms: this.noOfRooms,
        noOfAdultsDisplay: this.noOfAdultsDisplay
      };
      this.guestSelection.emit(data);
    }
  }

  emmitGuestDetails() {
    let data = {
      noOfAdults: this.noOfAdults,
      noOfChildren: this.noOfChildren,
      noOfInfants: this.noOfInfants,
      noOfRooms: this.noOfRooms,
      noOfAdultsDisplay: this.noOfAdultsDisplay
    };
    this.guestSelection.emit(data);
  }
}
