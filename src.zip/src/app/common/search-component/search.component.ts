import { DataExchangeService } from './../../services/data-exchange.service';
import { Observable, of } from 'rxjs';
import { LocationService } from './../../services/location.service.';
import {
  Component,
  OnInit,
  ViewChild,
  ViewEncapsulation,
  Output,
  EventEmitter
} from '@angular/core';
import { HotelSearchModel } from '../../model/hotel-search-model';
import {
  NgbDateAdapter,
  NgbDateNativeAdapter,
  NgbInputDatepicker,
  NgbCalendar,
  NgbDropdown,
  NgbPopover
} from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import * as moment from 'moment';
import { Router } from '@angular/router';

import {
  debounceTime,
  distinctUntilChanged,
  map,
  tap,
  switchMap,
  catchError
} from 'rxjs/operators';
import { RootScopeService } from '../../services/rootscope.service';
import { environment } from '../../../environments/environment';
import { GoogleAnalyticsEventsService } from 'src/app/google-analytics-events.service';
import { GeoLocationService } from 'src/app/services/geo-location.service';
import { DatePickerComponent } from '../date-picker/date-picker.component';
@Component({
  selector: 'search-bar',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component-ltr.scss', './search.component-rtl.scss'],
  providers: [{ provide: NgbDateAdapter, useClass: NgbDateNativeAdapter }],
  encapsulation: ViewEncapsulation.None
})
export class SearchComponent implements OnInit {
  @ViewChild('d') private datePicker: NgbInputDatepicker;
  @ViewChild('guestNgbDropdown') private guestDropDownRef: NgbDropdown;
  @ViewChild('datePick') private datePick: DatePickerComponent;
  @Output() searchClick = new EventEmitter();
  // @ViewChild('hotelBanner') private hotelBanner;

  noOfDays = 0;
  products: any = [];
  lodash = _;
  noOfAdultsDisplay: any;
  moment = moment;
  guests = [1, 2, 3, 4];
  searchCriteria: HotelSearchModel = new HotelSearchModel();
  searchCriteriaTemp: HotelSearchModel = new HotelSearchModel();
  baseImgUrl: String = environment.IMAGE_LOC;
  minDate;
  maxDate;
  amenityList;
  primaryTagList;
  noOfAdults = 1;
  noOfChildren = 0;
  noOfInfants = 0;
  noOfRooms = 1;
  page = 1;
  model: any = {};
  searching = false;
  searchFailed = false;
  displayDate;
  routerUrl;

  cssLayout: String = 'ltr';

  constructor(
    private calendar: NgbCalendar,
    private router: Router,
    private geolocationService: GeoLocationService,
    private locationService: LocationService,
    private rootScopeService: RootScopeService,
    public googleAnalyticsEventsService: GoogleAnalyticsEventsService,
    private dataExchangeService: DataExchangeService
  ) {
    this.minDate = {
      year: calendar.getToday().year,
      month: calendar.getToday().month,
      day: calendar.getToday().day
    };
    this.maxDate = {
      year: calendar.getToday().year + 1,
      month: calendar.getToday().month,
      day: calendar.getToday().day - 1
    };
  }

  searchItem = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      tap(() => (this.searching = true)),
      switchMap(term =>
        this.locationService.getLocationDetails(term).pipe(
          tap(() => (this.searchFailed = false)),
          catchError(() => {
            this.searchFailed = true;
            return of([]);
          })
        )
      ),
      tap(() => (this.searching = false))
    );
  formattedLocationInput = (x: { value: string }) => x.value;


  ngOnInit() {
    this.routerUrl = this.router.url;
    this.noOfAdultsDisplay =
      this.noOfAdults + ' Guest(s) in ' + this.noOfRooms + ' Room(s) ';

    if (this.dataExchangeService.getDataFromSessionStorage('tw-sdd')) {
      // Get Display data from SS
      const displayData = this.dataExchangeService.getDataFromSessionStorage('tw-sdd');
      if (displayData) {
        this.displayDate = displayData.date;
        this.noOfAdultsDisplay = displayData.guests;
      }
    }
    const searchCriteria = this.dataExchangeService.getDataFromSessionStorage('tw-scd');
    if (searchCriteria) {
      // If location is present.
      this.model = searchCriteria.searchModel.location;
    }
    else {
      // If NO Display data in SS call GEO Location.
      this.geolocationService.getLocation().subscribe(location => {
        this.locationService
          .getLocationDetails(location['city'])
          .subscribe(data => {
            this.model = data[0];
          });
      });
    }
    this.rootScopeService.getCSSLayout().subscribe(resp => {
      this.cssLayout = resp;
    });
  }

  search() {
    this.googleAnalyticsEventsService.emitEvent('Home Search Click','Home Search Click','Home Search Click',10);

    // Prepare SearchSearch criteria.
    this.prepareHotelSearchReq();

    if (this.noOfDays > 10) {
      this.datePick.validate();
    } else {

      // Set SearchCriteria in SS.
      const searchCriteriaData = {
        searchModel: this.searchCriteria,
        filtersApplied: false
      };
      this.dataExchangeService.setDataInSessionStorage('tw-scd', searchCriteriaData);

      // Set Display date in SS.
      const displayObj = {
        date: this.displayDate,
        guests: this.noOfAdultsDisplay,
        location: this.model
      };
      this.dataExchangeService.setDataInSessionStorage('tw-sdd', displayObj);
      this.searchClick.emit(this.searchCriteria);
    }
  }

  /**
   * Function to prepare SearchRequest criteria.
   * Called by SearchComponent upon search Click.
   */
  prepareHotelSearchReq() {
    this.noOfDays =
      this.searchCriteria.checkOut && this.searchCriteria.checkIn
        ? this.moment(this.searchCriteria.checkOut).diff(
          this.moment(this.searchCriteria.checkIn),
          'days'
        )
        : 0;
    this.searchCriteria.noOfRooms = this.noOfRooms.toString();
    this.searchCriteria.adultCnt = this.noOfAdults.toString();
    this.searchCriteria.childCnt = this.noOfChildren.toString();
    this.searchCriteria.nightStays = this.noOfDays;

    this.searchCriteria.noOfAdults = this.noOfAdults;
    this.searchCriteria.noOfChildren = this.noOfChildren;
    this.searchCriteria.noOfInfants = this.noOfInfants;
    
    this.searchCriteria.location = this.model;

    this.searchCriteria.sortBy = 'RECOMMENDED';
    this.searchCriteria.order = 'ASC';
    if (this.rootScopeService.getSelectedCurrency()) {
      this.searchCriteria.currencyCode = this.rootScopeService.getSelectedCurrency();
    }
  }

  onGuestSelection(data: any) {
    this.noOfAdults = data.noOfAdults;
    this.noOfChildren = data.noOfChildren;
    this.noOfInfants = data.noOfInfants;
    this.noOfRooms = data.noOfRooms;
    this.noOfAdultsDisplay = data.noOfAdultsDisplay;
  }

  onDateClick(data) {
    this.searchCriteria.checkIn = data.fromDate
      ? this.moment([
          data.fromDate.year,
          data.fromDate.month - 1,
          data.fromDate.day
        ]).format('YYYY-MM-DD')
      : '';
    this.searchCriteria.checkOut = data.toDate
      ? this.moment([
          data.toDate.year,
          data.toDate.month - 1,
          data.toDate.day
        ]).format('YYYY-MM-DD')
      : '';
    this.displayDate = data.displayDate;
  }
}
