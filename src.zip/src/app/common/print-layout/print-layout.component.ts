import { Component, OnInit } from '@angular/core';
import { RouterService } from 'src/app/services/router.service';


@Component({
  selector: 'app-print-layout',
  templateUrl: './print-layout.component.html',
  styleUrls: ['./print-layout.component.scss']
})
export class PrintLayoutComponent implements OnInit {

  constructor(private routerService : RouterService) { }

  navigationData:any;
  ngOnInit() {
    console.log('ngOnInit of PrintLayoutComponent');
    this.navigationData=this.routerService.navigationData;
    console.log('navigationData:',this.navigationData);
    
  }

}
