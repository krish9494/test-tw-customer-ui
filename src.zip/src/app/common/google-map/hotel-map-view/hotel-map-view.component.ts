import { Component, OnInit, Input } from '@angular/core';
import * as _ from 'lodash';
import { environment } from '../../../../environments/environment';
import { RootScopeService } from 'src/app/services/rootscope.service';

@Component({
  selector: 'app-hotel-map-view',
  templateUrl: './hotel-map-view.component.html',
  styleUrls: ['./hotel-map-view.component.scss']
})
export class HotelMapViewComponent implements OnInit {

  @Input() partners: any;
  lodash = _;
  baseImgUrl: String = environment.IMAGE_LOC;
  currencyCode;
  constructor(private rootScopeService: RootScopeService) { }

  ngOnInit() {
    this.rootScopeService.getCurrencyChangeSubject().subscribe(res => {
      this.currencyCode = res;
    });
  }

  markerEvent(product) {
    product.animation = 'Bounce';
  }
}
