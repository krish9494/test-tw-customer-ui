import { Component, OnInit, Input } from '@angular/core';
import { RootScopeService } from '../../services/rootscope.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HotelService } from '../../services/hotel.service';

@Component({
  selector: 'app-google-map',
  templateUrl: './google-map.component.html',
  styleUrls: ['./google-map.component.scss']
})
export class GoogleMapComponent implements OnInit {

  @Input() partners: any;
  @Input() showHotels: boolean;
  @Input() showHotelCard: boolean;
  currencyCode: string;
  constructor(private hotelService: HotelService, private modalService: NgbModal, private rootScopeService: RootScopeService, ) { }

  ngOnInit() {
    this.currencyCode = this.rootScopeService.getSelectedCurrency();
    // this.hotelService.productSubject.subscribe(resp => {
    //   if (resp) {
    //     this.partners = resp;
    //   }
    // });
  }

  closeMap() {
    this.modalService.dismissAll();
  }
}
