import { Component, OnInit, Input } from '@angular/core';
import { HotelService } from 'src/app/services/hotel.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import { RootScopeService } from 'src/app/services/rootscope.service';
import { environment } from '../../../../environments/environment';
import { AgmSnazzyInfoWindow } from '@agm/snazzy-info-window';
import { HotelSearchModel } from 'src/app/model/hotel-search-model';
@Component({
  selector: 'app-google-map-view',
  templateUrl: './google-map-view.component.html',
  styleUrls: ['./google-map-view.component.scss']
})
export class GoogleMapViewComponent implements OnInit {
  title: string = 'Mapping with Angular';
  lat: number = 25.2048;
  lng: number = 55.2708;
  zoom: number = 12;
  size: number;
  lodash = _;
  closeResult: string;
  baseImgUrl: String = environment.IMAGE_LOC;
  selectedIndex: number;

  @Input() partners: any;
  @Input() currencyCode: string;
  constructor() { }


  ngOnInit() {

  }
  hoverOnMarker(marker, selectedIndex, infoWindow) {
    marker.isClicked = 1;
    this.selectedIndex = selectedIndex;
    infoWindow._openInfoWindow();
  }

  markerClick(product) {

    console.log(`Marker - ${product.partnerId}`);

    let searchModel : HotelSearchModel = localStorage.getItem('searchModel') !== undefined ? JSON.parse(localStorage.getItem('searchModel')) : {};

    let selectedPartner = {
        "partnerId" : product.partnerId,
        "productTOList" : 
        [
          {
            "productId" : product.minPriceProduct.productId,
            "productRatePlanToList" : 
            [
              {
                "productRatePlanId": product.minPriceProduct.minPriceRatePlan.productRatePlanId,
                "selectedRoomCount": searchModel.noOfRooms
            }
            ]
          }
        ]
      };     
      searchModel.selectedPartner = selectedPartner;
      console.log(searchModel);

      localStorage.setItem('searchModel', JSON.stringify(searchModel));
      
      let productLink = `#/hotel-details/${product.partnerId}`;
      
      window.open(productLink, "_blank");
      
      
  }

  clicked(e) {
  }
  styleFunc(feature) {

    var color = 'green';

    return {
      fillColor: color,
      strokeColor: color,
      strokeWeight: 1,
      visible: true
    };
  }
}
