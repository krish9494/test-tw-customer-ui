import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us-ltr.component.scss', './about-us-rtl.component.scss']
})
export class AboutUsComponent implements OnInit {

  cssLayout: String = 'ltr';

  constructor(private rootScopeService : RootScopeService) { } 
  
  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }


}
