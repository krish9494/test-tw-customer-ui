import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Renderer2 } from '@angular/core';
import { PCIBookingService } from '../services/pci-booking/pci-booking.service';
import { ElementRef } from '@angular/core';
import { AppConstants } from '../constants/app.contstants';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HostListener } from '@angular/core';

@Component({
  selector: 'app-payment-gateway',
  templateUrl: './payment-gateway.component.html',
  styleUrls: ['./payment-gateway.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PaymentGatewayComponent implements OnInit {

  receiver: any;
  constructor(private renderer: Renderer2, private pciBookingService: PCIBookingService, public modelReference: NgbActiveModal,
    private ele: ElementRef) { }

  ngOnInit() {
    this.pciBookingService.getAccessToken().subscribe(resp => {
      this.createIFrame(resp.accessToken);
    });
  }

  createIFrame(accessToken: string) {
    const PCI_URL =
      AppConstants.PCI_BOOKING_URL +
      AppConstants.PCI_BOOKING_CAPTURE_CARD +
      '?accessToken=' +
      accessToken +
      '&brand=' +
      AppConstants.TRIPWORLD_SANDBOX +
      '&autoDetectCardType=true&autoFocus=false&success=' +
      encodeURIComponent(
        window.location.origin +
          '/assets/pci-callback.component.html?cardToken={cardToken}&authToken={" + authParamName + "}&cardType={cardType}&cardNumber={cardNumber}&cvv={cvv}&expiration={expiration}&cardHolderName={cardHolderName}'
      ) +
      '&failure=' +
      encodeURIComponent(window.location.origin) +
      '&submitWithPostMessage=false&postMessageHost=' +
      encodeURIComponent(window.location.origin);
    const iFrame = this.renderer.createElement('iframe');
    iFrame.setAttribute('src', PCI_URL);
    iFrame.setAttribute('id', 'iframePayment');
    iFrame.setAttribute('frameBorder', '0');
    iFrame.setAttribute('height', '400px');
    iFrame.setAttribute('width', '690px');
    iFrame.setAttribute('onload', 'setFocus()');
    const self = this;
    iFrame.onload = function() {
      self.receiver = self.ele.nativeElement.querySelector(
        '#iframePayment'
      ).contentWindow;
      // self.pciBookingService.getTempSession().subscribe(resp => {
      //   console.log('session----', resp);
      // });
      // self.pciBookingService.getTempSession1().subscribe(resp => {
      //   console.log('session----', resp);
      // });
    };
    this.renderer.appendChild(
      this.ele.nativeElement.querySelector('#payment-gateway'),
      iFrame
    );
  }

  @HostListener('window:callBackForPaymentGateway', ['$event'])
  callBack(callback) {
    if (callback.detail.cardType) {
      this.modelReference.close(true);
    } else {
      this.modelReference.close(false);
    }
  }
}
