import { Component, OnInit } from '@angular/core';
import { RootScopeService } from './../services/rootscope.service';


@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions-ltr.component.scss','./terms-and-conditions-rtl.component.scss']
})
export class TermsAndConditionsComponent implements OnInit {

  cssLayout: String = 'ltr';

  constructor(private rootScopeService : RootScopeService) { } 

  ngOnInit() {

    this.rootScopeService.getCSSLayout().subscribe(resp =>{
      this.cssLayout = resp;
    });

  }

}
