import { Component } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'tripworld-ui';
  eventArray=[];

  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.eventArray = event.urlAfterRedirects.split('/')
        if (this.eventArray[1] == ('hotel-details' || 'view-booking')){
                   event.urlAfterRedirects = '/' + this.eventArray[1];
        }
        (<any>window).ga('set', 'page', event.urlAfterRedirects);
        (<any>window).ga('send', 'pageview');
      }
    });
  }
}
